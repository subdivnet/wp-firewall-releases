<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__.'/hardening-facts.php';
require_once __DIR__.'/vulnerability-presentation.php';
require_once __DIR__.'/release-evidence.php';
require_once __DIR__.'/attack-visibility.php';
/** Owner-facing presentation only; collectors, references and schedules are untouched. */
final class WFP_Owner_Admin {
 const TABS=['overview'=>'Overview','vulnerabilities'=>'Vulnerabilities','attacks'=>'Attacks','login'=>'Login','hardening'=>'Hardening','settings'=>'Settings'];
 public static function init(){
  add_action('admin_menu',[__CLASS__,'menu'],999);
  add_action('admin_init',[__CLASS__,'legacy']);
 }
 public static function url($tab='overview'){return admin_url('admin.php?page=wp-firewall&tab='.$tab);}
 public static function menu(){
  remove_action('admin_notices',['WFP_Scanner_Host_Lab','notice']);
  foreach(['wfp-observer','wfp-updates','wfp-scanner-host-lab','wfp-minimal-hub','wfp-prevention'] as $slug)remove_submenu_page('tools.php',$slug);
  add_menu_page('WP Firewall','WP Firewall','manage_options','wp-firewall',[__CLASS__,'page'],'dashicons-shield',65);
 }
 public static function legacy(){
  if(!current_user_can('manage_options')||!isset($_GET['page'])||!is_string($_GET['page']))return;
  $map=['wfp-observer'=>'overview','wfp-updates'=>'settings','wfp-scanner-host-lab'=>'vulnerabilities','wfp-minimal-hub'=>'vulnerabilities','wfp-prevention'=>'hardening'];
  $page=wp_unslash($_GET['page']);if(isset($map[$page])){wp_safe_redirect(self::url($map[$page]));exit;}
 }
 public static function editor_enabled(){
  if((defined('DISALLOW_FILE_EDIT')&&DISALLOW_FILE_EDIT)||(defined('DISALLOW_FILE_MODS')&&DISALLOW_FILE_MODS))return false;
  if(function_exists('wp_is_file_mod_allowed')&&!wp_is_file_mod_allowed('capability_edit_plugins')&&!wp_is_file_mod_allowed('capability_edit_themes'))return false;
  return true;
 }
 public static function overview(array $findings,array $preview,$editor,$adminGrant=false,array $audit=[]){
  $items=[];
  if(count($findings))$items[]=['level'=>'red','sentence'=>count($findings)===1?'A known vulnerability affects an installed component.':count($findings).' known vulnerability matches need review.','action'=>'Review the finding and update the affected component.','button'=>'Review vulnerabilities','tab'=>'vulnerabilities'];
  if($adminGrant)$items[]=['level'=>'red','sentence'=>'Administrator access was granted in the last 24 hours.','action'=>'Confirm the access change was intended.','button'=>'Review accounts','url'=>admin_url('users.php')];
  if(($preview['pressure']??'')==='REVIEW')$items[]=['level'=>'yellow','sentence'=>'Repeated failed logins were recorded recently.','action'=>'Review the recent activity; this alone does not confirm an attack.','button'=>'Review logins','tab'=>'login'];
  if($editor)$items[]=['level'=>'yellow','sentence'=>'WordPress allows theme and plugin files to be edited in the dashboard.','action'=>'Turn off the file editor to reduce accidental or unwanted code changes.','button'=>'See how to turn it off','tab'=>'hardening'];
  foreach($audit as $check)if(($check['status']??'')==='review')$items[]=['level'=>'yellow','sentence'=>$check['sentence'],'action'=>$check['action'],'button'=>'Review hardening','tab'=>'hardening'];
  $red=false;foreach($items as $item)if($item['level']==='red')$red=true;
  return ['level'=>$red?'red':($items?'yellow':'green'),'label'=>$red?'Action needed':($items?'Worth a look':'No problems found'),'items'=>$items];
 }
 private static function recent_admin_grant(array $events,$now){
  foreach($events as $event){if(!is_array($event)||!in_array('administrator_role_assigned',array_map('trim',explode(',',(string)($event['signals']??''))),true))continue;$stamp=WFP_State_Sanitizer::timestamp($event['last_seen_utc']??($event['time']??''));if($stamp==='')continue;$t=strtotime($stamp.' UTC');if($t!==false&&$t<=$now&&$t>=$now-86400)return true;}return false;
 }
 public static function saved_message($kind,$feedConfigured,$updatesConfigured){
  if($kind==='feed'&&$feedConfigured)return 'Feed credential saved. You can leave this page; the site checks for feed updates automatically.';
  if($kind==='updates'&&$updatesConfigured)return 'Plugin-update credential saved. You can manage updates from the Plugins page.';
  return '';
 }
 public static function login_summary(array $preview){
  $n=$preview['failed_attempts']??null;
  if(!is_int($n)||$n<0||$n>3000000)return ['color'=>'grey','text'=>'Not checked yet.'];
  if($n===0)return ['color'=>'neutral','text'=>'No failed login attempts were recorded in these periods.'];
  if($n<5)return ['color'=>'neutral','text'=>$n.($n===1?' failed login attempt was':' failed login attempts were').' recorded in these periods.'];
  return ['color'=>'yellow','text'=>'Repeated failed logins are worth reviewing; this alone does not confirm an attack.'];
 }
 private static function badge($text,$color='grey'){echo '<span class="wfp-badge wfp-'.esc_attr($color).'">'.esc_html($text).'</span>';}
 private static function details($html){echo '<details class="wfp-details"><summary>Show details</summary>'.$html.'</details>';}
 private static function nonce_field($action,$id){
  // Change only DOM identity. Preserve WordPress action, POST name and nonce value.
  ob_start();wp_nonce_field($action);$html=ob_get_clean();
  echo str_replace('id="_wpnonce"','id="'.esc_attr($id).'"',$html);
 }
 private static function audit_rows(array $checks){
  $names=['public_registration'=>'Public account registration','registration_role'=>'Default new-account role','mfa_coverage'=>'Multi-factor authentication','https_login'=>'Login connection checks','application_passwords'=>'Connected application access','country_coverage'=>'Country information'];
  foreach($checks as $c){if(!isset($names[$c['id']])||$c['id']==='registration_role')continue;$text=$c['result']==='PASS'?'No problem found':($c['result']==='REVIEW'?'Worth a look':'Not checked yet');echo '<div class="wfp-check"><h3>'.esc_html($names[$c['id']]).'</h3>';self::badge($text,$c['result']==='PASS'?'green':($c['result']==='REVIEW'?'yellow':'grey'));if($c['id']==='public_registration'){
    if($c['result']==='PASS')echo '<p>Public account registration is turned off.</p>';
    elseif($c['result']==='REVIEW')echo '<p>Visitors can register for accounts. Review whether this is intended.</p><p><a class="button" href="'.esc_url(admin_url('options-general.php')).'">Review registration settings</a></p>';
   }
   self::details('<p>'.esc_html($c['id']==='public_registration'?'This checks public registration only; other account-creation paths are not covered.':$c['meaning']).'</p>');echo '</div>';}
 }
 public static function page(){
  if(!current_user_can('manage_options'))wp_die('Insufficient permissions');nocache_headers();
  $tab=isset($_GET['tab'])&&is_string($_GET['tab'])?sanitize_key(wp_unslash($_GET['tab'])):'overview';if(!isset(self::TABS[$tab]))$tab='overview';
  $report=WFP_Prevention_Panel::status();$hub=WFP_Minimal_Hub::status();$alerts=get_option(WFP_Scanner_Host_Lab::ALERTS,[]);$findings=is_array($alerts['findings']??null)?$alerts['findings']:[];$state=WFP_Observer::read_state();
  $hardening=WFP_Hardening_Facts::capture();
  $summary=self::overview($findings,$report['login']['preview'],self::editor_enabled(),self::recent_admin_grant($state['events']??[],time()),$hardening['checks']);
  $attackState=defined('WFP_Observer::STATE')&&!is_array(get_option(WFP_Observer::STATE,null))?null:$state;
  $attackModel=WFP_Attack_Visibility::model($attackState,time());
  if(WFP_Attack_Visibility::needs_review($attackModel['day'])){
   $summary['items'][]=['level'=>'yellow','sentence'=>'Possible probes or rapid failed-login groups were recorded in the past 24 hours.','action'=>'Review the observed counts; they do not prove a successful attack.','button'=>'Review attack activity','tab'=>'attacks'];
   if($summary['level']!=='red'){$summary['level']='yellow';$summary['label']='Worth a look';}
  }
  echo '<style>.wfp-owner{max-width:1120px}.wfp-status{padding:28px 32px;border-radius:10px;margin:24px 0;font-size:32px;font-weight:650}.wfp-green{background:#e7f4ea;color:#185c2c}.wfp-yellow{background:#fff3cd;color:#735000}.wfp-red{background:#fbe8e7;color:#9c2121}.wfp-grey{background:#eceff2;color:#50575e}.wfp-item{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:24px;background:white;padding:22px 24px;margin:12px 0;border:1px solid #dcdcde;border-radius:8px}.wfp-item p{font-size:15px;margin:5px 0}.wfp-item .button{flex-shrink:0}.wfp-check{background:white;border:1px solid #dcdcde;padding:20px 24px;margin:14px 0;border-radius:8px}.wfp-badge{display:inline-block;padding:5px 11px;border-radius:16px;font-size:13px}.wfp-details{margin:22px 0;padding:18px;background:white;border:1px solid #dcdcde;border-radius:8px}.wfp-details summary{cursor:pointer;font-weight:600}.wfp-owner input[type=password]{max-width:100%;box-sizing:border-box}.wfp-owner pre{white-space:pre-wrap;overflow-wrap:anywhere}.wfp-tabs{margin-bottom:24px}.wfp-owner table{margin:18px 0}.wfp-muted{color:#646970}</style><div class="wrap wfp-owner"><h1>WP Firewall</h1><nav class="nav-tab-wrapper wfp-tabs" aria-label="WP Firewall sections">';
  foreach(self::TABS as $key=>$label)echo '<a class="nav-tab'.($tab===$key?' nav-tab-active':'').'" href="'.esc_url(self::url($key)).'"'.($tab===$key?' aria-current="page"':'').'>'.esc_html($label).'</a>';
  echo '</nav>';
  if($tab==='overview'){
   echo '<div role="status" class="wfp-status wfp-'.esc_attr($summary['level']).'">'.esc_html($summary['label']).'</div>';
   echo '<section class="wfp-check"><h2>Attack activity in the past 24 hours</h2><p>'.esc_html(WFP_Attack_Visibility::sentence($attackModel['day'])).'</p><p>This is a partial view. Counts overlap and do not prove a successful attack.</p><a class="button" href="'.esc_url(self::url('attacks')).'">Review attack activity</a></section>';
   if(!$summary['items'])echo '<p>No problems were found in the checks completed so far.</p>';
   foreach($summary['items'] as $item)echo '<section class="wfp-item"><div><p><strong>'.esc_html($item['sentence']).'</strong></p><p>'.esc_html($item['action']).'</p></div><a class="button" href="'.esc_url($item['url']??self::url($item['tab']??'overview')).'">'.esc_html($item['button']).'</a></section>';
   self::details('<p>Checks may cover only part of the site. Some checks have not run yet. This status describes recorded findings, not a guarantee that the site is secure.</p><p>Protection is currently observation only: no login is blocked and no setting is changed automatically.</p><p>Last local vulnerability check: '.esc_html(WFP_Vulnerability_Presentation::display_date($hub['matching']['checked_at_utc']??null,time())).'.</p>'.WFP_Release_Evidence::html());
  }elseif($tab==='vulnerabilities'){
   $presentation=WFP_Vulnerability_Presentation::summary($findings,is_array($hub['matching']??null)?$hub['matching']:[],time());
   echo '<h2>Vulnerabilities</h2>';
   if($presentation['color']==='grey')self::badge($presentation['text'],'grey');else echo '<p>'.esc_html($presentation['text']).'</p>';
   foreach($findings as $finding){$display=$finding;unset($display['feed_status'],$display['feed_age_seconds']);echo '<section class="wfp-check"><h3>'.esc_html($finding['title']??'Vulnerability finding').'</h3><p>Review the advisory and update the affected component.</p>';self::details(WFP_Wordfence_Local::render_finding($display));echo '</section>';}
   $m=$hub['matching']??[];$phase=$hub['state']['status']??'';
   $progress=$phase==='indexing'?'A downloaded update is being prepared; earlier results remain visible.':($phase==='unavailable'?'The latest update could not be completed; earlier results remain visible.':'The site checks the published feed automatically.');
   $cost=$hub['state']['resources']??null;$costText='<p>Feed resource measurements: Not checked yet.</p>';
   if(is_array($cost)&&isset($cost['cache_logical_bytes'],$cost['cache_files'],$cost['php_allocator_peak_bytes'],$cost['last_slice_elapsed_seconds'])){
    $active=$hub['state']['active']??[];
    $costText='<h3>Feed resource measurements</h3><p>Measured at '.esc_html(WFP_Vulnerability_Presentation::display_date($cost['captured_at_utc']??null,time())).'.</p><p>Local cache: '.esc_html(number_format($cost['cache_logical_bytes']/1048576,2)).' MiB across '.esc_html((string)$cost['cache_files']).' files. Local cache limit: 512 MiB and 2,048 files.</p><p>Largest PHP allocation recorded in the measured request: '.esc_html(number_format($cost['php_allocator_peak_bytes']/1048576,2)).' MiB. Measured request work: '.esc_html((string)$cost['last_slice_elapsed_seconds']).' seconds.</p><p>Current feed indexing: '.esc_html((string)($active['index_elapsed_seconds']??'Not checked yet')).' seconds across '.esc_html((string)($active['slices']??'Not checked yet')).' requests; longest indexing slice '.esc_html((string)($active['max_index_slice_seconds']??'Not checked yet')).' seconds.</p><p>These are logical file sizes, PHP allocator memory and elapsed time, not hosting quota, physical disk allocation, total process memory or CPU usage. Check account-level load and limits separately before adding another site.</p>';
   }
   $audit=$hub['state']['cache_audit']??null;
   if(($hub['state']['cache_policy']??null)==='legacy_measurement'&&is_array($audit)){
    $complete=($audit['complete']??false)===true;
    $costText='<h3>Existing cache measurement</h3><p>Measured at '.esc_html(WFP_Vulnerability_Presentation::display_date($audit['captured_at_utc']??null,time())).'.</p><p>'.($complete?'Local cache: ':'Counted so far: at least ').esc_html(number_format(($audit['logical_bytes']??0)/1048576,2)).' MiB across '.esc_html((string)($audit['files']??0)).' files.</p>';
    if(!$complete)$costText.='<p>The measurement did not finish. The full cache size has not been checked yet.</p>';
    $costText.='<p>The existing SecurityLab cache is being measured before a capacity change. Its previous feed behavior is retained; the new-site cache limit has not been applied here and old files are not removed.</p>';
    if(is_array($cost)&&isset($cost['php_allocator_peak_bytes'],$cost['last_slice_elapsed_seconds']))$costText.='<p>Largest PHP allocation in the measured feed request: '.esc_html(number_format($cost['php_allocator_peak_bytes']/1048576,2)).' MiB. Measured request work: '.esc_html((string)$cost['last_slice_elapsed_seconds']).' seconds. Captured at '.esc_html(WFP_Vulnerability_Presentation::display_date($cost['captured_at_utc']??null,time())).'.</p>';
    $costText.='<p>Logical file sizes are not physical disk allocation, account quota or inode headroom. PHP allocator memory and elapsed time are not total process memory or CPU usage.</p>';
   }
   self::details($costText.'<p>'.esc_html($progress).'</p><p>'.esc_html((string)($m['components_checked']??0)).' components and '.esc_html((string)($m['candidate_records_checked']??0)).' advisory records were checked. Matching covers selected records; full coverage is not established.</p><p>Feed acquired: '.esc_html(WFP_Vulnerability_Presentation::display_date($m['feed_attempt_utc']??null,time())).'. Last local check: '.esc_html(WFP_Vulnerability_Presentation::display_date($m['checked_at_utc']??null,time())).'.</p><p>Feed age and incomplete coverage do not create a vulnerability finding.</p>');
  }elseif($tab==='attacks'){
   WFP_Attack_Visibility::render($attackModel);
  }elseif($tab==='login'){
   $login=self::login_summary($report['login']['preview']);echo '<h2>Login activity</h2>';
   if($login['color']==='grey')self::badge($login['text'],'grey');else echo '<p>'.esc_html($login['text']).'</p>';
   if($login['color']==='yellow')echo '<p>Review whether the timing fits expected activity with your site maintainer.</p>';
   echo '<p>Login protection is observing activity. It does not block or challenge anyone.</p><table class="widefat striped"><thead><tr><th>Five-minute period starts (UTC)</th><th>Failed login attempts recorded</th></tr></thead><tbody>';
   foreach($report['login']['buckets'] as $b)echo '<tr><td>'.esc_html($b['bucket_start_utc']).'</td><td>'.esc_html((string)$b['failed_attempts']).'</td></tr>';echo '</tbody></table>';
   self::details('<p>The preview flags five recorded failures across these periods for review. It does not identify an attack or distinct people. Retained history can be incomplete; groups crossing period boundaries are excluded. Excluded groups: '.esc_html((string)$report['login']['preview']['ambiguous_groups_excluded']).'.</p><p>Country restrictions are not enabled. No trusted country sample is available for an impact estimate.</p>');
  }elseif($tab==='hardening'){
   echo '<h2>Hardening</h2><section class="wfp-check" id="file-editor"><h3>WordPress file editor</h3>';self::badge(self::editor_enabled()?'Worth a look':'Turned off',self::editor_enabled()?'yellow':'green');
   echo '<p>'.(self::editor_enabled()?'The dashboard file editor is enabled. Turning it off reduces accidental or unwanted changes to plugin and theme code.':'The dashboard file editor is turned off by site policy.').'</p>';
   if(self::editor_enabled())echo '<p>Ask your site maintainer to add this line to the WordPress configuration file, before the line that says to stop editing:</p><pre><code>define( \'DISALLOW_FILE_EDIT\', true );</code></pre><p>This turns off the built-in file editor while keeping normal plugin and theme updates available. This page does not change the file for you.</p><a class="button" href="https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#disable-the-plugin-and-theme-file-editor">Read the WordPress instructions</a>';
   echo '</section>';
   foreach($hardening['checks'] as $check){echo '<section class="wfp-check"><h3>'.esc_html($check['title']).'</h3>';self::badge($check['badge'],$check['color']);echo '<p>'.esc_html($check['sentence']).'</p>';if($check['action']!==null)echo '<p>'.esc_html($check['action']).'</p>';self::details('<p>'.esc_html($check['details']).'</p>');echo '</section>';}
   self::audit_rows($report['audit']['checks']);
   require __DIR__.'/country-draft-view.php';
  }else{
   $saved=isset($_GET['wfp_saved'])&&is_string($_GET['wfp_saved'])?sanitize_key(wp_unslash($_GET['wfp_saved'])):'';
   $message=self::saved_message($saved,WFP_Private_Updates::hub_configured(),WFP_Private_Updates::updates_configured());
   if($message!=='')echo '<div class="wfp-check wfp-green" role="status"><p>'.esc_html($message).'</p></div>';
   echo '<h2>Settings</h2><p>Matching stays on this site. The provider key stays on your machine. Credentials are never shown after saving.</p><section class="wfp-check"><h3>Feed connection</h3>';self::badge(WFP_Private_Updates::hub_configured()?'Credential saved':'Not configured',WFP_Private_Updates::hub_configured()?'green':'grey');
   echo '<p>Use a separate expiring read-only token for the private feed repository.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_hub_save_read_token">';self::nonce_field('wfp_hub_save_read_token','wfp-feed-nonce');echo '<label for="wfp_hub_read_token">New feed read-only token</label><p><input id="wfp_hub_read_token" name="wfp_hub_read_token" type="password" value="" autocomplete="new-password" size="55"></p>';submit_button('Save feed credential','secondary','submit',true,['id'=>'wfp-feed-submit']);echo '</form></section><section class="wfp-check"><h3>Plugin updates</h3>';self::badge(WFP_Private_Updates::updates_configured()?'Credential saved':'Not configured',WFP_Private_Updates::updates_configured()?'green':'grey');echo '<p>The plugin update credential is separate from the feed credential. Saving a new credential replaces the stored one.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_save_token">';self::nonce_field('wfp_save_token','wfp-updates-nonce');echo '<label for="wfp_token">New plugin-update read-only token</label><p><input id="wfp_token" name="wfp_token" type="password" value="" autocomplete="new-password" size="55"></p>';submit_button('Save update credential','secondary','submit',true,['id'=>'wfp-updates-submit']);echo '</form><p><a class="button" href="'.esc_url(admin_url('plugins.php')).'">Manage plugin updates</a></p></section>';
   if(empty($hub['enabled'])){
    echo '<section class="wfp-check"><h3>Connect this site to the feed</h3><p>Saving a credential does not connect this site. The feed uses a private folder outside the public website; debug logging is not required. Start one site at a time and review its measured storage and request cost before adding another. Hosting limits may be unknown.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_minimal_hub">';self::nonce_field('wfp_minimal_hub','wfp-enroll-nonce');echo '<p><label for="wfp-hub-consent"><input id="wfp-hub-consent" type="checkbox" name="wfp_hub_site_consent" value="yes" required> I want this site to download the private feed and check component versions locally.</label></p><p>This schedules observation only. It does not block visitors or change WordPress security settings.</p>';submit_button('Connect this site','secondary','submit',true,['id'=>'wfp-enroll-submit']);echo '</form></section>';
   }
   WFP_Release_Evidence::settings_html();
   if(class_exists('WFP_Owner_Mail'))WFP_Owner_Mail::panel();
   self::details('<p>The feed repository is subdivnet/wp-firewall-feed. The plugin source repository is subdivnet/wp-firewall. Use a different token for each, limited to its own repository.</p><p>Observation mode is active. No blocking, country restrictions, challenges or automatic setting changes are enabled.</p>');
  }
  echo '</div>';
 }
}
WFP_Owner_Admin::init();
