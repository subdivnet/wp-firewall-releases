<?php
/**
 * Private GitHub release updater for the WP Firewall Prototype.
 *
 * Opt-in: define('WFP_GITHUB_TOKEN', 'fine-grained-read-only-token') in wp-config.php.
 * Never put credentials in plugin files, GitHub source, update metadata or URLs.
 * WordPress's normal update UI handles installation; this code does not enable auto-updates.
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/public-update-download.php';
final class WFP_Private_Updates {
 const REPO = 'subdivnet/wp-firewall';
 const FEED_REPO = 'subdivnet/wp-firewall-feed';
 const SLUG = 'wp-firewall-prototype';
 const FILE = 'wp-firewall-prototype/wp-firewall-prototype.php';
 const CACHE = 'wfp_private_release_v1';
 private static function public_enabled() {
  return defined('WFP_PUBLIC_UPDATES_ORIGIN') && defined('WFP_PUBLIC_UPDATES_KEY');
 }
 private static function public_channel() {
  return defined('WFP_PUBLIC_UPDATES_CHANNEL') ? WFP_PUBLIC_UPDATES_CHANNEL : 'stable';
 }
 private static function installed_version() {
  if (!function_exists('get_plugin_data')) { require_once ABSPATH.'wp-admin/includes/plugin.php'; }
  return get_plugin_data(WP_PLUGIN_DIR.'/'.self::FILE, false, false)['Version'] ?? '0';
 }
 private static function package_marker(array $release) {
  return self::public_enabled() ? wfp_public_release_marker($release) : 'wfp-private-release://'.$release['zip_id'];
 }
 public static function init() {
  add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'updates']);
  add_filter('site_transient_update_plugins', [__CLASS__, 'updates']);
  add_filter('update_plugins_pebkac404.com', [__CLASS__, 'custom_update'], 10, 4);
  add_filter('plugins_api', [__CLASS__, 'info'], 10, 3);
  add_filter('upgrader_pre_download', [__CLASS__, 'download'], 10, 4);
  add_action('admin_menu', [__CLASS__, 'menu']);
  add_action('admin_post_wfp_hub_save_read_token', [__CLASS__, 'save_hub_token']);
  add_action('admin_post_wfp_save_token', [__CLASS__, 'save_token']);
  add_action('admin_post_wfp_install_update', [__CLASS__, 'install_update']);
 }
 private static function token() {
  if (defined('WFP_GITHUB_TOKEN') && is_string(WFP_GITHUB_TOKEN)) { return trim(WFP_GITHUB_TOKEN); }
  $sealed = get_option('wfp_encrypted_token_v1', '');
  if (!is_string($sealed) || !$sealed || !function_exists('openssl_decrypt')) { return ''; }
  $raw = base64_decode($sealed, true);
  if ($raw === false || strlen($raw) < 29) { return ''; }
  $key = hash('sha256', wp_salt('auth').'wfp-github-token', true);
  $value = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
  return is_string($value) ? $value : '';
 }
 private static function api($url, $accept = 'application/vnd.github+json') {
  if (!self::token()) { return new WP_Error('wfp_no_token', 'Private updates are not configured'); }
  return wp_remote_get($url, [
   'timeout' => 15, 'redirection' => 0,
   'headers' => [
    'Authorization' => 'Bearer '.self::token(),
    'Accept' => $accept,
    'X-GitHub-Api-Version' => '2022-11-28',
    'User-Agent' => 'WFP-WordPress-Updater'
   ]
  ]);
 }
 private static function release() {
  if (self::public_enabled()) {
   static $public_release = false;
   if ($public_release === false) {
    $release = wfp_fetch_public_release(WFP_PUBLIC_UPDATES_ORIGIN, WFP_PUBLIC_UPDATES_KEY, self::public_channel(), self::installed_version());
    $public_release = is_wp_error($release) ? null : $release;
   }
   return $public_release;
  }
  $cached = get_site_transient(self::CACHE);
  if (is_array($cached)) { return $cached; }
  $res = self::api('https://api.github.com/repos/'.self::REPO.'/releases/latest');
  if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) { return null; }
  $body = json_decode(wp_remote_retrieve_body($res), true);
  if (!is_array($body) || !empty($body['draft']) || !empty($body['prerelease'])) { return null; }
  if (empty($body['tag_name']) || !preg_match('/^v([0-9]+\\.[0-9]+\\.[0-9]+)$/D', $body['tag_name'], $m)) { return null; }
  $zip = 0; $sum = 0;
  foreach (($body['assets'] ?? []) as $asset) {
   if (($asset['name'] ?? '') === 'wp-firewall-prototype.zip') { $zip = (int) ($asset['id'] ?? 0); }
   if (($asset['name'] ?? '') === 'SHA256SUMS') { $sum = (int) ($asset['id'] ?? 0); }
  }
  if (!$zip || !$sum) { return null; }
  $data = ['version' => $m[1], 'zip_id' => $zip, 'sum_id' => $sum];
  set_site_transient(self::CACHE, $data, 30 * MINUTE_IN_SECONDS);
  return $data;
 }

 private static function hub_token() {
  if (defined('WFP_FEED_GITHUB_TOKEN') && is_string(WFP_FEED_GITHUB_TOKEN)) { return trim(WFP_FEED_GITHUB_TOKEN); }
  $sealed = get_option('wfp_hub_read_token_v1', '');
  if (!is_string($sealed) || !$sealed || !function_exists('openssl_decrypt')) { return ''; }
  $raw = base64_decode($sealed, true);
  if ($raw === false || strlen($raw) < 29) { return ''; }
  $key = hash('sha256', wp_salt('auth').'wfp-hub-read-token', true);
  $value = openssl_decrypt(substr($raw,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16));
  return is_string($value) ? $value : '';
 }
 public static function updates_configured() { return self::public_enabled() || self::token() !== ''; }
 public static function hub_configured() { return self::hub_token() !== ''; }
 public static function save_hub_token() {
  if (!current_user_can('manage_options')) { wp_die('Administrator access required.'); }
  check_admin_referer('wfp_hub_save_read_token');
  $token = isset($_POST['wfp_hub_read_token']) && is_string($_POST['wfp_hub_read_token']) ? trim(wp_unslash($_POST['wfp_hub_read_token'])) : '';
  if (!preg_match('/^github_pat_[A-Za-z0-9_]{20,}$/D',$token) || !function_exists('openssl_encrypt')) { wp_die('Fine-grained feed token required, or encryption unavailable.'); }
  $iv=random_bytes(12);$tag='';$key=hash('sha256',wp_salt('auth').'wfp-hub-read-token',true);
  $cipher=openssl_encrypt($token,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
  if ($cipher===false || strlen($tag)!==16) { wp_die('Credential encryption failed.'); }
  $sealed=base64_encode($iv.$tag.$cipher);
  if (!update_option('wfp_hub_read_token_v1',$sealed,false) && get_option('wfp_hub_read_token_v1')!==$sealed) { wp_die('Credential could not be saved.'); }
  wp_safe_redirect(admin_url('admin.php?page=wp-firewall&tab=settings&wfp_saved=feed'));exit;
 }

 /** Feed distribution uses its own read-only credential and data repository. */
 public static function hub_manifest() {
  if (!self::hub_configured()) { throw new RuntimeException('hub_credentials_unavailable'); }
  $response = wp_safe_remote_get('https://api.github.com/repos/'.self::FEED_REPO.'/releases/tags/hub-scanner', ['timeout'=>15,'redirection'=>0,'sslverify'=>true,'headers'=>['Authorization'=>'Bearer '.self::hub_token(),'Accept'=>'application/vnd.github+json','X-GitHub-Api-Version'=>'2022-11-28','User-Agent'=>'WFP-Hub-Pull']]);
  if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) { throw new RuntimeException('hub_metadata_unavailable'); }
  $body = wp_remote_retrieve_body($response);
  if (!is_string($body) || strlen($body) > 2097152) { throw new RuntimeException('hub_metadata_invalid'); }
  $release = json_decode($body, true);
  if (!is_array($release) || ($release['tag_name'] ?? '') !== 'hub-scanner' || empty($release['prerelease']) || !empty($release['draft'])) { throw new RuntimeException('hub_metadata_invalid'); }
  $manifest = json_decode((string)($release['body'] ?? ''), true);
  if (!is_array($manifest)) { throw new RuntimeException('hub_manifest_invalid'); }
  return $manifest;
 }
 public static function hub_download($id, $filename, $maximum) {
  if (!is_int($id) || $id < 1 || !self::hub_token()) { throw new RuntimeException('hub_credentials_unavailable'); }
  $args = ['timeout'=>60,'redirection'=>0,'sslverify'=>true,'stream'=>true,'filename'=>$filename,'limit_response_size'=>$maximum,
   'headers'=>['Authorization'=>'Bearer '.self::hub_token(),'Accept'=>'application/octet-stream','X-GitHub-Api-Version'=>'2022-11-28','User-Agent'=>'WFP-Hub-Pull']];
  $response = wp_safe_remote_get('https://api.github.com/repos/'.self::FEED_REPO.'/releases/assets/'.$id, $args);
  if (is_wp_error($response)) { throw new RuntimeException('hub_download_unavailable'); }
  $code = wp_remote_retrieve_response_code($response);
  if (in_array($code, [302,307], true)) {
   $location = wp_remote_retrieve_header($response,'location'); $parts=wp_parse_url($location);
   if (!is_array($parts) || ($parts['scheme']??'')!=='https' || !in_array($parts['host']??'', ['release-assets.githubusercontent.com','objects.githubusercontent.com'],true)) { throw new RuntimeException('hub_download_host_invalid'); }
   unset($args['headers']['Authorization']); // Repository credential never follows the CDN URL.
   $response=wp_safe_remote_get($location,$args);
  }
  if (is_wp_error($response) || wp_remote_retrieve_response_code($response)!==200) { throw new RuntimeException('hub_download_unavailable'); }
 }

 public static function menu() {
  add_management_page('Firewall Updates', 'Firewall Updates', 'manage_options', 'wfp-updates', [__CLASS__, 'page']);
 }
 public static function page() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  $configured = self::token() !== '';
  echo '<div class="wrap"><h1>Firewall Updates</h1><p>Security Lab only. Private GitHub releases; manual, administrator-initiated updates. No automatic blocking.</p>';
  if (isset($_GET['wfp_status'])) {
   $status = sanitize_key(wp_unslash($_GET['wfp_status']));
   if ($status === 'saved') { echo '<div class="notice notice-success"><p>Credential saved.</p></div>'; }
   if ($status === 'updated') { echo '<div class="notice notice-success"><p>Update installed. Verify the version below.</p></div>'; }
   if ($status === 'cleared') { echo '<div class="notice notice-success"><p>Credential removed.</p></div>'; }
  }
  echo '<p>GitHub credential: <strong>'.($configured ? 'configured' : 'not configured').'</strong></p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  wp_nonce_field('wfp_save_token');
  echo '<input type="hidden" name="action" value="wfp_save_token"><label for="wfp_token">Fine-grained GitHub token (Contents: read-only, this repository only)</label><p><input id="wfp_token" type="password" name="wfp_token" autocomplete="new-password" size="55" value="" placeholder="Paste new token"></p>';
  submit_button('Save credential', 'secondary', 'submit', false);
  echo ' <label><input type="checkbox" name="wfp_remove_token" value="1"> Remove stored credential</label></form>';
  if (!$configured) { echo '<p>Configure a credential to check for updates. A constant in wp-config.php also works and takes precedence.</p></div>'; return; }
  delete_site_transient(self::CACHE);
  $release = self::release();
  $version = get_plugin_data(WP_PLUGIN_DIR.'/'.self::FILE, false, false)['Version'] ?? 'unknown';
  echo '<p>Installed: <strong>'.esc_html($version).'</strong>; GitHub release: <strong>'.esc_html($release['version'] ?? 'unavailable').'</strong></p>';
  if (!$release || version_compare($release['version'], $version, '<=')) { echo '<p>No newer verified release metadata available.</p></div>'; return; }
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  wp_nonce_field('wfp_install_update');
  echo '<input type="hidden" name="action" value="wfp_install_update">';
  submit_button('Update Firewall from GitHub');
  echo '</form></div>';
 }
 public static function save_token() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_save_token');
  if (!empty($_POST['wfp_remove_token'])) {
   delete_option('wfp_encrypted_token_v1');
   delete_site_transient(self::CACHE);
   wp_safe_redirect(admin_url('tools.php?page=wfp-updates&wfp_status=cleared')); exit;
  }
  $token = isset($_POST['wfp_token']) && is_string($_POST['wfp_token']) ? trim(wp_unslash($_POST['wfp_token'])) : '';
  if (!preg_match('/^(github_pat_|ghp_)[A-Za-z0-9_]{20,}$/D', $token) || !function_exists('openssl_encrypt')) {
   wp_die('Invalid token format or encryption unavailable.');
  }
  $iv = random_bytes(12); $tag = '';
  $key = hash('sha256', wp_salt('auth').'wfp-github-token', true);
  $cipher = openssl_encrypt($token, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
  if ($cipher === false || strlen($tag) !== 16) { wp_die('Credential encryption failed.'); }
  $sealed = base64_encode($iv.$tag.$cipher);
  if (!update_option('wfp_encrypted_token_v1', $sealed, false) && get_option('wfp_encrypted_token_v1') !== $sealed) { wp_die('Credential could not be saved.'); }
  delete_site_transient(self::CACHE);
  wp_safe_redirect(admin_url('admin.php?page=wp-firewall&tab=settings&wfp_saved=updates')); exit;
 }
 public static function install_update() {
  if (!current_user_can('update_plugins') || !current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_install_update');
  $release = self::release();
  if (!$release) { wp_die('Release metadata unavailable.'); }
  if (!function_exists('get_plugin_data')) { require_once ABSPATH.'wp-admin/includes/plugin.php'; }
  $version = get_plugin_data(WP_PLUGIN_DIR.'/'.self::FILE, false, false)['Version'] ?? '0';
  if (version_compare($release['version'], $version, '<=')) { wp_die('No newer release is available.'); }
  require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/misc.php';
  // Let WordPress's standard plugin upgrader manage hooks and rollback behavior.
  $updates = get_site_transient('update_plugins');
  if (!is_object($updates)) { $updates = new stdClass(); }
  if (!isset($updates->checked) || !is_array($updates->checked)) { $updates->checked = []; }
  $updates->checked[self::FILE] = $version;
  $updates = self::updates($updates);
  set_site_transient('update_plugins', $updates, 5 * MINUTE_IN_SECONDS);
  $skin = new Automatic_Upgrader_Skin();
  $upgrader = new Plugin_Upgrader($skin);
  $result = $upgrader->upgrade(self::FILE);
  if (is_wp_error($result) || !$result) {
   wp_die('Firewall update failed. Review WordPress logs and restore the plugin backup if necessary.');
  }
  wp_clean_plugins_cache(true);
  wp_safe_redirect(admin_url('tools.php?page=wfp-updates&wfp_status=updated')); exit;
 }
 public static function updates($transient) {
  if (!is_object($transient)) { return $transient; }
  if (self::public_enabled() && isset($transient->response) && is_array($transient->response)) {
   unset($transient->response[self::FILE]);
  }
  if (!isset($transient->checked) || !is_array($transient->checked)) { $transient->checked = []; }
  if (empty($transient->checked[self::FILE])) {
   if (!function_exists('get_plugin_data')) { require_once ABSPATH.'wp-admin/includes/plugin.php'; }
   $installed = get_plugin_data(WP_PLUGIN_DIR.'/'.self::FILE, false, false);
   $transient->checked[self::FILE] = $installed['Version'] ?? '0';
  }
  $release = self::release();
  if (!$release || version_compare($release['version'], $transient->checked[self::FILE], '<=')) { return $transient; }
  if (!isset($transient->response) || !is_array($transient->response)) { $transient->response = []; }
  $transient->response[self::FILE] = (object) [
   'id' => 'https://github.com/'.self::REPO,
   'slug' => self::SLUG, 'plugin' => self::FILE,
   'new_version' => $release['version'],
   'version' => $release['version'],
   'url' => 'https://github.com/'.self::REPO,
   // This is an internal marker, NOT a URL with a credential.
   'package' => self::package_marker($release)
  ];
  return $transient;
 }
 public static function custom_update($update, $plugin_data, $plugin_file, $locales) {
  if ($plugin_file !== self::FILE) { return $update; }
  $release = self::release();
  if (!$release || version_compare($release['version'], $plugin_data['Version'] ?? '0', '<=')) { return false; }
  return ['id' => 'https://pebkac404.com/wp-firewall-prototype',
   'slug' => self::SLUG, 'version' => $release['version'],
   'url' => 'https://github.com/'.self::REPO,
   'package' => self::package_marker($release)];
 }
 public static function info($result, $action, $args) {
  if ($action !== 'plugin_information' || ($args->slug ?? '') !== self::SLUG) { return $result; }
  $release = self::release();
  if (!$release) { return $result; }
  return (object) [
   'name' => 'WP Firewall Prototype', 'slug' => self::SLUG,
   'version' => $release['version'], 'author' => 'PEBKAC404',
   'homepage' => 'https://github.com/'.self::REPO,
   'sections' => ['description' => 'Observation-only security research prototype.'],
   'download_link' => self::package_marker($release)
  ];
 }
 private static function asset($id) {
  $response = self::api('https://api.github.com/repos/'.self::REPO.'/releases/assets/'.$id, 'application/octet-stream');
  if (is_wp_error($response)) { return $response; }
  $status = wp_remote_retrieve_response_code($response);
  if ($status === 200) { return wp_remote_retrieve_body($response); }
  if (!in_array($status, [302, 307], true)) { return new WP_Error('wfp_asset', 'GitHub asset request failed'); }
  $location = wp_remote_retrieve_header($response, 'location');
  $parts = wp_parse_url($location);
  if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' ||
      !in_array($parts['host'] ?? '', ['release-assets.githubusercontent.com', 'objects.githubusercontent.com'], true)) {
   return new WP_Error('wfp_redirect', 'Unexpected asset download host');
  }
  // No Authorization header on the signed CDN URL.
  $cdn = wp_remote_get($location, ['timeout' => 45, 'redirection' => 0,
   'headers' => ['User-Agent' => 'WFP-WordPress-Updater']]);
  if (is_wp_error($cdn) || wp_remote_retrieve_response_code($cdn) !== 200) {
   return new WP_Error('wfp_cdn', 'Release asset download failed');
  }
  return wp_remote_retrieve_body($cdn);
 }
 public static function download($reply, $package, $upgrader, $hook_extra = []) {
  if (!is_string($package)) { return $reply; }
  if (strpos($package, 'wfp-public-release://') === 0) {
   if (!self::public_enabled() || !current_user_can('update_plugins') || ($hook_extra['plugin'] ?? '') !== self::FILE) {
    return new WP_Error('wfp_public_permission', 'Public Firewall update is unavailable for this request.');
   }
   return wfp_download_public_update(WFP_PUBLIC_UPDATES_ORIGIN, WFP_PUBLIC_UPDATES_KEY, self::public_channel(), self::installed_version(), $package);
  }
  if (strpos($package, 'wfp-private-release://') !== 0) { return $reply; }
  if (self::public_enabled()) { return new WP_Error('wfp_public_stale_offer', 'Refresh Firewall updates before installing.'); }
  if (!current_user_can('update_plugins')) { return new WP_Error('wfp_permission', 'Insufficient permissions'); }
  $release = self::release();
  if (!$release || $package !== 'wfp-private-release://'.$release['zip_id']) {
   return new WP_Error('wfp_mismatch', 'Requested release does not match approved metadata');
  }
  $checksum = self::asset($release['sum_id']);
  if (is_wp_error($checksum)) { return $checksum; }
  if (!is_string($checksum) || strlen($checksum) > 16384 || !preg_match('/^([a-f0-9]{64})\\s+\\*?wp-firewall-prototype\\.zip\\s*$/mi', $checksum, $match)) {
   return new WP_Error('wfp_checksum', 'Release checksum missing or invalid');
  }
  $bytes = self::asset($release['zip_id']);
  if (is_wp_error($bytes)) { return $bytes; }
  if (!is_string($bytes) || strlen($bytes) > 12 * 1024 * 1024 || substr($bytes, 0, 2) !== 'PK') {
   return new WP_Error('wfp_package', 'Release is not a valid-sized ZIP archive');
  }
  if (!hash_equals(strtolower($match[1]), hash('sha256', $bytes))) {
   return new WP_Error('wfp_integrity', 'Release ZIP failed SHA-256 verification');
  }
  $tmp = wp_tempnam('wfp-private-release.zip');
  if (!$tmp || file_put_contents($tmp, $bytes) !== strlen($bytes)) {
   return new WP_Error('wfp_temp', 'Could not write verified ZIP');
  }
  return $tmp;
 }
}
WFP_Private_Updates::init();
