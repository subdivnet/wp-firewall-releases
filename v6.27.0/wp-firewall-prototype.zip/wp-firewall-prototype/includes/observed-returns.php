<?php
if (!defined('ABSPATH')) { exit; }
/** Bounded observed absence/return evidence; callers supply protected keys and digests. */
final class WFP_Observed_Returns {
 const RETURN_WINDOW = 604800;
 const MAX_ABSENT = 2000;
 public static function returns($old, $current, $stamp) {
  $now = strtotime($stamp . ' UTC'); $cutoff = $now - self::RETURN_WINDOW;
  $prior = is_array($old) ? ($old['returns'] ?? null) : null;
  $valid = is_array($prior) && ($prior['schema'] ?? null) === 1 && ($prior['snapshot_time'] ?? '') === ($old['time'] ?? '')
   && WFP_State_Sanitizer::timestamp($prior['since'] ?? null) !== '' && $prior['since'] <= $old['time'] && $old['time'] <= $stamp
   && is_array($prior['absent'] ?? null) && count($prior['absent']) <= self::MAX_ABSENT;
  if ($valid) {
   $until = $prior['limited_until'] ?? null;
   if ($until !== null && (WFP_State_Sanitizer::timestamp($until) === '' || $until > gmdate('Y-m-d H:i:s', strtotime($old['time'] . ' UTC') + self::RETURN_WINDOW))) { $valid = false; }
   foreach ($prior['absent'] as $key => $row) {
    if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key) || !is_array($row)
     || !is_string($row['digest'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $row['digest'])
     || WFP_State_Sanitizer::timestamp($row['left_utc'] ?? null) === '' || $row['left_utc'] < $prior['since']
     || $row['left_utc'] > $old['time'] || isset($old['items'][$key])) { $valid = false; break; }
   }
  }
  $state = ['schema' => 1, 'since' => $valid ? $prior['since'] : $stamp, 'snapshot_time' => $stamp, 'limited_until' => null, 'absent' => []];
  if ($valid && ($prior['limited_until'] ?? '') >= $stamp) { $state['limited_until'] = $prior['limited_until']; }
  if ($valid) {
   foreach ($prior['absent'] as $key => $row) {
    if (strtotime($row['left_utc'] . ' UTC') >= $cutoff) { $state['absent'][$key] = ['digest' => $row['digest'], 'left_utc' => $row['left_utc']]; }
   }
  }
  $returned = $valid ? 0 : null; $matching = $valid ? 0 : null;
  foreach ($current as $key => $digest) {
   if (isset($state['absent'][$key])) {
    $returned++;
    if (hash_equals($state['absent'][$key]['digest'], $digest)) { $matching++; }
    unset($state['absent'][$key]);
   }
  }
  foreach ((is_array($old) ? ($old['items'] ?? []) : []) as $key => $digest) {
   if (!isset($current[$key])) { $state['absent'][$key] = ['digest' => $digest, 'left_utc' => $stamp]; }
  }
  // Keep the most recent departures; preserve the fact that coverage was truncated.
  uasort($state['absent'], function ($a, $b) { return strcmp($b['left_utc'], $a['left_utc']); });
  if (count($state['absent']) > self::MAX_ABSENT) {
   $state['absent'] = array_slice($state['absent'], 0, self::MAX_ABSENT, true);
   $state['limited_until'] = gmdate('Y-m-d H:i:s', $now + self::RETURN_WINDOW);
  }
  $status = !$valid ? ($prior === null ? 'started' : 'restarted') : ($state['limited_until'] !== null ? 'limited' : 'active');
  return ['state' => $state, 'return_tracking' => $status, 'reappeared_items' => $returned, 'matching_reappeared_items' => $matching];
 }
}
