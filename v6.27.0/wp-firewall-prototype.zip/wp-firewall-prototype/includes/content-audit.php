<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Administrator-requested metadata audit. Never reads titles, bodies, URLs,
 * usernames or email addresses, and never modifies content or observation state.
 */
final class WFP_Content_Audit {
 const LIMIT = 500;
 const WINDOW = 900;
 const BURST_THRESHOLD = 20;
 public static function run($now = null) {
  global $wpdb;
  $now = $now === null ? time() : (int) $now;
  $base = [
   'status' => 'unavailable',
   'checked_at_utc' => gmdate('Y-m-d H:i:s', $now),
   'scope' => 'Published posts, pages and products only. Metadata sample: newest 500 by ID. Recent-edit check: all eligible IDs, at most 500 matches reported.',
   'sample_limit' => self::LIMIT,
   'sampled_items' => 0,
   'metadata_sample_limited' => false,
   'missing_author_items' => 0,
   'invalid_modified_time_items' => 0,
   'future_modified_time_items' => 0,
   'recently_modified_items' => 0,
   'recent_count_limited' => false,
   'window_seconds' => self::WINDOW,
   'burst_threshold' => self::BURST_THRESHOLD,
   'bulk_change_review' => false,
   'meaning' => 'Findings require review; imports, migrations and planned edits can explain anomalies. Modification dates can be falsified. This is not a malware scan or a known-clean baseline.',
  ];
  if (!isset($wpdb) || !is_object($wpdb)) { return $base; }
  $previous = $wpdb->suppress_errors(true);
  try {
   // Fixed table identifiers originate from WordPress, never request parameters.
   $rows = $wpdb->get_results($wpdb->prepare(
    "SELECT (u.ID IS NULL) AS missing_author, p.post_modified_gmt
     FROM {$wpdb->posts} p LEFT JOIN {$wpdb->users} u ON p.post_author = u.ID
     WHERE p.post_status = %s AND p.post_type IN (%s, %s, %s)
     ORDER BY p.ID DESC LIMIT %d",
    'publish', 'post', 'page', 'product', self::LIMIT + 1
   ), ARRAY_A);
   if (!is_array($rows) || $wpdb->last_error !== '') { return $base; }
   // Independent query includes recently modified OLD content outside the ID sample.
   // Return constants only; individual content identifiers never enter the report.
   $recent = $wpdb->get_results($wpdb->prepare(
    "SELECT 1 AS matched_row FROM {$wpdb->posts}
     WHERE post_status = %s AND post_type IN (%s, %s, %s)
     AND post_modified_gmt >= %s AND post_modified_gmt <= %s LIMIT %d",
    'publish', 'post', 'page', 'product',
    gmdate('Y-m-d H:i:s', $now - self::WINDOW), gmdate('Y-m-d H:i:s', $now),
    self::LIMIT + 1
   ), ARRAY_A);
   if (!is_array($recent) || $wpdb->last_error !== '') { return $base; }
  } finally {
   $wpdb->suppress_errors($previous);
  }
  $base['status'] = 'completed';
  $base['metadata_sample_limited'] = count($rows) > self::LIMIT;
  $base['sampled_items'] = min(self::LIMIT, count($rows));
  foreach (array_slice($rows, 0, self::LIMIT) as $row) {
   if (!empty($row['missing_author'])) { $base['missing_author_items']++; }
   $stamp = WFP_State_Sanitizer::timestamp($row['post_modified_gmt'] ?? null);
   if ($stamp === '') { $base['invalid_modified_time_items']++; }
   elseif ($stamp > gmdate('Y-m-d H:i:s', $now)) { $base['future_modified_time_items']++; }
  }
  $base['recent_count_limited'] = count($recent) > self::LIMIT;
  $base['recently_modified_items'] = min(self::LIMIT, count($recent));
  $base['bulk_change_review'] = $base['recently_modified_items'] >= self::BURST_THRESHOLD;
  return $base;
 }
 public static function render($report) {
  echo '<h2>Content metadata audit</h2>';
  if ($report['status'] !== 'completed') {
   echo '<p>Audit unavailable: the database checks did not complete. No clean result can be inferred. Try again or ask your administrator to check database access.</p>';
   return;
  }
  echo '<p>Checked at '.esc_html($report['checked_at_utc']).' UTC. This report is not saved and does not alter content or security observations.</p>';
  echo '<ul><li>Newest published items examined: '.esc_html((string) $report['sampled_items']).($report['metadata_sample_limited'] ? ' (partial sample; older content remains unchecked)' : ' (all eligible items at query time)').'</li>';
  echo '<li>Items whose author account is missing: '.esc_html((string) $report['missing_author_items']).'</li>';
  echo '<li>Items with invalid or missing UTC modification dates: '.esc_html((string) $report['invalid_modified_time_items']).'</li>';
  echo '<li>Items with future UTC modification dates: '.esc_html((string) $report['future_modified_time_items']).'</li>';
  echo '<li>Published items modified in the last 15 minutes: '.($report['recent_count_limited'] ? 'at least ' : '').esc_html((string) $report['recently_modified_items']).'</li></ul>';
  if ($report['bulk_change_review']) {
   echo '<p><strong>Review recent bulk changes.</strong> At least 20 published items have modification dates in this 15-minute window. Confirm whether an import or planned maintenance explains this.</p>';
  }
  echo '<p>'.esc_html($report['scope']).'</p><p>'.esc_html($report['meaning']).' Zero findings do not establish that the site is clean. No alerts are sent by this manual audit.</p>';
 }
}
