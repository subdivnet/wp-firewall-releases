<?php
if (!defined('ABSPATH')) { exit; }
/** Selected uploads candidate content change detection. Local references are never called clean. */
require_once __DIR__ . '/observed-returns.php';
require_once __DIR__ . '/observed-reversions.php';
require_once __DIR__ . '/bulk-changes.php';
require_once __DIR__ . '/uploads-inventory.php';
final class WFP_Upload_Candidates {
 const REVISION = 1;
 const HOOK = 'wfp_upload_candidates_scan';
 const STATE = 'wfp_upload_candidate_fingerprints_v1';
 const REPORTS = 'wfp_upload_candidate_reports_v1';
 const LOCK = 'wfp_upload_candidate_lock_v1';
 const MAX_ITEMS = 2000;
 const MAX_DIRS = 2000;
 const MAX_DEPTH = 32;
 const MAX_PATH_BYTES = 4096;
 const MAX_ENTRIES = 20000;
 const MAX_ITEM_BYTES = 8388608;
 const MAX_BYTES = 67108864;
 const MAX_SECONDS = 5;
 public static function init() {
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::HOOK, [__CLASS__, 'scan']);
  add_action('admin_post_wfp_upload_candidates', [__CLASS__, 'manual']);
  add_action('admin_post_wfp_upload_candidate_preview', [__CLASS__, 'preview_manual']);
  if (function_exists('register_deactivation_hook')) { register_deactivation_hook(WFP_Observer::PLUGIN_FILE, [__CLASS__, 'deactivate']); }
 }
 public static function ensure_schedule() {
  $next = wp_next_scheduled(self::HOOK);
  if (!$next) { wp_schedule_event(time() + 60, 'hourly', self::HOOK); return; }
  $last = self::status()['latest'];
  if (isset($last['time_utc']) && ($last['scanner_revision'] ?? 1) !== self::REVISION && $next > time() + 660) { wp_schedule_single_event(time() + 60, self::HOOK); }
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); }
 public static function manual() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_upload_candidates');
  self::scan();
  wp_safe_redirect(admin_url('tools.php?page=wfp-observer')); exit;
 }
 public static function preview_manual() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_upload_candidate_preview'); $r = self::scan(true); nocache_headers();
  echo '<!doctype html><html><head><meta charset="utf-8"><title>Upload candidate change preview</title></head><body><main>';
  echo '<p><a href="' . esc_url(admin_url('tools.php?page=wfp-observer')) . '">Return to Firewall Observer</a></p>';
  echo '<h1>Upload candidate change preview</h1><p>Status: ' . esc_html(str_replace('_', ' ', $r['status'])) . '. The saved reference and scan history were not replaced.</p>';
  if ($r['status'] === 'compared') {
   echo '<p>Files checked: ' . esc_html((string) $r['files_checked']) . '; new: ' . esc_html((string) $r['new_files']) . '; changed: ' . esc_html((string) $r['changed_files']) . '; absent: ' . esc_html((string) $r['absent_files']) . '.</p>';
  }
  echo '<p>Up to 20 new/changed path examples from this preview only. Absent paths cannot be recovered from the protected reference. Initial references remain unverified; differences do not prove compromise. If a completed comparison already advanced the reference, this preview cannot reconstruct earlier filenames.</p>';
  foreach (($r['examples'] ?? []) as $row) { echo '<p><code>' . esc_html($row['file']) . '</code>: ' . esc_html($row['issue']) . '</p>'; }
  echo '</main></body></html>'; exit;
 }
 private static function unlock($lock) {
  global $wpdb;
  // Compare-and-delete only our own lock. A stale worker cannot delete a new lock.
  $wpdb->delete($wpdb->options, ['option_name' => self::LOCK, 'option_value' => maybe_serialize($lock)], ['%s', '%s']);
  wp_cache_delete(self::LOCK, 'options'); wp_cache_delete('notoptions', 'options');
 }
 private static function acquire() {
  $existing = get_option(self::LOCK, false);
  if ($existing !== false && (!is_array($existing) || !isset($existing['token'], $existing['expires'])
   || !is_string($existing['token']) || !preg_match('/^[a-f0-9]{32}$/D', $existing['token'])
   || !is_int($existing['expires']) || $existing['expires'] < time())) { self::unlock($existing); }
  $lock = ['token' => bin2hex(random_bytes(16)), 'expires' => time() + 120];
  return add_option(self::LOCK, $lock, '', false) ? $lock : false;
 }
 public static function valid_state($state, $key_id) {
  if (!is_array($state) || ($state['schema'] ?? null) !== 1 || ($state['key_id'] ?? '') !== $key_id
   || WFP_State_Sanitizer::timestamp($state['time'] ?? null) === '' || $state['time'] > gmdate('Y-m-d H:i:s')
   || !isset($state['items']) || !is_array($state['items']) || count($state['items']) > self::MAX_ITEMS) { return false; }
  foreach ($state['items'] as $key => $digest) {
   if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key) || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) { return false; }
  }
  return true;
 }
 private static function roots() {
  $uploads = function_exists('wp_get_upload_dir') ? wp_get_upload_dir() : false;
  $root = is_array($uploads) ? ($uploads['basedir'] ?? null) : null;
  if (!is_string($root) || strlen($root) === 0 || strlen($root) > self::MAX_PATH_BYTES || !empty($uploads['error'])
   || strpos($root, "\0") !== false || strpos($root, '://') !== false || substr($root, 0, 2) === '\\\\'
   || !($root[0] === '/' || (DIRECTORY_SEPARATOR === '\\' && preg_match('/^[A-Za-z]:/', $root) && in_array(substr($root, 2, 1), ['\\','/'], true)))) { return false; }
  $resolved = realpath($root);
  if ($resolved !== false && ($resolved === dirname($resolved) || $resolved === realpath(ABSPATH)
   || (defined('WP_CONTENT_DIR') && $resolved === realpath(WP_CONTENT_DIR)))) { return false; }
  return ['uploads' => $root];
 }
 private static function plain_path($path) {
  $cursor = $path;
  while (true) {
   clearstatcache(true, $cursor);
   if (is_link($cursor)) { return false; }
   $parent = dirname($cursor);
   if ($parent === $cursor || $cursor === '.' || $cursor === '') { break; }
   $cursor = $parent;
  }
  return true;
 }
 private static function same_file($a, $b) {
  if (!is_array($a) || !is_array($b)) { return false; }
  foreach (['dev','ino','mode','size','mtime','ctime'] as $key) {
   if (!isset($a[$key], $b[$key]) || $a[$key] !== $b[$key]) { return false; }
  }
  return true;
 }
 private static function capture($roots, $secret, &$bytes, $start, &$status, &$paths, &$reason, &$files, &$visited) {
  $items = []; $entries = 0; $directories = 0; $stack = [];
  foreach ($roots as $label => $root) {
   if (!is_string($root)) { $status = 'unavailable'; $reason = 'root_unavailable'; return false; }
   if (!self::plain_path($root)) { $status = 'partial'; $reason = 'path_link'; return false; }
   if (!file_exists($root) && $label === 'mu-plugins') { continue; }
   if (!is_dir($root) || !is_readable($root)) { $status = 'unavailable'; $reason = 'root_unavailable'; return false; }
   $resolved = realpath($root);
   if ($resolved === false) { $status = 'unavailable'; $reason = 'root_unavailable'; return false; }
   $stack[] = [$label, rtrim($resolved, '/\\'), ''];
  }
  try {
   while ($stack) {
    if (microtime(true) - $start >= self::MAX_SECONDS) { $status = 'partial'; $reason = 'time_limit'; return false; }
    list($label, $root, $relative) = array_pop($stack);
    $dir = $root . ($relative === '' ? '' : '/' . $relative);
    if (!self::plain_path($dir)) { $status = 'partial'; $reason = 'path_link'; return false; }
    if (!is_readable($dir)) { $status = 'partial'; $reason = 'directory_unreadable'; return false; }
    if (++$directories > self::MAX_DIRS) { $status = 'partial'; $reason = 'directory_limit'; return false; }
    $iterator = new DirectoryIterator($dir);
    foreach ($iterator as $entry) {
     if ($entry->isDot()) { continue; }
     $entries++; $visited = min($entries, self::MAX_ENTRIES);
     if ($entries > self::MAX_ENTRIES) { $status = 'partial'; $reason = 'entry_limit'; return false; }
     if (microtime(true) - $start >= self::MAX_SECONDS) { $status = 'partial'; $reason = 'time_limit'; return false; }
     $name = $entry->getFilename();
     $rel = ($relative === '' ? '' : $relative . '/') . $name;
     $path = $root . '/' . $rel;
     if (strlen($path) > self::MAX_PATH_BYTES) { $status = 'partial'; $reason = 'path_limit'; return false; }
     if (!self::plain_path($path)) { $status = 'partial'; $reason = 'path_link'; return false; }
     $before = @lstat($path);
     if (!is_array($before)) { $status = 'unavailable'; $reason = 'file_metadata_unavailable'; return false; }
     $kind = $before['mode'] & 0170000;
     if ($kind === 0040000) {
      if (substr_count($rel, '/') >= self::MAX_DEPTH || count($stack) >= self::MAX_DIRS) { $status = 'partial'; $reason = 'directory_limit'; return false; }
      $stack[] = [$label, $root, $rel]; continue;
     }
     if ($kind !== 0100000) { $status = 'partial'; $reason = 'special_file'; return false; }
     if (WFP_Uploads_Inventory::category($name) === '') { continue; }
     if (($before['nlink'] ?? 1) > 1) { $status = 'partial'; $reason = 'hard_link'; return false; }
     $size = $before['size'];
     if (!is_int($size) || $size < 0) { $status = 'unavailable'; $reason = 'invalid_file_metadata'; return false; }
     if ($size > self::MAX_ITEM_BYTES) { $status = 'partial'; $reason = 'single_file_byte_limit'; return false; }
     if (count($items) >= self::MAX_ITEMS) { $status = 'partial'; $reason = 'file_limit'; return false; }
     if ($bytes + $size > self::MAX_BYTES) { $status = 'partial'; $reason = 'total_byte_limit'; return false; }
     $handle = @fopen($path, 'rb');
     if (!$handle) { $status = 'unavailable'; $reason = 'file_unreadable'; return false; }
     try {
      if (!self::same_file($before, fstat($handle))) { $status = 'unstable'; $reason = 'changed_during_scan'; return false; }
      $context = hash_init('sha256');
      // Read at most the preflight size plus a sentinel byte; growth cannot bypass the byte cap.
      $read = hash_update_stream($context, $handle, $size + 1);
      $after = fstat($handle);
      clearstatcache(true, $path);
      if ($read !== $size || !self::same_file($before, $after) || !self::same_file($before, @lstat($path))
       || !self::plain_path($path)) { $status = 'unstable'; $reason = 'changed_during_scan'; return false; }
      $bytes += $read;
      $key = hash_hmac('sha256', $label . ':' . $rel, $secret);
      if (is_array($paths)) { $paths[$key] = $label . '/' . $rel; }
      $items[$key] = hash_hmac('sha256', hash_final($context), $secret); $files = count($items);
     } finally { fclose($handle); }
    }
   }
  } catch (UnexpectedValueException $e) { $status = 'unavailable'; $reason = 'directory_unreadable'; return false; }
  ksort($items, SORT_STRING);
  return $items;
 }
 public static function scan($preview = false) {
  global $wpdb;
  $report = ['reversion_tracking'=>'not_tracked', 'reversion_tracking_since_utc'=>null, 'reverted_files'=>null, 'return_tracking' => 'not_tracked', 'return_tracking_since_utc' => null, 'reappeared_files' => null, 'matching_reappeared_files' => null, 'scanner_revision' => self::REVISION, 'completion_reason' => 'root_unavailable', 'first_pass_files' => 0, 'second_pass_files' => 0, 'first_pass_entries' => 0, 'second_pass_entries' => 0, 'file_bytes_hashed' => 0, 'status' => 'unavailable', 'time_utc' => gmdate('Y-m-d H:i:s'), 'files_checked' => 0, 'new_files' => null, 'changed_files' => null, 'absent_files' => null];
  $preview = $preview === true;
  $bytes = 0;
  $finish = function ($r) use ($preview, &$bytes, &$lock) {
   $r['file_bytes_hashed'] = $bytes;
   if ($r['status'] !== 'compared') { $r['previous_files'] = null; $r['previous_time_utc'] = null; }
   $r['bulk_assessment'] = WFP_Bulk_Changes::files($r, self::MAX_ITEMS);
   if (get_option(self::LOCK, false) !== $lock || $lock['expires'] < time()) { $r['status'] = 'busy'; $r['completion_reason'] = 'scan_in_progress'; $r['reversion_tracking']='not_tracked'; $r['reversion_tracking_since_utc']=null; $r['reverted_files']=null; $r['previous_files'] = null; $r['previous_time_utc'] = null; $r['bulk_assessment'] = WFP_Bulk_Changes::files($r, self::MAX_ITEMS); return $r; }
   return $preview ? $r : self::remember($r);
  };
  $paths = $preview ? [] : null;
  $lock = self::acquire();
  if (!$lock) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return $report; }
  $previous_errors = $wpdb->suppress_errors(true);
  try {
   $roots = self::roots(); $bytes = 0; $start = microtime(true); $status = 'unavailable'; $reason = 'root_unavailable';
   if ($roots === false) { return $finish($report); }
   $scope = realpath($roots['uploads']); if ($scope === false) { $scope = $roots['uploads']; }
   $secret = hash_hmac('sha256', 'wfp-upload-candidate-reference-v1:' . $scope, wp_salt('auth'), true);
   $key_id = hash_hmac('sha256', 'reference-key-check', $secret);
   $first = self::capture($roots, $secret, $bytes, $start, $status, $paths, $reason, $report['first_pass_files'], $report['first_pass_entries']);
   if ($first === false) { $report['status'] = $status; $report['completion_reason'] = $reason; return $finish($report); }
   $second = self::capture($roots, $secret, $bytes, $start, $status, $paths, $reason, $report['second_pass_files'], $report['second_pass_entries']);
   if ($second === false) { $report['status'] = $status; $report['completion_reason'] = $reason; return $finish($report); }
   if ($first !== $second) { $report['status'] = 'unstable'; $report['completion_reason'] = 'changed_during_scan'; return $finish($report); }
   if (get_option(self::LOCK, false) !== $lock || $lock['expires'] < time()) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return $report; }
   if (microtime(true) - $start >= self::MAX_SECONDS) { $report['status'] = 'partial'; $report['completion_reason'] = 'time_limit'; return $finish($report); }
   $report['files_checked'] = count($second); $report['completion_reason'] = 'none'; $report['file_bytes_hashed'] = $bytes;
   $old = get_option(self::STATE, false);
   if (self::valid_state($old, $key_id)) {
    $report['status'] = 'compared';
    $report['previous_files'] = count($old['items']); $report['previous_time_utc'] = $old['time'];
    $report['new_files'] = 0; $report['changed_files'] = 0; $report['absent_files'] = 0;
    foreach ($second as $key => $value) {
     if (!isset($old['items'][$key])) { $report['new_files']++; }
     elseif (!hash_equals($old['items'][$key], $value)) { $report['changed_files']++; }
    }
    foreach ($old['items'] as $key => $value) { if (!isset($second[$key])) { $report['absent_files']++; } }
   } else {
    $report['status'] = $old === false ? 'reference_created' : 'reference_reinitialized';
   }
   if ($preview) {
    if ($report['status'] !== 'compared') { $report['status'] = 'no_valid_reference'; $report['completion_reason'] = 'no_valid_reference'; }
    $report['examples'] = [];
    if ($report['status'] === 'compared') {
     foreach ($second as $key => $value) {
      $issue = !isset($old['items'][$key]) ? 'new' : (!hash_equals($old['items'][$key], $value) ? 'changed' : '');
      if ($issue !== '' && count($report['examples']) < 20) { $report['examples'][] = ['file' => $paths[$key], 'issue' => $issue]; }
     }
    }
    return $report;
   }
   $returns = WFP_Observed_Returns::returns($report['status'] === 'compared' ? $old : false, $second, $report['time_utc']);
   $report['return_tracking'] = $returns['return_tracking'];
   $report['return_tracking_since_utc'] = $returns['state']['since'];
   $report['reappeared_files'] = $returns['reappeared_items']; $report['matching_reappeared_files'] = $returns['matching_reappeared_items'];
   $reversions = WFP_Observed_Reversions::observe($report['status'] === 'compared' ? $old : false, $second, $report['time_utc']);
   foreach (['reversion_tracking','reversion_tracking_since_utc','reverted_files'] as $field) { $report[$field] = $reversions[$field]; }
   $next = ['schema' => 1, 'key_id' => $key_id, 'time' => $report['time_utc'], 'items' => $second, 'returns' => $returns['state'], 'reversions' => $reversions['state']];
   if (get_option(self::LOCK, false) !== $lock || $lock['expires'] < time()) { return $finish($report); }
   update_option(self::STATE, $next, false);
   if (get_option(self::STATE, false) !== $next) {
    $report['status'] = 'unavailable'; $report['completion_reason'] = 'reference_storage_unavailable';
    $report['reversion_tracking']='not_tracked'; $report['reversion_tracking_since_utc']=null; $report['reverted_files']=null;
    $report['return_tracking'] = 'not_tracked'; $report['return_tracking_since_utc'] = null; $report['reappeared_files'] = null; $report['matching_reappeared_files'] = null;
    $report['new_files'] = null; $report['changed_files'] = null; $report['absent_files'] = null;
   }
   return $finish($report);
  } finally {
   $wpdb->suppress_errors($previous_errors); self::unlock($lock);
  }
 }
 public static function clean_report($raw) {
  if (!is_array($raw) || !in_array($raw['status'] ?? '', ['compared','reference_created','reference_reinitialized','partial','unavailable','unstable'], true)) { return false; }
  $time = WFP_State_Sanitizer::timestamp($raw['time_utc'] ?? null);
  if ($time === '' || $time > gmdate('Y-m-d H:i:s')) { return false; }
  $safe = ['status' => $raw['status'], 'time_utc' => $time];
  foreach (['files_checked','new_files','changed_files','absent_files'] as $key) {
   if ($key !== 'files_checked' && $raw['status'] !== 'compared') { $safe[$key] = null; continue; }
   $value = $raw[$key] ?? null;
   if (!is_int($value) || $value < 0 || $value > self::MAX_ITEMS) { return false; }
   $safe[$key] = $value;
  }
  if ($safe['status'] === 'compared' && $safe['new_files'] + $safe['changed_files'] > $safe['files_checked']) { return false; }
  $safe['previous_files'] = null; $safe['previous_time_utc'] = null;
  if ($safe['status'] === 'compared' && (($raw['previous_files'] ?? null) !== null || ($raw['previous_time_utc'] ?? null) !== null)) {
   $previous = $raw['previous_files'] ?? null; $previous_time = WFP_State_Sanitizer::timestamp($raw['previous_time_utc'] ?? null);
   if (!is_int($previous) || $previous < 0 || $previous > self::MAX_ITEMS || $previous_time === '' || $previous_time > $time
    || $previous !== $safe['files_checked'] - $safe['new_files'] + $safe['absent_files']) { return false; }
   $safe['previous_files'] = $previous; $safe['previous_time_utc'] = $previous_time;
  }
  $safe['bulk_assessment'] = WFP_Bulk_Changes::files($safe, self::MAX_ITEMS);
  $revision = $raw['scanner_revision'] ?? 1;
  if (!is_int($revision) || $revision < 1 || $revision > self::REVISION) { return false; }
  $reason = $raw['completion_reason'] ?? 'legacy_unknown';
  if (!is_string($reason) || !array_key_exists($reason, self::reason_labels())) { return false; }
  $safe['scanner_revision'] = $revision; $safe['completion_reason'] = $reason;
  foreach (['first_pass_files','second_pass_files','first_pass_entries','second_pass_entries','file_bytes_hashed'] as $field) {
   $value = $raw[$field] ?? null;
   $max = $field === 'file_bytes_hashed' ? self::MAX_BYTES : (strpos($field, 'entries') !== false ? self::MAX_ENTRIES : self::MAX_ITEMS);
   if ($value !== null && (!is_int($value) || $value < 0 || $value > $max)) { return false; }
   if ($reason !== 'legacy_unknown' && $value === null) { return false; }
   $safe[$field] = $value;
  }
  if ($reason !== 'legacy_unknown') {
   $complete = in_array($safe['status'], ['compared','reference_created','reference_reinitialized'], true);
   if ($complete && ($reason !== 'none' || $safe['first_pass_files'] !== $safe['files_checked'] || $safe['second_pass_files'] !== $safe['files_checked'])) { return false; }
   if (!$complete && $reason === 'none') { return false; }
   if ($safe['first_pass_files'] > $safe['first_pass_entries'] || $safe['second_pass_files'] > $safe['second_pass_entries']) { return false; }
  }
  $tracking = $raw['return_tracking'] ?? 'not_tracked';
  if (!in_array($tracking, ['not_tracked','started','restarted','active','limited'], true)) { return false; }
  $since = $raw['return_tracking_since_utc'] ?? null;
  if ($tracking === 'not_tracked') { if ($since !== null) { return false; } }
  elseif (!in_array($safe['status'], ['compared','reference_created','reference_reinitialized'], true)
   || WFP_State_Sanitizer::timestamp($since) === '' || $since > $time) { return false; }
  $safe['return_tracking'] = $tracking; $safe['return_tracking_since_utc'] = $since;
  foreach (['reappeared_files','matching_reappeared_files'] as $field) {
   $value = $raw[$field] ?? null;
   if (in_array($tracking, ['active','limited'], true)) {
    if ($safe['status'] !== 'compared' || !is_int($value) || $value < 0 || $value > $safe['new_files']) { return false; }
   } elseif ($value !== null) { return false; }
   $safe[$field] = $value;
  }
  if ($safe['matching_reappeared_files'] !== null && $safe['matching_reappeared_files'] > $safe['reappeared_files']) { return false; }
  return WFP_Observed_Reversions::clean_fields($raw, $safe);
 }
 public static function history() {
  $rows = get_option(self::REPORTS, []);
  if (!is_array($rows)) { return []; }
  $safe = [];
  foreach (array_slice($rows, 0, 48) as $row) {
   $clean = self::clean_report($row);
   if ($clean !== false) { $safe[] = $clean; }
  }
  // Preserve stored newest-first order for scans sharing one timestamp on PHP7.4 too.
  $ranked = [];
  foreach ($safe as $index => $row) { $ranked[] = ['row' => $row, 'index' => $index]; }
  usort($ranked, function ($a, $b) { return strcmp($b['row']['time_utc'], $a['row']['time_utc']) ?: ($a['index'] <=> $b['index']); });
  return array_column(array_slice($ranked, 0, 24), 'row');
 }
 private static function remember($report) {
  $rows = self::history(); array_unshift($rows, self::clean_report($report));
  update_option(self::REPORTS, array_slice($rows, 0, 24), false);
  return $report;
 }
 public static function status() {
  $history = self::history();
  return [
   'latest' => $history ? $history[0] : ['status' => 'not_run'],
   'history' => $history,
   'bulk_review' => array_values(array_filter($history, function ($r) { return $r['bulk_assessment']['status'] === 'review'; })),
   'reversion_review' => array_values(array_filter($history, function ($r) { return ($r['reverted_files'] ?? 0) > 0; })),
   'return_review' => array_values(array_filter($history, function ($r) { return ($r['reappeared_files'] ?? 0) > 0; })),
   'reference_trust' => 'Unverified observed starting state; never a known-clean baseline.',
   'scope' => 'Only script-like and configuration filenames selected by the separate uploads inventory rules, under the configured local uploads directory. Selected file contents are read in bounded streams and only site/root-keyed path and content fingerprints are saved. Ordinary media contents are not opened. No readable paths or file contents are retained. A name match or returning fingerprint is not a malware verdict; legitimate index.php, configurations, restores and reinstallations can explain observations. Extensionless code, code hidden in ordinary media and files outside this scope are not covered.',
   'limits' => 'Up to 2000 selected files, 20000 directory entries and 2000 directories per pass, depth 32, path length 4096 bytes, 8 MiB per selected file, 64 MiB across two observed passes and a five-second between-operation budget. Symlinks, hard links and special files cause partial results. Partial, failed or unstable scans never replace the reference.',
  ];
 }
 public static function reason_labels() {
  return ['none' => 'Complete scan', 'legacy_unknown' => 'Earlier scan: coverage details unavailable',
   'root_unavailable' => 'A required scan directory is unavailable', 'path_link' => 'A symbolic link was not followed',
   'directory_unreadable' => 'A directory could not be read', 'file_metadata_unavailable' => 'File metadata could not be read',
   'invalid_file_metadata' => 'File metadata was invalid', 'special_file' => 'A special file was not read', 'hard_link' => 'A hard link was not read',
   'single_file_byte_limit' => 'A file exceeds the size limit', 'file_limit' => 'File count limit reached',
   'directory_limit' => 'Directory count or depth limit reached', 'path_limit' => 'Path length limit reached',
   'entry_limit' => 'Directory entry limit reached', 'total_byte_limit' => 'Total file-size budget reached',
   'file_unreadable' => 'A file could not be opened', 'changed_during_scan' => 'Files changed during verification',
   'time_limit' => 'Processing-time budget reached', 'reference_storage_unavailable' => 'Reference could not be saved'];
 }
 private static function coverage_html($r) {
  if (!isset($r['completion_reason'])) { return; }
  echo '<p>Coverage: <strong>'.esc_html(self::reason_labels()[$r['completion_reason']]).'</strong>.';
  if ($r['first_pass_files'] !== null) { echo ' Fingerprints completed in each pass: '.esc_html((string) $r['first_pass_files']).' / '.esc_html((string) $r['second_pass_files']).'. Entries examined: '.esc_html((string) $r['first_pass_entries']).' / '.esc_html((string) $r['second_pass_entries']).'. These are scan progress counts, not changed-file counts.'; }
  echo '</p>';
 }
 public static function render() {
  $status = self::status(); $r = $status['latest'];
  echo '<h2>Upload candidate fingerprints and returns</h2><p>Last result: <strong>'.esc_html(str_replace('_', ' ', $r['status'])).'</strong>';
  if (isset($r['time_utc'])) { echo ' at '.esc_html($r['time_utc']).' UTC'; }
  echo '.</p>';
  if ($r['status'] === 'compared') {
   echo '<p>Files checked: '.esc_html((string) $r['files_checked']).'; new: '.esc_html((string) $r['new_files']).'; changed: '.esc_html((string) $r['changed_files']).'; absent: '.esc_html((string) $r['absent_files']).'.</p>';
  }
  if (isset($r['return_tracking'])) {
   echo '<p>File return tracking: <strong>'.esc_html(str_replace('_', ' ', $r['return_tracking'])).'</strong>';
   if ($r['return_tracking_since_utc'] !== null) { echo '; observed since '.esc_html($r['return_tracking_since_utc']).' UTC'; }
   if ($r['reappeared_files'] !== null) { echo '; previously absent paths returned: '.esc_html((string) $r['reappeared_files']).'; matching earlier contents: '.esc_html((string) $r['matching_reappeared_files']); }
   echo '.</p>';
  }
  WFP_Bulk_Changes::render_files($status);
  WFP_Observed_Reversions::render($status);
  foreach ($status['return_review'] as $review) {
   echo '<p><strong>Previously observed file returns to review</strong> at '.esc_html($review['time_utc']).' UTC: '.esc_html((string) $review['reappeared_files']).' returned paths, '.esc_html((string) $review['matching_reappeared_files']).' with matching earlier content fingerprints. Restores and reinstallations can explain this; it is not proof of reinfection.</p>';
  }
  echo '<details><summary>How file return tracking works</summary><p>Only the same protected scoped path observed absent in one complete scan and present in a later complete scan within seven days can be linked. Returns are part of new-file counts, not additional changed files. Matching content fingerprints do not identify malware. Renamed paths, other scopes and changes between scans are not linked. Up to 2000 absent-path fingerprints are retained without readable filenames or file contents. Expired evidence is discarded on a complete comparison; limited tracking can miss returns. Tracking starts at the displayed time; no earlier history is reconstructed. Initial references remain unverified. Review summaries remain among the last 24 reports when later scans are quiet. Previews do not advance tracking.</p></details>';
  self::coverage_html($r);
  echo '<p>'.esc_html($status['reference_trust']).' Comparisons are against the preceding complete snapshot, not proof of compromise or successful cleanup. Absent means a previously observed path was not found. Installation, updates, renames and removal can explain differences. Existing malware may be included in the initial reference; this does not check vendor packages or malware signatures.</p>';
  echo '<p>'.esc_html($status['scope']).'</p><p>'.esc_html($status['limits']).' Automatic checks depend on WordPress cron. No automatic alerts, file edits or deletions occur.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_upload_candidates">';
  wp_nonce_field('wfp_upload_candidates'); submit_button('Compare upload candidates now', 'secondary'); echo '</form>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_upload_candidate_preview">';
  wp_nonce_field('wfp_upload_candidate_preview'); submit_button('Preview changed upload candidates without advancing reference', 'secondary'); echo '</form>';
  if ($status['history']) {
   echo '<details><summary>Show upload candidate comparison history</summary><table class="widefat striped"><thead><tr><th>UTC time</th><th>Result</th><th>Coverage</th><th>New</th><th>Changed</th><th>Absent</th><th>Returned</th><th>Matching return</th><th>Reversions</th><th>Tracking</th><th>Bulk review</th></tr></thead><tbody>';
   foreach ($status['history'] as $row) {
    echo '<tr><td>'.esc_html($row['time_utc']).'</td><td>'.esc_html(str_replace('_', ' ', $row['status'])).'</td><td>'.esc_html(self::reason_labels()[$row['completion_reason']]).'</td>';
    foreach (['new_files','changed_files','absent_files','reappeared_files','matching_reappeared_files','reverted_files'] as $key) { echo '<td>'.esc_html($row[$key] === null ? 'Not compared' : (string) $row[$key]).'</td>'; }
    echo '<td>'.esc_html(str_replace('_', ' ', $row['return_tracking'])).'</td><td>'.esc_html(str_replace('_', ' ', $row['bulk_assessment']['status'])).'</td></tr>';
   }
   echo '</tbody></table></details>';
  }
 }
}
