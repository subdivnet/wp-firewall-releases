<?php
/** Bounded selected-record matcher; callers stream the full feed separately. */
final class WFP_Wordfence_Local {
    const MAX_BYTES = 2097152;
    const MAX_RECORDS = 50000;
    const MAX_COMPARISONS = 200000;
    const MAX_FINDINGS = 200;

    private static function text($v, $limit = 8192) {
        return is_string($v) && $v !== '' && strlen($v) <= $limit &&
            preg_match('//u', $v) === 1 && !preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $v);
    }

    private static function version($v) {
        // Deliberately conservative: unsupported vendor schemes stay unknown.
        return is_string($v) && strlen($v) <= 64 &&
            preg_match('/\A[0-9]+(?:[._+-][0-9]+){0,15}(?:[._+-]?(?:alpha|a|beta|b|RC|rc|dev|pl|p)(?:[._+-]?[0-9]+)?)?\z/D', $v) === 1;
    }

    private static function identity($v) {
        // Exact, case-preserving lookup token, never a filesystem path or a URL.
        return is_string($v) && strlen($v) <= 200 && preg_match('/\A[A-Za-z0-9][A-Za-z0-9._-]*\z/D', $v) === 1;
    }

    /** Fixed diagnostic categories only; never return rejected provider values or observed identities. */
    public static function rejection_reasons($r) {
        if (!is_array($r) || !isset($r['id'],$r['title'],$r['software'],$r['informational']) ||
            !is_string($r['id']) || !self::text($r['title'],1024) || !is_bool($r['informational']) ||
            !is_array($r['software']) || !$r['software'] || count($r['software'])>256 ||
            (array_key_exists('cve',$r) && !self::cve($r['cve']))) return ['record_shape'];
        if ($r['informational']) return [];
        $reasons=[];
        if (self::attribution($r)===null) $reasons['attribution']=true;
        if (!isset($r['references']) || !is_array($r['references']) || count($r['references'])>256) $reasons['references']=true;
        else { $link=false; foreach($r['references'] as $ref) { if(self::link($ref,true)) {$link=true;break;} } if(!$link)$reasons['advisory_link']=true; }
        foreach($r['software'] as $software) {
            if(!is_array($software)) {$reasons['software_shape']=true;continue;}
            if(!in_array($software['type']??null,['core','plugin','theme'],true))$reasons['component_type']=true;
            if(!self::identity($software['slug']??null))$reasons['component_identity']=true;
            $ranges=$software['affected_versions']??null;
            if(!is_array($ranges)||!$ranges||count($ranges)>128){$reasons['version_range']=true;continue;}
            foreach($ranges as $range){if(self::range('0',$range)===null)$reasons['version_range']=true;}
        }
        return array_keys($reasons);
    }

    private static function reject(&$out,$record) {
        $out['rejected_records']++;$out['status']='PARTIAL';
        $reasons=self::rejection_reasons($record);
        if(!$reasons)$reasons=['record_admission'];
        foreach($reasons as $reason)$out['rejection_reasons'][$reason]=($out['rejection_reasons'][$reason]??0)+1;
    }

    private static function cve($v) {
        return $v === null || (is_string($v) && strlen($v) <= 32 && preg_match('/\ACVE-[0-9]{4}-[0-9]{4,}\z/D', $v) === 1);
    }

    private static function link($v, $record = false) {
        if (!self::text($v, 2048)) return false;
        $p = parse_url($v);
        if (!$p || !isset($p['scheme'], $p['host']) || $p['scheme'] !== 'https' ||
            isset($p['user']) || isset($p['pass']) || isset($p['port']) ||
            (!$record && isset($p['query'])) || isset($p['fragment'])) return false;
        if ($record) return $p['host'] === 'www.wordfence.com' && isset($p['path']) &&
            strpos($p['path'], '/threat-intel/vulnerabilities/') === 0;
        return in_array($p['host'], ['www.wordfence.com', 'www.cve.org', 'cve.mitre.org'], true);
    }

    private static function attribution($r) {
        if (!isset($r['copyrights']) || !is_array($r['copyrights'])) return null;
        $c = $r['copyrights'];
        if (!isset($c['message'], $c['defiant']) || count($c) > 17 || !self::text($c['message'])) return null;
        $out = ['message' => $c['message'], 'holders' => []];
        foreach ($c as $holder => $entry) {
            if ($holder === 'message') continue;
            if (!self::identity($holder) || !is_array($entry) ||
                !isset($entry['notice'], $entry['license'], $entry['license_url']) ||
                !self::text($entry['notice']) || !self::text($entry['license'], 32768) ||
                !self::link($entry['license_url'])) return null;
            $out['holders'][$holder] = ['notice' => $entry['notice'],
                'license' => $entry['license'], 'license_url' => $entry['license_url']];
        }
        if (isset($r['cve']) && $r['cve'] !== null && $r['cve'] !== '' && !isset($out['holders']['mitre'])) return null;
        return $out;
    }

    private static function range($version, $range) {
        if (!is_array($range) || !isset($range['from_version'], $range['to_version'],
            $range['from_inclusive'], $range['to_inclusive']) ||
            !is_bool($range['from_inclusive']) || !is_bool($range['to_inclusive'])) return null;
        $from = $range['from_version']; $to = $range['to_version'];
        if (($from !== '*' && !self::version($from)) || ($to !== '*' && !self::version($to))) return null;
        if ($from !== '*' && $to !== '*' && version_compare($from, $to, '>')) return null;
        return ($from === '*' || version_compare($version, $from, $range['from_inclusive'] ? '>=' : '>')) &&
            ($to === '*' || version_compare($version, $to, $range['to_inclusive'] ? '<=' : '<'));
    }

    public static function match_json($json, $inventory) {
        $out = ['status' => 'UNAVAILABLE', 'findings' => [], 'unknown_components' => [], 'rejected_records' => 0, 'rejection_reasons' => []];
        if (!is_string($json) || strlen($json) > self::MAX_BYTES || !is_array($inventory) || count($inventory) > 2000) return $out;
        // Require an object root, not a list or scalar; bounded depth limits hostile input.
        $root = json_decode($json, false, 32);
        if (json_last_error() !== JSON_ERROR_NONE || !is_object($root)) return $out;
        unset($root);
        $data = json_decode($json, true, 32);
        if (!is_array($data) || !$data || count($data) > self::MAX_RECORDS) return $out;
        $out['status'] = 'COMPLETE';
        $work = 0;
        // Build type/slug lookup once; unrelated inventory must not rescan the entire feed.
        $index = [];
        foreach ($data as $id => $r) {
            if (++$work > self::MAX_COMPARISONS) { $out['status'] = 'PARTIAL'; break; }
            if (!is_string($id) || preg_match('/\A[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\z/D', $id) !== 1 ||
                !is_array($r) || !isset($r['id'], $r['title'], $r['software'], $r['informational']) ||
                $r['id'] !== $id || !self::text($r['title'], 1024) || !is_array($r['software']) ||
                !$r['software'] || count($r['software']) > 256 || !is_bool($r['informational']) ||
                (array_key_exists('cve', $r) && !self::cve($r['cve']))) {
                self::reject($out,$r); continue;
            }
            if ($r['informational']) continue;
            $valid_record = self::attribution($r) !== null && isset($r['references']) &&
                is_array($r['references']) && count($r['references']) <= 256;
            if (!$valid_record) { self::reject($out,$r); continue; }
            $has_link = false;
            foreach (isset($r['references']) && is_array($r['references']) ? $r['references'] : [] as $ref) {
                if (self::link($ref, true)) { $has_link = true; break; }
            }
            if (!$valid_record || !$has_link) {
                self::reject($out,$r); continue;
            }
            $identities = [];
            foreach ($r['software'] as $software) {
                if (++$work > self::MAX_COMPARISONS) { $out['status'] = 'PARTIAL'; break 2; }
                if (!is_array($software) || !isset($software['type'], $software['slug']) ||
                    !in_array($software['type'], ['plugin', 'theme', 'core'], true) || !self::identity($software['slug'])) {
                    $valid_record = false; continue;
                }
                $ranges = isset($software['affected_versions']) ? $software['affected_versions'] : null;
                if (!is_array($ranges) || !$ranges || count($ranges) > 128) { $valid_record = false; continue; }
                foreach ($ranges as $range) {
                    if (++$work > self::MAX_COMPARISONS) { $out['status'] = 'PARTIAL'; break 3; }
                    if (self::range('0', $range) === null) $valid_record = false;
                }
                $identities[$software['type'] . ':' . $software['slug']] = true;
            }
            if (!$valid_record) { self::reject($out,$r); continue; }
            foreach ($identities as $identity => $unused) $index[$identity][$id] = true;
        }
        foreach ($inventory as $component) {
            if (!is_array($component) || !isset($component['type'], $component['slug'], $component['version']) ||
                !in_array($component['type'], ['plugin', 'theme', 'core'], true) ||
                !self::identity($component['slug']) || !self::version($component['version'])) {
                $out['unknown_components'][] = count($out['unknown_components']);
                $out['status'] = 'PARTIAL'; continue;
            }
            $identity = $component['type'] . ':' . $component['slug'];
            foreach (isset($index[$identity]) ? $index[$identity] : [] as $id => $unused) {
                $r = $data[$id];
                if (++$work > self::MAX_COMPARISONS) {
                    $out['status'] = 'PARTIAL'; break 2;
                }
                if (!is_string($id) || preg_match('/\A[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\z/D', $id) !== 1 ||
                    !is_array($r) || !isset($r['id'], $r['title'], $r['software'], $r['informational']) ||
                    $r['id'] !== $id || !self::text($r['title'], 1024) || !is_array($r['software']) ||
                    count($r['software']) > 256 || !is_bool($r['informational']) ||
                    (array_key_exists('cve', $r) && !self::cve($r['cve']))) {
                    $out['rejected_records']++; $out['status'] = 'PARTIAL'; continue;
                }
                if ($r['informational']) continue;
                foreach ($r['software'] as $software) {
                    if (++$work > self::MAX_COMPARISONS) {
                        $out['status'] = 'PARTIAL'; break 3;
                    }
                    if (!is_array($software) || !isset($software['type'], $software['slug']) ||
                        !is_string($software['type']) || !self::identity($software['slug'])) {
                        $out['status'] = 'PARTIAL'; continue;
                    }
                    if ($software['type'] !== $component['type'] || $software['slug'] !== $component['slug']) continue;
                    $ranges = isset($software['affected_versions']) ? $software['affected_versions'] : null;
                    if (!is_array($ranges) || !$ranges || count($ranges) > 128) { $out['status'] = 'PARTIAL'; continue; }
                    $matched = false; $valid = true;
                    foreach ($ranges as $range) {
                        if (++$work > self::MAX_COMPARISONS) {
                            $out['status'] = 'PARTIAL'; break 4;
                        }
                        $m = self::range($component['version'], $range);
                        if ($m === null) $valid = false;
                        if ($m === true) $matched = true;
                    }
                    if (!$valid) { $out['status'] = 'PARTIAL'; continue; }
                    if (!$matched) continue;
                    $attribution = self::attribution($r); $url = null;
                    foreach (isset($r['references']) && is_array($r['references']) ? $r['references'] : [] as $ref) {
                        if (self::link($ref, true)) { $url = $ref; break; }
                    }
                    if ($attribution === null || $url === null) { $out['status'] = 'PARTIAL'; continue; }
                    $key = $id . ':' . $component['type'] . ':' . $component['slug'];
                    if (count($out['findings']) >= self::MAX_FINDINGS && !isset($out['findings'][$key])) {
                        $out['status'] = 'PARTIAL'; break 3;
                    }
                    $out['findings'][$key] = ['id' => $id, 'title' => $r['title'], 'cve' => isset($r['cve']) ? $r['cve'] : null,
                        'component' => ['type' => $component['type'], 'slug' => $component['slug'], 'version' => $component['version']],
                        'source' => 'Wordfence Intelligence', 'record_url' => $url, 'copyrights' => $attribution];
                }
            }
        }
        $out['comparisons'] = $work;
        $out['findings'] = array_values($out['findings']);
        return $out;
    }

    public static function render_finding($finding) {
        // Stored findings may be corrupt or altered: validate again at the display boundary.
        $unavailable = '<p>Vulnerability finding unavailable: invalid evidence or attribution.</p>';
        if (!is_array($finding) || !array_key_exists('cve', $finding) || !self::cve($finding['cve']) ||
            !isset($finding['title'], $finding['record_url'], $finding['copyrights']) ||
            !self::text($finding['title'], 1024) || !self::link($finding['record_url'], true) ||
            !is_array($finding['copyrights']) ||
            !isset($finding['copyrights']['message'], $finding['copyrights']['holders']) ||
            !is_array($finding['copyrights']['holders']) || count($finding['copyrights']['holders']) > 16)
            return $unavailable;
        $copyrights = ['message' => $finding['copyrights']['message']];
        foreach ($finding['copyrights']['holders'] as $name => $holder) {
            if ($name === 'message') return $unavailable;
            $copyrights[$name] = $holder;
        }
        $check = ['copyrights' => $copyrights];
        if (array_key_exists('cve', $finding)) $check['cve'] = $finding['cve'];
        if (self::attribution($check) === null) return $unavailable;
        $freshness = '';
        if (array_key_exists('feed_status', $finding) || array_key_exists('feed_age_seconds', $finding)) {
            if (!isset($finding['feed_status'], $finding['feed_age_seconds']) ||
                !in_array($finding['feed_status'], ['FRESH', 'STALE'], true) ||
                !is_int($finding['feed_age_seconds']) || $finding['feed_age_seconds'] < 0 ||
                (($finding['feed_status'] === 'STALE') !== ($finding['feed_age_seconds'] >= 86400))) return $unavailable;
            $freshness = '<p>Feed data: ' . $finding['feed_status'] . '; age ' . $finding['feed_age_seconds'] . ' seconds.</p>';
        }
        $e = function ($s) { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };
        $h = '<article><h3>' . $e($finding['title']) . '</h3><p>Source: Wordfence Intelligence. <a href="' .
            $e($finding['record_url']) . '" rel="noreferrer noopener">Original advisory</a></p><p>' .
            $e($finding['copyrights']['message']) . '</p>';
        foreach ($finding['copyrights']['holders'] as $holder) {
            $h .= '<p>' . $e($holder['notice']) . '</p><p>' . $e($holder['license']) . '</p><a href="' .
                $e($holder['license_url']) . '" rel="noreferrer noopener">License</a>';
        }
        return $h . $freshness . '<p>Review the advisory and choose any update yourself.</p></article>';
    }
}
