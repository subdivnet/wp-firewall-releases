<?php
if (!defined('ABSPATH')) { exit; }
/** Metadata-only uploads inventory. Filename indicators are not malware verdicts. */
final class WFP_Uploads_Inventory {
 const HOOK = 'wfp_uploads_inventory_scan';
 const REPORTS = 'wfp_uploads_inventory_reports_v1';
 const LOCK = 'wfp_uploads_inventory_lock_v1';
 const MAX_ENTRIES = 20000;
 const MAX_DIRS = 2000;
 const MAX_DEPTH = 32;
 const MAX_PATH_BYTES = 4096;
 const MAX_SECONDS = 5;
 public static function init() {
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::HOOK, [__CLASS__, 'scan']);
  add_action('admin_post_wfp_uploads_inventory', [__CLASS__, 'manual']);
  if (function_exists('register_deactivation_hook')) { register_deactivation_hook(WFP_Observer::PLUGIN_FILE, [__CLASS__, 'deactivate']); }
 }
 public static function ensure_schedule() { if (!wp_next_scheduled(self::HOOK)) { wp_schedule_event(time() + 60, 'hourly', self::HOOK); } }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); }
 public static function manual() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_uploads_inventory'); $r = self::scan(true); nocache_headers();
  echo '<!doctype html><html><head><meta charset="utf-8"><title>Uploads file review</title></head><body><main>';
  echo '<p><a href="'.esc_url(admin_url('tools.php?page=wfp-observer')).'">Return to Firewall Observer</a></p><h1>Uploads file review</h1>';
  self::render_report($r);
  echo '<p>Up to 20 relative filename examples observed in this request only; examples are not saved. Names alone do not establish malware or server execution. Incomplete results may omit files.</p>';
  foreach (($r['examples'] ?? []) as $row) { echo '<p><code>'.esc_html($row['file']).'</code>: '.esc_html($row['category']).'</p>'; }
  echo '</main></body></html>'; exit;
 }
 /** Script extension anywhere in a dot-separated name also catches double extensions. */
 public static function category($name) {
  $name = strtolower($name);
  if (in_array($name, ['.htaccess','.user.ini','php.ini','web.config'], true)) { return 'configuration'; }
  return preg_match('/\.(?:php[0-9]*|phtml|pht|phar|phps|cgi|pl|py|rb|sh|bash|shtml|asp|aspx|jsp|jspx|cfm|cfc)(?:[. ]|$)/D', $name) ? 'script_name' : '';
 }
 private static function plain($path) {
  do {
   clearstatcache(true, $path);
   if (is_link($path)) { return false; }
   $parent = dirname($path);
   if ($parent === $path || $path === '.' || $path === '') { return true; }
   $path = $parent;
  } while (true);
 }
 private static function metadata($path, $kind) {
  clearstatcache(true, $path); $st = @lstat($path);
  if (!is_array($st) || ($st['mode'] & 0170000) !== $kind) { return false; }
  $out = [];
  foreach (['dev','ino','mode','nlink','size','mtime','ctime'] as $field) { $out[] = $st[$field] ?? null; }
  return $out;
 }
 private static function unlock($lock) {
  global $wpdb;
  $wpdb->delete($wpdb->options, ['option_name' => self::LOCK, 'option_value' => maybe_serialize($lock)], ['%s','%s']);
  wp_cache_delete(self::LOCK, 'options'); wp_cache_delete('notoptions', 'options');
 }
 private static function acquire() {
  $old = get_option(self::LOCK, false);
  if ($old !== false && (!is_array($old) || !is_string($old['token'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $old['token'])
   || !is_int($old['expires'] ?? null) || $old['expires'] < time())) { self::unlock($old); }
  $lock = ['token' => bin2hex(random_bytes(16)), 'expires' => time() + 120];
  return add_option(self::LOCK, $lock, '', false) ? $lock : false;
 }
 private static function capture($root, $secret, $start, &$r, $pass, &$examples) {
  $prefix = $pass === 1 ? 'first_' : 'second_'; $map = []; $stack = [[$root, '', 0]];
  $root_meta = self::metadata($root, 0040000);
  if ($root_meta === false) { $r['completion_reason'] = 'root_unavailable'; return false; }
  $map[hash_hmac('sha256', 'root', $secret)] = hash_hmac('sha256', serialize($root_meta), $secret);
  try {
   while ($stack) {
    if (microtime(true) - $start >= self::MAX_SECONDS) { $r['status'] = 'partial'; $r['completion_reason'] = 'time_limit'; return false; }
    list($dir, $rel, $depth) = array_pop($stack);
    if (!self::plain($dir)) { $r['status'] = 'partial'; $r['completion_reason'] = 'path_link'; return false; }
    if (!is_readable($dir)) { $r['completion_reason'] = 'directory_unreadable'; return false; }
    if ($r[$prefix.'directories'] >= self::MAX_DIRS) { $r['status'] = 'partial'; $r['completion_reason'] = 'directory_limit'; return false; }
    $r[$prefix.'directories']++;
    $before = self::metadata($dir, 0040000);
    if ($before === false) { $r['completion_reason'] = 'metadata_unavailable'; return false; }
    $iterator = new DirectoryIterator($dir);
    foreach ($iterator as $entry) {
     if ($entry->isDot()) { continue; }
     if ($r[$prefix.'entries'] >= self::MAX_ENTRIES) { $r['status'] = 'partial'; $r['completion_reason'] = 'entry_limit'; return false; }
     if (microtime(true) - $start >= self::MAX_SECONDS) { $r['status'] = 'partial'; $r['completion_reason'] = 'time_limit'; return false; }
     $r[$prefix.'entries']++;
     $name = $entry->getFilename(); $relative = ($rel === '' ? '' : $rel.'/').$name; $path = $dir.'/'.$name;
     if (strlen($path) > self::MAX_PATH_BYTES) { $r['status'] = 'partial'; $r['completion_reason'] = 'path_limit'; return false; }
     if (!self::plain($path)) { $r['status'] = 'partial'; $r['completion_reason'] = 'path_link'; return false; }
     clearstatcache(true, $path); $st = @lstat($path);
     if (!is_array($st)) { $r['completion_reason'] = 'metadata_unavailable'; return false; }
     $kind = $st['mode'] & 0170000;
     if ($kind !== 0040000 && $kind !== 0100000) { $r['status'] = 'partial'; $r['completion_reason'] = 'special_file'; return false; }
     if ($kind === 0100000 && ($st['nlink'] ?? 1) > 1) { $r['status'] = 'partial'; $r['completion_reason'] = 'hard_link'; return false; }
     $meta = self::metadata($path, $kind);
     if ($meta === false) { $r['status'] = 'unstable'; $r['completion_reason'] = 'changed_during_scan'; return false; }
     $key = hash_hmac('sha256', 'entry:'.$relative, $secret);
     $map[$key] = hash_hmac('sha256', serialize($meta), $secret);
     if ($kind === 0040000) {
      if ($depth >= self::MAX_DEPTH || count($stack) >= self::MAX_DIRS) { $r['status'] = 'partial'; $r['completion_reason'] = 'directory_limit'; return false; }
      $stack[] = [$path, $relative, $depth + 1]; continue;
     }
     $r[$prefix.'files']++;
     $category = self::category($name);
     if ($category !== '') {
      $r[$prefix.($category === 'script_name' ? 'scripts' : 'configuration')]++;
      if (is_array($examples) && count($examples) < 20) { $examples[$key] = ['file' => $relative, 'category' => $category]; }
     }
    }
    if (!self::plain($dir) || self::metadata($dir, 0040000) !== $before) { $r['status'] = 'unstable'; $r['completion_reason'] = 'changed_during_scan'; return false; }
   }
  } catch (UnexpectedValueException $e) { $r['completion_reason'] = 'directory_unreadable'; return false; }
  ksort($map, SORT_STRING); return $map;
 }
 public static function scan($details = false) {
  $r = ['scanner_revision' => 1, 'status' => 'unavailable', 'completion_reason' => 'root_unavailable', 'time_utc' => gmdate('Y-m-d H:i:s'),
   'script_named_files' => null, 'configuration_files' => null];
  foreach (['first_','second_'] as $prefix) { foreach (['files','entries','directories','scripts','configuration'] as $field) { $r[$prefix.$field] = 0; } }
  $lock = self::acquire();
  if (!$lock) { $r['status'] = 'busy'; $r['completion_reason'] = 'scan_in_progress'; return $r; }
  $examples = $details === true ? [] : null;
  try {
   $uploads = function_exists('wp_get_upload_dir') ? wp_get_upload_dir() : false;
   $root = is_array($uploads) ? ($uploads['basedir'] ?? null) : null;
   if (is_string($root) && strlen($root) > 0 && strlen($root) <= self::MAX_PATH_BYTES
    && ($root[0] === '/' || (DIRECTORY_SEPARATOR === '\\' && preg_match('/^[A-Za-z]:/', $root) && in_array(substr($root, 2, 1), ['\\','/'], true))) && strpos($root, "\0") === false
    && strpos($root, '://') === false && substr($root, 0, 2) !== '\\\\' && empty($uploads['error'])) {
    if (!self::plain($root)) { $r['status'] = 'partial'; $r['completion_reason'] = 'path_link'; }
    elseif (is_dir($root) && is_readable($root) && realpath($root) !== false
     && realpath($root) !== dirname(realpath($root))
     && (!defined('WP_CONTENT_DIR') || realpath($root) !== realpath(WP_CONTENT_DIR))
     && realpath($root) !== realpath(ABSPATH)) {
     $root = rtrim(realpath($root), '/\\'); $secret = hash_hmac('sha256', 'wfp-uploads-inventory-v1', wp_salt('auth'), true); $start = microtime(true);
     $first = self::capture($root, $secret, $start, $r, 1, $examples);
     if ($first !== false) {
      $second = self::capture($root, $secret, $start, $r, 2, $examples);
      if ($second !== false) {
       if ($first !== $second || !self::plain($root)) { $r['status'] = 'unstable'; $r['completion_reason'] = 'changed_during_scan'; }
       else { $r['status'] = 'completed'; $r['completion_reason'] = 'none'; $r['script_named_files'] = $r['first_scripts']; $r['configuration_files'] = $r['first_configuration']; }
      }
     }
    }
   }
   if (get_option(self::LOCK, false) !== $lock || $lock['expires'] < time()) { $r['status'] = 'busy'; $r['completion_reason'] = 'scan_in_progress'; return $r; }
   $safe = self::clean_report($r);
   if ($safe === false) { $r['status'] = 'unavailable'; $r['completion_reason'] = 'metadata_unavailable'; $r['script_named_files'] = null; $r['configuration_files'] = null; return $r; }
   $rows = self::history(); array_unshift($rows, $safe); update_option(self::REPORTS, array_slice($rows, 0, 24), false);
   if (get_option(self::REPORTS, false) !== array_slice($rows, 0, 24)) { $r['status'] = 'unavailable'; $r['completion_reason'] = 'report_storage_unavailable'; $r['script_named_files'] = null; $r['configuration_files'] = null; }
   if (is_array($examples)) { $r['examples'] = array_values($examples); }
   return $r;
  } finally { self::unlock($lock); }
 }
 public static function labels() {
  return ['none' => 'Completed filename inventory', 'root_unavailable' => 'Configured uploads directory unavailable',
   'path_link' => 'Symbolic link not followed', 'directory_unreadable' => 'Directory could not be read',
   'metadata_unavailable' => 'File metadata could not be read', 'special_file' => 'Special file not inspected',
   'hard_link' => 'Hard link not inspected', 'directory_limit' => 'Directory count or depth limit reached',
   'entry_limit' => 'Directory entry limit reached', 'path_limit' => 'Path length limit reached',
   'time_limit' => 'Processing-time budget reached', 'changed_during_scan' => 'Metadata changed during inventory',
   'report_storage_unavailable' => 'Inventory report could not be saved'];
 }
 public static function clean_report($raw) {
  if (!is_array($raw) || ($raw['scanner_revision'] ?? null) !== 1
   || !in_array($raw['status'] ?? '', ['completed','partial','unavailable','unstable'], true)
   || !is_string($raw['completion_reason'] ?? null) || !array_key_exists($raw['completion_reason'], self::labels())
   || WFP_State_Sanitizer::timestamp($raw['time_utc'] ?? null) === '' || $raw['time_utc'] > gmdate('Y-m-d H:i:s')) { return false; }
  $r = ['scanner_revision' => 1, 'status' => $raw['status'], 'completion_reason' => $raw['completion_reason'], 'time_utc' => $raw['time_utc']];
  foreach (['first_','second_'] as $prefix) {
   foreach (['files','entries','directories','scripts','configuration'] as $field) {
    $value = $raw[$prefix.$field] ?? null; $max = $field === 'directories' ? self::MAX_DIRS : self::MAX_ENTRIES;
    if (!is_int($value) || $value < 0 || $value > $max) { return false; } $r[$prefix.$field] = $value;
   }
   if ($r[$prefix.'directories'] > $r[$prefix.'entries'] + 1 || $r[$prefix.'files'] > $r[$prefix.'entries'] || $r[$prefix.'scripts'] + $r[$prefix.'configuration'] > $r[$prefix.'files']) { return false; }
  }
  foreach (['script_named_files','configuration_files'] as $field) {
   $value = $raw[$field] ?? null;
   if ($r['status'] !== 'completed') { if ($value !== null) { return false; } }
   elseif (!is_int($value) || $value < 0 || $value > self::MAX_ENTRIES) { return false; }
   $r[$field] = $value;
  }
  if ($r['status'] === 'completed') {
   if ($r['first_directories'] < 1 || $r['completion_reason'] !== 'none' || $r['script_named_files'] !== $r['first_scripts'] || $r['configuration_files'] !== $r['first_configuration']) { return false; }
   foreach (['files','entries','directories','scripts','configuration'] as $field) { if ($r['first_'.$field] !== $r['second_'.$field]) { return false; } }
  } elseif ($r['completion_reason'] === 'none') { return false; }
  return $r;
 }
 public static function history() {
  $raw = get_option(self::REPORTS, []); if (!is_array($raw)) { return []; } $out = [];
  foreach (array_slice($raw, 0, 48) as $row) { $safe = self::clean_report($row); if ($safe !== false) { $out[] = $safe; } }
  return array_slice($out, 0, 24);
 }
 public static function status() { $h = self::history(); return ['latest' => $h ? $h[0] : ['status' => 'not_run'], 'history' => $h]; }
 public static function render_report($r) {
  echo '<p>Status: <strong>'.esc_html(str_replace('_', ' ', $r['status'])).'</strong>';
  if (isset($r['time_utc'])) { echo ' at '.esc_html($r['time_utc']).' UTC'; } echo '.</p>';
  if (isset($r['completion_reason']) && isset(self::labels()[$r['completion_reason']])) { echo '<p>Coverage: '.esc_html(self::labels()[$r['completion_reason']]).'.</p>'; }
  if (isset($r['first_files'])) { echo '<p>Files examined in each pass: '.esc_html((string)$r['first_files']).' / '.esc_html((string)$r['second_files']).'; entries: '.esc_html((string)$r['first_entries']).' / '.esc_html((string)$r['second_entries']).'.</p>'; }
  if ($r['status'] === 'completed') { echo '<p>Script-like filenames: '.esc_html((string)$r['script_named_files']).'; configuration filenames: '.esc_html((string)$r['configuration_files']).'. Review these names in context; this is not a malware verdict.</p>'; }
  elseif (isset($r['first_scripts'])) { echo '<p>Observed script-like names in each incomplete pass: '.esc_html((string)$r['first_scripts']).' / '.esc_html((string)$r['second_scripts']).'; configuration names: '.esc_html((string)$r['first_configuration']).' / '.esc_html((string)$r['second_configuration']).'. These are partial observations, not site totals.</p>'; }
 }
 public static function render() {
  $s = self::status(); echo '<h2>Review executable and configuration names in uploads</h2>'; self::render_report($s['latest']);
  echo '<p>Metadata-only inventory of the configured local uploads directory, including nested and hidden entries. Two matching observed metadata passes; no uploaded file contents are opened or hashed and no files are changed. Script extensions (including double extensions) and .htaccess, .user.ini, php.ini and web.config warrant review; index.php or configuration files may be legitimate. Server execution rules are not inspected. Extensionless code, code hidden in ordinary media, other locations, external storage and malware signatures are outside scope. A completed inventory is not a clean-site assessment.</p>';
  echo '<p>Limits: 20000 entries per pass, 2000 directories, depth 32, path length 4096 bytes and five seconds between operations. Symlinks, hard links, special files or limits produce incomplete coverage. Automatic checks depend on WordPress cron. No alerts, blocking, deletion or remediation occur. Only aggregate reports are saved; a fresh administrator scan can show up to 20 ephemeral relative filenames.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_uploads_inventory">'; wp_nonce_field('wfp_uploads_inventory'); submit_button('Review upload files now', 'secondary'); echo '</form>';
  if ($s['history']) {
   echo '<details><summary>Show uploads inventory history</summary><table class="widefat striped"><thead><tr><th>UTC time</th><th>Coverage</th><th>Script-like names</th><th>Configuration names</th></tr></thead><tbody>';
   foreach ($s['history'] as $row) { echo '<tr><td>'.esc_html($row['time_utc']).'</td><td>'.esc_html(self::labels()[$row['completion_reason']]).'</td><td>'.esc_html($row['script_named_files'] === null ? 'Incomplete' : (string)$row['script_named_files']).'</td><td>'.esc_html($row['configuration_files'] === null ? 'Incomplete' : (string)$row['configuration_files']).'</td></tr>'; }
   echo '</tbody></table></details>';
  }
 }
}
