<?php

// Local prototype. The caller supplies the pinned key and release channel.
function wfp_verify_public_manifest($manifest, $signature, $public_key, $channel, $installed, $now) {
    if (!is_string($manifest) || strlen($manifest) > 4096 || !is_string($signature)
        || strlen($signature) > 1024 || !function_exists('openssl_verify')) {
        return false;
    }
    $decoded_signature = base64_decode($signature, true);
    if ($decoded_signature === false || openssl_verify($manifest, $decoded_signature, $public_key, OPENSSL_ALGO_SHA256) !== 1) {
        return false;
    }

    $release = json_decode($manifest, true, 4);
    $version_pattern = $channel === 'https-rehearsal'
        ? '/\A[0-9]+\.[0-9]+\.[0-9]+-lab\.[0-9]+-dev\z/'
        : '/\A[0-9]+\.[0-9]+\.[0-9]+\z/';
    if (!is_array($release) || ($release['schema'] ?? null) !== 1
        || ($release['plugin'] ?? null) !== 'wp-firewall-prototype'
        || ($release['channel'] ?? null) !== $channel
        || !is_string($release['version'] ?? null)
        || !preg_match($version_pattern, $release['version'])
        || !version_compare($release['version'], $installed, '>')
        || ($release['path'] ?? null) !== ($channel === 'https-rehearsal'
            ? 'wp-firewall-prototype-' . $release['version'] . '.zip'
            : 'v' . $release['version'] . '/wp-firewall-prototype.zip')
        || !is_int($release['expires'] ?? null) || $release['expires'] <= $now
        || !is_int($release['bytes'] ?? null) || $release['bytes'] < 1 || $release['bytes'] > 10 * 1024 * 1024
        || !is_string($release['sha256'] ?? null) || !preg_match('/\A[a-f0-9]{64}\z/', $release['sha256'])) {
        return false;
    }
    return $release;
}

// Verify the downloaded temporary file against a verified manifest.
function wfp_verify_public_package($file, array $release) {
    clearstatcache(true, $file);
    if (!is_file($file) || !is_readable($file) || filesize($file) !== $release['bytes']) {
        return false;
    }

    $digest = hash_file('sha256', $file);
    return is_string($digest) && hash_equals($release['sha256'], $digest);
}
