<?php
if (!defined('ABSPATH')) { exit; }
/** Bounded, seekable provider JSON reader. No network or WordPress state. */
final class WFP_Scanner_Stream {
 private $stream; private $buffer = ''; private $position = 0; public $offset;
 const RECORD_LIMIT = 2097152;
 public function __construct($path, $offset = 0) {
  $this->stream = fopen($path, 'rb');
  if (!$this->stream || fseek($this->stream, $offset) !== 0) { throw new RuntimeException('feed_open'); }
  $this->offset = $offset;
 }
 public function __destruct() { if (is_resource($this->stream)) { fclose($this->stream); } }
 private function chunk() {
  if ($this->position >= strlen($this->buffer)) { $this->buffer = fread($this->stream, 65536); $this->position = 0; }
  if ($this->buffer === false) { throw new RuntimeException('feed_read'); }
  return substr($this->buffer, $this->position);
 }
 private function take($n = 1) {
  $chunk = $this->chunk(); if (strlen($chunk) < $n) { throw new RuntimeException('feed_truncated'); }
  $value = substr($chunk, 0, $n); $this->position += $n; $this->offset += $n; return $value;
 }
 private function whitespace() {
  while (($chunk = $this->chunk()) !== '') { $n = strspn($chunk, " \r\n\t"); if (!$n) { break; } $this->take($n); }
 }
 private function expect($c) { $this->whitespace(); if ($this->take() !== $c) { throw new RuntimeException('feed_token'); } }
 private function value($key = false) {
  $this->whitespace(); $value = ''; $depth = 0; $quoted = false; $started = false;
  do {
   $chunk = $this->chunk(); if ($chunk === '') { throw new RuntimeException('feed_truncated'); }
   if ($quoted) { $n = strcspn($chunk, "\"\\"); if ($n) { $value .= $this->take($n); if (strlen($value) > self::RECORD_LIMIT) { throw new RuntimeException('record_limit'); } continue; } }
   $c = $this->take(); $value .= $c;
   if ($quoted && $c === '\\') { $value .= $this->take(); }
   elseif ($c === '"') { $quoted = !$quoted; if ($key && $started && !$quoted) { return $value; } }
   elseif (!$quoted) { if ($c === '{' || $c === '[') { $depth++; } elseif ($c === '}' || $c === ']') { $depth--; } }
   $started = true;
   if ($depth > 64 || strlen($value) > self::RECORD_LIMIT) { throw new RuntimeException('record_limit'); }
  } while ($quoted || $depth > 0 || !$started);
  return $value;
 }
 public function next($first) {
  if ($this->offset === 0) { $this->expect('{'); }
  $this->whitespace();
  if (substr($this->chunk(), 0, 1) === '}') {
   $this->take(); $this->whitespace(); if ($this->chunk() !== '') { throw new RuntimeException('feed_trailing'); } return null;
  }
  if (!$first) { $this->expect(','); }
  $this->whitespace(); if (substr($this->chunk(), 0, 1) !== '"') { throw new RuntimeException('feed_key'); }
  $key = json_decode($this->value(true), true, 8, JSON_THROW_ON_ERROR);
  if (!is_string($key) || !preg_match('/^[a-f0-9-]{36}$/Di', $key)) { throw new RuntimeException('feed_identity'); }
  $this->expect(':'); $this->whitespace(); $start = $this->offset;
  if (substr($this->chunk(), 0, 1) !== '{') { throw new RuntimeException('feed_record'); }
  $raw = $this->value(); $record = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
  if (!is_array($record) || ($record['id'] ?? null) !== $key || !isset($record['software']) || !is_array($record['software'])) { throw new RuntimeException('feed_record'); }
  return ['id' => $key, 'record' => $record, 'offset' => $start, 'length' => strlen($raw)];
 }
 /** Atomic caller-owned generation only. Root UUIDs are unique even across resumed slices. */
 public static function append($directory, $row) {
  $uuid = hash('sha256', $row['id']); $seen = $directory . '/seen-' . substr($uuid, 0, 2);
  $prior = is_file($seen) ? file_get_contents($seen) : '';
  if ($prior === false || strlen($prior) > 131072 || strpos("\n" . $prior, "\n" . $uuid . "\n") !== false) { throw new RuntimeException('duplicate_or_invalid_identity'); }
  if (file_put_contents($seen, $uuid . "\n", FILE_APPEND) !== 65) { throw new RuntimeException('index_write'); }
  chmod($seen, 0600); $count = 0; $dedup = [];
  foreach ($row['record']['software'] as $software) {
   if (!is_array($software) || !is_string($software['type'] ?? null) || !is_string($software['slug'] ?? null) || strlen($software['slug']) > 512) { throw new RuntimeException('software_shape'); }
   $identity = hash('sha256', $software['type'] . ':' . $software['slug']); if (isset($dedup[$identity])) { continue; } $dedup[$identity] = true;
   $path = $directory . '/bucket-' . substr($identity, 0, 2);
   $line = json_encode([$identity, $row['offset'], $row['length']], JSON_THROW_ON_ERROR) . "\n";
   if (file_put_contents($path, $line, FILE_APPEND) !== strlen($line)) { throw new RuntimeException('index_write'); } chmod($path, 0600); $count++;
  }
  return $count;
 }
}
