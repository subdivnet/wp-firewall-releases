<?php
if (!defined('ABSPATH')) { exit; }
/** Bounded, observation-only core integrity checks. No file contents leave the site. */
final class WFP_Core_Integrity {
 const REVISION = 2;
 const HOOK = 'wfp_core_integrity_scan';
 const HISTORY = 'wfp_core_integrity_history_v1';
 const HISTORY_LIMIT = 24;
 const SUMMARY = 'wfp_core_integrity_summary_v1';
 const MAX_FILES = 5000;
 const MAX_ENTRIES = 8000;
 const MAX_BYTES = 268435456;
 const MAX_FILE_BYTES = 67108864;
 const MAX_SECONDS = 5;
 public static function init() {
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::HOOK, [__CLASS__, 'scheduled_scan']);
  if (function_exists('register_deactivation_hook')) {
   register_deactivation_hook(WFP_Observer::PLUGIN_FILE, [__CLASS__, 'deactivate']);
  }
 }
 public static function ensure_schedule() {
  $next = wp_next_scheduled(self::HOOK);
  if (!$next) { wp_schedule_event(time() + 60, 'hourly', self::HOOK); return; }
  $last = self::summary();
  $stamp = WFP_State_Sanitizer::timestamp($last['checked_at_utc'] ?? null);
  // Retry unavailable scans after five minutes; do not retry incomplete scans
  // that repeatedly hit resource limits. Keep the existing hourly event.
  $outdated = $stamp !== '' && (($last['scanner_revision'] ?? 0) !== self::REVISION || empty($last['matches_current_package']));
  $retry = ($last['status'] ?? '') === 'unavailable' && $stamp !== '' && strtotime($stamp . ' UTC') <= time() - 300;
  if (($outdated || $retry) && $next > time() + 660) {
   wp_schedule_single_event(time() + 60, self::HOOK);
  }
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); }
 private static function manifest($version, $locale) {
  if (!is_string($version) || !preg_match('/^[0-9][0-9A-Za-z.-]{0,39}$/D', $version)
   || !is_string($locale) || !preg_match('/^[A-Za-z0-9_@.-]{2,30}$/D', $locale)) { return false; }
  $key = 'wfp_core_manifest_' . md5($version . ':' . $locale);
  $cached = get_transient($key);
  if (is_array($cached)) { return $cached; }
  $url = 'https://api.wordpress.org/core/checksums/1.0/?' . http_build_query(['version' => $version, 'locale' => $locale], '', '&');
  $response = wp_safe_remote_get($url, ['timeout' => 5, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 2097152, 'user-agent' => 'WFP-Core-Integrity']);
  if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) { return false; }
  $body = json_decode(wp_remote_retrieve_body($response), true);
  $checksums = is_array($body) ? ($body['checksums'] ?? false) : false;
  if (!is_array($checksums) || !$checksums || count($checksums) > 10000) { return false; }
  set_transient($key, $checksums, 21600); // Public release metadata only.
  return $checksums;
 }
 private static function relative_path($path) {
  if (!is_string($path) || strlen($path) > 240 || !preg_match('~^[a-zA-Z0-9_./-]+$~D', $path)) { return false; }
  foreach (explode('/', $path) as $part) {
   if ($part === '' || $part === '.' || $part === '..') { return false; }
  }
  return true;
 }
 private static function target($root, $relative) {
  if (!self::relative_path($relative)) { return false; }
  $path = $root;
  foreach (explode('/', $relative) as $part) {
   $path .= DIRECTORY_SEPARATOR . $part;
   if (is_link($path)) { return false; }
  }
  $resolved = realpath($path);
  if ($resolved !== false && strpos($resolved, $root . DIRECTORY_SEPARATOR) !== 0) { return false; }
  return $path;
 }
 private static function example(&$report, $file, $issue) {
  if (count($report['examples']) < 20) {
   // Only ephemeral administrator responses include relative file paths.
   $report['examples'][] = ['file' => substr($file, 0, 240), 'issue' => $issue];
  }
 }
 public static function run($root = null, $checksums = null, $version = null, $locale = null) {
  global $wp_version, $wp_local_package;
  $version = $version === null ? ($wp_version ?? '') : $version;
  $locale = $locale === null ? ($wp_local_package ?? 'en_US') : $locale;
  $r = [
   'status' => 'unavailable', 'checked_at_utc' => gmdate('Y-m-d H:i:s'),
   'wordpress_version' => $version, 'package_locale' => $locale, 'scanner_revision' => self::REVISION,
   'manifest_files' => 0, 'excluded_manifest_files' => 0, 'expected_files_examined' => 0,
   'matched_files' => 0, 'modified_files' => 0, 'missing_files' => 0,
   'unreadable_files' => 0, 'symlinked_entries' => 0, 'unexpected_files' => 0,
   'skipped_large_files' => 0, 'checked_bytes' => 0, 'directory_entries_examined' => 0,
   'examples' => [], 'reason' => 'Official checksums or installation root unavailable.',
   'scope' => 'Official WordPress core files, extra files in wp-admin/wp-includes, and extra root PHP files. Excludes wp-content and wp-config.php. No malware signature scan or assurance that the whole site is clean.',
  ];
  $root = realpath($root === null ? ABSPATH : $root);
  if ($root === false || !is_dir($root)) { return $r; }
  $root = rtrim($root, '/\\');
  if ($checksums === null) { $checksums = self::manifest($version, $locale); }
  if (!is_array($checksums) || !$checksums || count($checksums) > 10000) { return $r; }
  $expected = [];
  foreach ($checksums as $file => $hash) {
   // Out-of-scope bundled plugins/themes may contain font and image names
   // outside the core path allowlist. Never inspect or validate their contents.
   if (is_string($file) && (strpos($file, 'wp-content/') === 0 || $file === 'wp-config.php')) {
    $r['excluded_manifest_files']++; continue;
   }
   if (!self::relative_path($file) || !is_string($hash) || !preg_match('/^[a-f0-9]{32}$/iD', $hash)) {
    $r['reason'] = 'Invalid checksum manifest; no verification result available.'; return $r;
   }
   if (strpos($file, '/') !== false && strpos($file, 'wp-admin/') !== 0 && strpos($file, 'wp-includes/') !== 0) {
    $r['reason'] = 'Unexpected manifest scope; no verification result available.'; return $r;
   }
   $expected[$file] = strtolower($hash);
  }
  if (!$expected) { return $r; }
  $r['manifest_files'] = count($expected);
  $r['status'] = 'completed'; $r['reason'] = '';
  $started = microtime(true);
  foreach ($expected as $file => $hash) {
   if ($r['expected_files_examined'] >= self::MAX_FILES || microtime(true) - $started >= self::MAX_SECONDS) {
    $r['status'] = 'partial'; $r['reason'] = 'Scan resource limit reached.'; break;
   }
   $r['expected_files_examined']++;
   $path = self::target($root, $file);
   if ($path === false) {
    $r['symlinked_entries']++; $r['status'] = 'partial'; self::example($r, $file, 'symbolic link or unsafe path; not read'); continue;
   }
   if (!file_exists($path)) { $r['missing_files']++; self::example($r, $file, 'missing'); continue; }
   if (!is_file($path) || !is_readable($path)) {
    $r['unreadable_files']++; $r['status'] = 'partial'; self::example($r, $file, 'unreadable'); continue;
   }
   $size = @filesize($path);
   if ($size === false) { $r['unreadable_files']++; $r['status'] = 'partial'; continue; }
   if ($size > self::MAX_FILE_BYTES || $r['checked_bytes'] + $size > self::MAX_BYTES) {
    $r['skipped_large_files']++; $r['status'] = 'partial'; $r['reason'] = 'Individual file or total read-byte limit reached.';
    self::example($r, $file, 'file size or remaining read budget exceeded; not verified'); continue;
   }
   $actual = @md5_file($path);
   $r['checked_bytes'] += $size;
   if ($actual === false) { $r['unreadable_files']++; $r['status'] = 'partial'; continue; }
   if (hash_equals($hash, $actual)) { $r['matched_files']++; }
   else { $r['modified_files']++; self::example($r, $file, 'checksum mismatch'); }
  }
  // Never follow symlinks. Bound both enumeration and elapsed time.
  foreach (['wp-admin', 'wp-includes', ''] as $area) {
   if (microtime(true) - $started >= self::MAX_SECONDS || $r['directory_entries_examined'] >= self::MAX_ENTRIES) {
    $r['status'] = 'partial'; $r['reason'] = 'Scan resource limit reached.'; break;
   }
   $dir = $area === '' ? $root : self::target($root, $area);
   if ($dir === false) { $r['status'] = 'partial'; $r['symlinked_entries']++; continue; }
   if (!is_dir($dir)) { $r['status'] = 'partial'; $r['reason'] = 'A core directory was unavailable.'; continue; }
   try {
    $iterator = $area === ''
     ? new DirectoryIterator($dir)
     : new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
    foreach ($iterator as $item) {
     if ($item->getFilename() === '.' || $item->getFilename() === '..') { continue; }
     if ($r['directory_entries_examined'] >= self::MAX_ENTRIES || microtime(true) - $started >= self::MAX_SECONDS) {
      $r['status'] = 'partial'; $r['reason'] = 'Scan resource limit reached.'; break;
     }
     $r['directory_entries_examined']++;
     $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($item->getPathname(), strlen($root) + 1));
     if ($area === '' && (!preg_match('/\.php$/iD', $relative) || $relative === 'wp-config.php')) { continue; }
     if ($item->isLink()) {
      // Expected symlinks were already counted above.
      if (!isset($expected[$relative])) { $r['symlinked_entries']++; }
      $r['status'] = 'partial'; continue;
     }
     if ($item->isDir()) { continue; }
     if (!isset($expected[$relative])) { $r['unexpected_files']++; self::example($r, $relative, 'unexpected file; review required'); }
    }
   } catch (UnexpectedValueException $e) {
    $r['status'] = 'partial'; $r['unreadable_files']++; $r['reason'] = 'A directory could not be inspected.';
   }
  }
  if ($r['status'] === 'partial' && $r['reason'] === '') { $r['reason'] = 'Some files or symbolic links could not be verified.'; }
  return $r;
 }
 public static function scheduled_scan() {
  $previous = self::summary();
  $rows = self::history();
  $r = self::run();
  unset($r['examples']); // Never persist file paths or contents in scan history.
  if (!$rows && isset($previous['manifest_files'])) { $rows[] = $previous; }
  array_unshift($rows, $r);
  update_option(self::HISTORY, self::normalize_history($rows), false);
  update_option(self::SUMMARY, $r, false);
 }
 public static function summary() { return self::validate_summary(get_option(self::SUMMARY, [])); }
 public static function validate_summary($raw) {
  if (!is_array($raw) || !in_array($raw['status'] ?? '', ['completed', 'partial', 'unavailable'], true)) {
   return ['status' => 'not_run', 'meaning' => 'No stored background scan. WordPress cron depends on traffic or an external cron runner.'];
  }
  global $wp_version, $wp_local_package;
  $version = $raw['wordpress_version'] ?? '';
  $locale = $raw['package_locale'] ?? '';
  $version = is_string($version) && preg_match('/^[0-9][0-9A-Za-z.-]{0,39}$/D', $version) ? $version : '';
  $locale = is_string($locale) && preg_match('/^[A-Za-z0-9_@.-]{2,30}$/D', $locale) ? $locale : '';
  $stamp = WFP_State_Sanitizer::timestamp($raw['checked_at_utc'] ?? null);
  if ($stamp === '' || $version === '' || $locale === '') { return ['status' => 'unavailable', 'checked_at_utc' => $stamp]; }
  $safe = [
   'status' => $raw['status'], 'checked_at_utc' => $stamp,
   'wordpress_version' => $version, 'package_locale' => $locale,
   'scanner_revision' => WFP_State_Sanitizer::count_value($raw['scanner_revision'] ?? 0),
   'matches_current_package' => $version !== '' && $version === ($wp_version ?? '') && $locale === ($wp_local_package ?? 'en_US'),
  ];
  foreach (['manifest_files','excluded_manifest_files','expected_files_examined','matched_files','modified_files','missing_files','unreadable_files','symlinked_entries','unexpected_files','skipped_large_files','checked_bytes','directory_entries_examined'] as $key) {
   $value = WFP_State_Sanitizer::count_value($raw[$key] ?? null, -1);
   if ($value < 0) { return ['status' => 'unavailable', 'checked_at_utc' => $stamp]; }
   $safe[$key] = $value;
  }
  $classified = $safe['matched_files'] + $safe['modified_files'] + $safe['missing_files'];
  if ($safe['manifest_files'] > 10000 || $safe['expected_files_examined'] > self::MAX_FILES
   || $safe['expected_files_examined'] > $safe['manifest_files'] || $classified > $safe['expected_files_examined']
   || ($safe['status'] === 'completed' && ($safe['manifest_files'] === 0
    || $classified !== $safe['manifest_files'] || $safe['expected_files_examined'] !== $safe['manifest_files']
    || $safe['unreadable_files'] !== 0 || $safe['symlinked_entries'] !== 0 || $safe['skipped_large_files'] !== 0))) {
   return ['status' => 'unavailable', 'checked_at_utc' => $stamp];
  }
  return $safe;
 }
 public static function normalize_history($rows, $now = null) {
  if (!is_array($rows)) { return []; }
  $now = $now === null ? time() : (int) $now;
  $safe = [];
  foreach (array_slice($rows, 0, self::HISTORY_LIMIT * 2) as $row) {
   $row = self::validate_summary($row);
   if (!isset($row['manifest_files']) || $row['checked_at_utc'] > gmdate('Y-m-d H:i:s', $now)) { continue; }
   $key = $row['checked_at_utc'] . ':' . $row['wordpress_version'] . ':' . $row['package_locale'] . ':' . $row['scanner_revision'];
   if (!isset($safe[$key])) { $safe[$key] = $row; }
  }
  $safe = array_values($safe);
  usort($safe, function ($a, $b) { return strcmp($b['checked_at_utc'], $a['checked_at_utc']); });
  return array_slice($safe, 0, self::HISTORY_LIMIT);
 }
 public static function history() { return self::normalize_history(get_option(self::HISTORY, [])); }
 public static function trend($rows = null) {
  $rows = $rows === null ? self::history() : self::normalize_history($rows);
  $result = ['status' => 'insufficient_history', 'meaning' => 'Two complete, comparable automatic scans are needed. Counts do not identify individual files or establish recurrence of the same file.'];
  if (count($rows) < 2) { return $result; }
  $a = $rows[0]; $b = $rows[1];
  if ($a['status'] !== 'completed' || $b['status'] !== 'completed'
   || $a['checked_at_utc'] <= $b['checked_at_utc']
   || $a['wordpress_version'] !== $b['wordpress_version'] || $a['package_locale'] !== $b['package_locale']
   || $a['scanner_revision'] !== $b['scanner_revision'] || $a['manifest_files'] !== $b['manifest_files']
   || !$a['matches_current_package']) {
   $result['status'] = 'not_comparable'; return $result;
  }
  $increased = false; $decreased = false; $deltas = [];
  foreach (['modified_files', 'missing_files', 'unexpected_files'] as $key) {
   $deltas[$key] = $a[$key] - $b[$key];
   if ($deltas[$key] > 0) { $increased = true; }
   if ($deltas[$key] < 0) { $decreased = true; }
  }
  $result['status'] = $increased ? 'findings_increased' : ($decreased ? 'findings_decreased' : 'counts_unchanged');
  $result['current_scan_utc'] = $a['checked_at_utc']; $result['previous_scan_utc'] = $b['checked_at_utc'];
  $result['count_changes'] = $deltas;
  return $result;
 }
 public static function render_history() {
  $rows = self::history(); $trend = self::trend($rows);
  echo '<h2>Core scan history</h2><p>Last '.self::HISTORY_LIMIT.' automatic scan summaries, newest first. Earlier findings remain visible when later counts fall. Only counts and scan metadata are retained.</p>';
  $labels = [
   'insufficient_history' => 'Waiting for two complete comparable scans.',
   'not_comparable' => 'The latest scans cannot be compared: a scan was incomplete, the package or scanner changed, or timing is invalid.',
   'findings_increased' => 'Finding counts increased. Review a fresh manual scan for file details.',
   'findings_decreased' => 'Finding counts decreased. This does not prove that a compromise was removed.',
   'counts_unchanged' => 'Finding counts are unchanged. This does not prove that the same individual files are unchanged.',
  ];
  echo '<p><strong>'.esc_html($labels[$trend['status']]).'</strong></p>';
  if (!$rows) { echo '<p>No retained automatic scan history yet.</p>'; return; }
  echo '<details><summary>Show recent scan summaries</summary><table class="widefat striped"><thead><tr><th>UTC time</th><th>Status</th><th>WordPress</th><th>Modified</th><th>Missing</th><th>Unexpected</th></tr></thead><tbody>';
  foreach ($rows as $row) {
   echo '<tr><td>'.esc_html($row['checked_at_utc']).'</td><td>'.esc_html($row['status']).'</td><td>'.esc_html($row['wordpress_version']).'</td><td>'.esc_html((string) $row['modified_files']).'</td><td>'.esc_html((string) $row['missing_files']).'</td><td>'.esc_html((string) $row['unexpected_files']).'</td></tr>';
  }
  echo '</tbody></table></details><p>These are scan snapshots, not a complete file-change log. Updates, restores and manual maintenance can explain differences. No automatic alerts or file changes are performed.</p>';
 }
 public static function render($r, $background = false) {
  echo '<h2>'.($background ? 'Last automatic core scan' : 'Core file integrity scan').'</h2>';
  if (($r['status'] ?? '') === 'not_run') { echo '<p>No automatic scan recorded yet.</p>'; return; }
  echo '<p>Status: <strong>'.esc_html($r['status']).'</strong>; checked at '.esc_html($r['checked_at_utc'] ?? '').' UTC.</p>';
  if ($background && empty($r['matches_current_package'])) { echo '<p>This saved scan does not match the currently installed WordPress package. Run a fresh scan.</p>'; }
  if ($r['status'] === 'unavailable') { echo '<p>Official checksums or scan access were unavailable. No clean result can be inferred.</p>'; return; }
  echo '<p>Expected files examined: '.esc_html((string) $r['expected_files_examined']).' of '.esc_html((string) $r['manifest_files']).'; matching: '.esc_html((string) $r['matched_files']).'; modified: '.esc_html((string) $r['modified_files']).'; missing: '.esc_html((string) $r['missing_files']).'; unexpected: '.esc_html((string) $r['unexpected_files']).'.</p>';
  echo '<p>Unreadable: '.esc_html((string) $r['unreadable_files']).'; symbolic links not read: '.esc_html((string) $r['symlinked_entries']).'; oversized or byte-limited files skipped: '.esc_html((string) $r['skipped_large_files']).'.</p>';
  if ($r['status'] === 'partial') { echo '<p><strong>Incomplete scan:</strong> some files or directories were not verified. Zero findings is not a clean bill of health.</p>'; }
  foreach (($r['examples'] ?? []) as $example) {
   echo '<p><code>'.esc_html($example['file']).'</code>: '.esc_html($example['issue']).'</p>';
  }
  echo '<p>Results require review. Modified or extra files may have legitimate explanations. Only WordPress core is covered; plugins, themes, uploads and database content are excluded. No files are changed or deleted. Background results keep aggregate counts only.</p>';
 }
}
