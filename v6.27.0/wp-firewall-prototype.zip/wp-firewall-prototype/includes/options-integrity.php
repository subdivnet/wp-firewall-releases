<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__.'/options-snapshot.php';
require_once __DIR__.'/observed-returns.php';
require_once __DIR__.'/observed-reversions.php';
require_once __DIR__.'/bulk-changes.php';
/** Independent single-site policy-1 reference. All public projections are aggregate. */
final class WFP_Options_Integrity {
 const REVISION=1;
 const MAX_ITEMS=7;
 const MAX_BYTES=4194304;
 const STATE='wfp_site_options_fingerprints_v1';
 const LOCK='wfp_site_options_lock_v1';
 const HOOK='wfp_site_options_scan';
 public static function init() {
  add_action('init',[__CLASS__,'ensure_schedule']); add_action(self::HOOK,[__CLASS__,'scan']);
  add_action('admin_post_wfp_site_options',[__CLASS__,'manual']);
  if(function_exists('register_deactivation_hook')) { register_deactivation_hook(WFP_Observer::PLUGIN_FILE,[__CLASS__,'deactivate']); }
 }
 public static function ensure_schedule() { if(!wp_next_scheduled(self::HOOK)) { wp_schedule_event(time()+60,'hourly',self::HOOK); } }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); }
 public static function manual() {
  if(!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_site_options'); self::scan(); wp_safe_redirect(admin_url('tools.php?page=wfp-observer')); exit;
 }
 private static function unlock($lock) {
  global $wpdb;
  $wpdb->delete($wpdb->options,['option_name'=>self::LOCK,'option_value'=>maybe_serialize($lock)],['%s','%s']);
  wp_cache_delete(self::LOCK,'options'); wp_cache_delete('notoptions','options');
 }
 private static function owns($lock) { return get_option(self::LOCK,false)===$lock && $lock['expires']>=time(); }
 private static function acquire() {
  $old=get_option(self::LOCK,false);
  if($old!==false && (!is_array($old) || !is_string($old['token']??null) || !preg_match('/^[a-f0-9]{32}$/D',$old['token']) || !is_int($old['expires']??null) || $old['expires']<time())) { self::unlock($old); }
  $lock=['token'=>bin2hex(random_bytes(16)),'expires'=>time()+120];
  return add_option(self::LOCK,$lock,'',false) ? $lock : false;
 }
 public static function valid_state($r,$key) {
  if(!is_array($r) || ($r['schema']??null)!==1 || ($r['policy']??null)!==1 || ($r['key_id']??null)!==$key
   || WFP_State_Sanitizer::timestamp($r['time']??null)==='' || $r['time']>gmdate('Y-m-d H:i:s')
   || !is_array($r['items']??null) || count($r['items'])>self::MAX_ITEMS) { return false; }
  foreach($r['items'] as $id=>$digest) { if(!is_string($id) || !preg_match('/^[a-f0-9]{64}$/D',$id) || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D',$digest)) { return false; } }
  return true;
 }
 private static function empty_report() {
  return ['scanner_revision'=>1,'status'=>'unavailable','time_utc'=>gmdate('Y-m-d H:i:s'),'completion_reason'=>'database_unavailable',
   'first_pass_items'=>0,'second_pass_items'=>0,'content_bytes_accounted'=>0,'items_checked'=>0,
   'new_items'=>null,'changed_items'=>null,'left_published_scope'=>null,'previous_items'=>null,'previous_time_utc'=>null,
   'return_tracking'=>'not_tracked','return_tracking_since_utc'=>null,'reappeared_items'=>null,'matching_reappeared_items'=>null,
   'reversion_tracking'=>'not_tracked','reversion_tracking_since_utc'=>null,'reverted_items'=>null];
 }
 private static function remember($r,$lock,$next=null,$expected=null) {
  if(!self::owns($lock)) { $safe=self::empty_report(); $safe['status']='busy'; $safe['completion_reason']='scan_in_progress'; return $safe; }
  $clean=self::clean_report($r);
  if($clean===false) { return self::empty_report(); }
  $rows=self::history(); array_unshift($rows,$clean); $rows=array_slice($rows,0,24);
  // Reference and report history share one option write. A report failure cannot
  // silently advance comparison/return/reversion evidence without its report.
  $saved=get_option(self::STATE,false);
  if($next!==null && $saved!==$expected) { $safe=self::empty_report(); $safe['status']='unstable'; $safe['completion_reason']='changed_during_scan'; return $safe; }
  $bundle=$next!==null ? $next : (is_array($saved)?$saved:[]);
  $bundle['history']=$rows;
  if(!self::owns($lock) || get_option(self::STATE,false)!==$saved) { $safe=self::empty_report(); $safe['status']='unstable'; $safe['completion_reason']='changed_during_scan'; return $safe; }
  update_option(self::STATE,$bundle,false);
  if(get_option(self::STATE,false)!==$bundle) { $safe=self::empty_report(); $safe['completion_reason']='reference_storage_unavailable'; return $safe; }
  return $clean;
 }
 public static function scan() {
  global $wpdb;
  $r=self::empty_report(); $lock=self::acquire();
  if(!$lock) { $r['status']='busy'; $r['completion_reason']='scan_in_progress'; return $r; }
  try {
   // Never apply single-site semantics to a network installation without a policy.
   if(function_exists('is_multisite') && is_multisite()) { $r['completion_reason']='multisite_not_supported'; return self::remember($r,$lock); }
   $salt=wp_salt('auth');
   $key=is_string($salt) && $salt!=='' ? hash_hmac('sha256','wfp-site-options-reference-policy-1',$salt) : '';
   $original=get_option(self::STATE,false);
   $valid=$key!=='' && self::valid_state($original,$key);
   $snapshot=WFP_Options_Snapshot::read($wpdb,$salt);
   if($snapshot['status']!=='complete') {
    $r['completion_reason']=$snapshot['reason']; $r['status']=in_array($snapshot['reason'],['time_limit','single_item_byte_limit','total_byte_limit'],true)?'partial':($snapshot['reason']==='changed_during_scan'?'unstable':'unavailable');
    return self::remember($r,$lock);
   }
   if(!self::owns($lock) || get_option(self::STATE,false)!==$original) { $r['status']='unstable'; $r['completion_reason']='changed_during_scan'; return self::remember($r,$lock); }
   $items=$snapshot['items']; $old=$valid?$original:false;
   $r['status']=$valid?'compared':(is_array($original) && array_key_exists('items',$original)?'reference_reinitialized':'reference_created'); $r['completion_reason']='none';
   $r['items_checked']=count($items); $r['first_pass_items']=count($items); $r['second_pass_items']=count($items); $r['content_bytes_accounted']=$snapshot['bytes_accounted'];
   if($valid) {
    $r['new_items']=count(array_diff_key($items,$old['items'])); $r['left_published_scope']=count(array_diff_key($old['items'],$items)); $r['changed_items']=0;
    foreach($items as $id=>$digest) { if(isset($old['items'][$id]) && !hash_equals($old['items'][$id],$digest)) { $r['changed_items']++; } }
    $r['previous_items']=count($old['items']); $r['previous_time_utc']=$old['time'];
   }
   $returns=WFP_Observed_Returns::returns($old,$items,$r['time_utc']);
   $reversions=WFP_Observed_Reversions::observe($old,$items,$r['time_utc']);
   foreach(['return_tracking','reappeared_items','matching_reappeared_items'] as $field) { $r[$field]=$returns[$field]; }
   $r['return_tracking_since_utc']=$returns['state']['since'];
   foreach(['reversion_tracking','reversion_tracking_since_utc'] as $field) { $r[$field]=$reversions[$field]; } $r['reverted_items']=$reversions['reverted_files'];
   $next=['schema'=>1,'policy'=>1,'key_id'=>$key,'time'=>$r['time_utc'],'items'=>$items,'returns'=>$returns['state'],'reversions'=>$reversions['state']];
   if(!self::owns($lock) || get_option(self::STATE,false)!==$original) { $fail=self::empty_report(); $fail['status']='unstable'; $fail['completion_reason']='changed_during_scan'; return self::remember($fail,$lock); }
   return self::remember($r,$lock,$next,$original);
  } finally { self::unlock($lock); }
 }
 public static function clean_report($raw) {
  if (!is_array($raw) || !in_array($raw['status'] ?? '', ['compared','reference_created','reference_reinitialized','partial','unavailable','unstable'], true)) { return false; }
  $time = WFP_State_Sanitizer::timestamp($raw['time_utc'] ?? null);
  if ($time === '' || $time > gmdate('Y-m-d H:i:s')) { return false; }
  $revision = $raw['scanner_revision'] ?? 1;
  if (!is_int($revision) || $revision < 1 || $revision > self::REVISION) { return false; }
  $safe = ['scanner_revision' => $revision, 'status' => $raw['status'], 'time_utc' => $time];
  $reason = $raw['completion_reason'] ?? 'legacy_unknown';
  if (!in_array($reason, ['none','legacy_unknown','database_unavailable','invalid_database_metadata','item_limit','single_item_byte_limit','total_byte_limit','time_limit','changed_during_scan','reference_storage_unavailable','checkpoint_invalid','checkpoint_unavailable','continuation_unavailable','key_unavailable','multisite_not_supported','report_storage_unavailable'], true)) { return false; }
  $safe['completion_reason'] = $reason;
  foreach (['first_pass_items','second_pass_items','content_bytes_accounted'] as $field) {
   $value = $raw[$field] ?? null; $max = $field === 'content_bytes_accounted' ? self::MAX_BYTES : self::MAX_ITEMS;
   if ($value !== null && (!is_int($value) || $value < 0 || $value > $max)) { return false; }
   $safe[$field] = $value;
  }
  foreach (['items_checked','new_items','changed_items','left_published_scope'] as $key) {
   if ($key !== 'items_checked' && $raw['status'] !== 'compared') { $safe[$key] = null; continue; }
   $value = $raw[$key] ?? null;
   if (!is_int($value) || $value < 0 || $value > self::MAX_ITEMS) { return false; }
   $safe[$key] = $value;
  }
  if ($reason !== 'legacy_unknown') {
   foreach (['first_pass_items','second_pass_items','content_bytes_accounted'] as $field) { if ($safe[$field] === null) { return false; } }
   $finished = in_array($safe['status'], ['compared','reference_created','reference_reinitialized'], true);
   if ($finished && ($reason !== 'none' || $safe['first_pass_items'] !== $safe['items_checked'] || $safe['second_pass_items'] !== $safe['items_checked'])) { return false; }
   if (!$finished && $reason === 'none') { return false; }
  }
  if ($safe['status'] === 'compared' && $safe['new_items'] + $safe['changed_items'] > $safe['items_checked']) { return false; }
  $tracking = $raw['return_tracking'] ?? 'not_tracked';
  if (!in_array($tracking, ['not_tracked','started','restarted','active','limited'], true)) { return false; }
  $safe['return_tracking'] = $tracking;
  $since = $raw['return_tracking_since_utc'] ?? null;
  if ($tracking === 'not_tracked') { if ($since !== null) { return false; } }
  elseif (WFP_State_Sanitizer::timestamp($since) === '' || $since > $time) { return false; }
  $safe['return_tracking_since_utc'] = $since;
  foreach (['reappeared_items','matching_reappeared_items'] as $key) {
   $value = $raw[$key] ?? null;
   if (in_array($tracking, ['active','limited'], true)) {
    if ($safe['status'] !== 'compared' || !is_int($value) || $value < 0 || $value > self::MAX_ITEMS) { return false; }
   } elseif ($value !== null) { return false; }
   $safe[$key] = $value;
  }
  if (in_array($tracking, ['active','limited'], true) && ($safe['reappeared_items'] > $safe['new_items'] || $safe['matching_reappeared_items'] > $safe['reappeared_items'])) { return false; }
  $previous = $raw['previous_items'] ?? null; $previous_time = $raw['previous_time_utc'] ?? null;
  if ($safe['status'] !== 'compared') { $previous = null; $previous_time = null; }
  if (($previous === null) !== ($previous_time === null)) { return false; }
  if ($previous !== null) {
   if (!is_int($previous) || $previous < 0 || $previous > self::MAX_ITEMS
    || WFP_State_Sanitizer::timestamp($previous_time) === '' || $previous_time > $time
    || $previous !== $safe['items_checked'] - $safe['new_items'] + $safe['left_published_scope']) { return false; }
  }
  $safe['previous_items'] = $previous; $safe['previous_time_utc'] = $previous_time;
  $safe['bulk_assessment'] = self::assess($safe);
  return WFP_Observed_Reversions::clean_fields($raw, $safe, 'items');
 }
 public static function assess($r) { return WFP_Bulk_Changes::assess($r,self::MAX_ITEMS); }
 public static function history() {
  $bundle=get_option(self::STATE,[]); $raw=is_array($bundle)?($bundle['history']??[]):[]; if(!is_array($raw)) { return []; } $safe=[];
  foreach(array_slice($raw,0,48) as $r) { $clean=self::clean_report($r); if($clean!==false) { $safe[]=$clean; } }
  $ranked=[]; foreach($safe as $index=>$row) { $ranked[]=['row'=>$row,'index'=>$index]; }
  usort($ranked,function($a,$b) { return strcmp($b['row']['time_utc'],$a['row']['time_utc']) ?: ($a['index']<=>$b['index']); });
  return array_column(array_slice($ranked,0,24),'row');
 }
 public static function status() {
  $history=self::history(); $latest=$history[0]??['status'=>'not_run'];
  return ['latest'=>$latest,'history'=>$history,'reversion_review'=>array_values(array_filter($history,function($r) { return ($r['reverted_items']??0)>0; }))];
 }
 public static function render() {
  $status=self::status(); $r=$status['latest'];
  echo '<h2>Selected site-setting comparisons</h2><p>Seven single-site settings cover registration, active plugins/theme, routing and indexing. Other options, secrets, scheduled-task payloads and network settings are excluded. Initial references are unverified; changes are not malware verdicts. Only protected fingerprints and aggregate counts persist. No automatic action occurs.</p>';
  echo '<p>Latest result: '.esc_html(str_replace('_',' ',$r['status'])).(isset($r['time_utc'])?' at '.esc_html($r['time_utc']).' UTC':'').'.</p>';
  if(isset($r['completion_reason']) && $r['completion_reason']!=='none') { echo '<p>Incomplete coverage: '.esc_html(str_replace('_',' ',$r['completion_reason'])).'. Previous complete reference retained.</p>'; }
  echo '<p>History retains 24 reports. A quiet site may delay hourly cron execution. Limits: seven rows, 1 MiB per setting, 4 MiB over two passes, five seconds checked between queries; a database query itself may take longer.</p>';
  echo '<table class="widefat striped"><thead><tr><th>UTC time</th><th>Result</th><th>Checked</th><th>New</th><th>Changed</th><th>Left scope</th><th>Returned</th><th>Matching return</th><th>Reverted</th></tr></thead><tbody>';
  foreach($status['history'] as $row) {
   echo '<tr><td>'.esc_html($row['time_utc']).'</td><td>'.esc_html(str_replace('_',' ',$row['status'])).'</td>';
   foreach(['items_checked','new_items','changed_items','left_published_scope','reappeared_items','matching_reappeared_items','reverted_items'] as $f) { echo '<td>'.esc_html($row[$f]===null?'Not compared':(string)$row[$f]).'</td>'; } echo '</tr>';
  }
  echo '</tbody></table>'; WFP_Observed_Reversions::render($status,'items','selected settings');
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_site_options">'; wp_nonce_field('wfp_site_options'); submit_button('Compare selected site settings','secondary'); echo '</form>';
 }
}
