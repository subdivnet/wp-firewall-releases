<?php
/** Pure staged lockout state machine. No WordPress hooks, IP reads or live writes. */
final class WFP_Login_Lockout_Policy {
 const FAILURES=5;const WINDOW=900;const LOCK=900;const MAX_IDENTITIES=2048;
 public static function defaults(){return ['schema'=>1,'enabled'=>false,'recovery_hash'=>null,'recovery_confirmed'=>false];}
 public static function empty_state(){return ['schema'=>1,'entries'=>[]];}
 public static function secret_hash($secret){return is_string($secret)&&preg_match('/^[A-Za-z0-9_-]{43}$/D',$secret)?hash('sha256',$secret):null;}
 public static function arm($config,$confirmed){
  if(!self::config_valid($config)||!is_string($config['recovery_hash'])||!preg_match('/^[a-f0-9]{64}$/D',$config['recovery_hash'])||$confirmed!==true)return false;
  $config['enabled']=true;$config['recovery_confirmed']=true;return $config;
 }
 private static function config_valid($c){
  return is_array($c)&&count($c)===4&&($c['schema']??null)===1&&is_bool($c['enabled']??null)&&is_bool($c['recovery_confirmed']??null)&&array_key_exists('recovery_hash',$c)&&($c['recovery_hash']===null||(is_string($c['recovery_hash'])&&preg_match('/^[a-f0-9]{64}$/D',$c['recovery_hash'])));
 }
 private static function state_valid($s,$now){
  if(!is_array($s)||count($s)!==2||($s['schema']??null)!==1||!is_array($s['entries']??null)||count($s['entries'])>self::MAX_IDENTITIES)return false;
  foreach($s['entries'] as $key=>$e){
   if(!is_string($key)||!preg_match('/^[a-f0-9]{64}$/D',$key)||!is_array($e)||count($e)!==3)return false;
   foreach(['first','failures','locked_until'] as $f)if(!is_int($e[$f]??null)||$e[$f]<0)return false;
   if($e['first']>$now||$e['failures']>self::FAILURES||$e['locked_until']>$now+self::LOCK||($e['locked_until']>0&&$e['failures']!==self::FAILURES))return false;
  }
  return true;
 }
 public static function snapshot_valid($config,$state,$now){return is_int($now)&&$now>0&&self::config_valid($config)&&self::state_valid($state,$now);}
 public static function decision($config,$state,$identity,$now,$owner_session=false,$classic_login=true){
  // OFF is unconditional: callers must not collect an identity merely to call us.
  if(is_array($config)&&($config['enabled']??false)===false)return ['allow'=>true,'reason'=>'disabled'];
  if($owner_session===true)return ['allow'=>true,'reason'=>'existing_owner_session'];
  if($classic_login!==true)return ['allow'=>true,'reason'=>'outside_classic_login_scope'];
  if(!self::config_valid($config)||!$config['recovery_confirmed']||$config['recovery_hash']===null||!is_int($now)||$now<1||!is_string($identity)||!preg_match('/^[a-f0-9]{64}$/D',$identity)||!self::state_valid($state,$now))return ['allow'=>true,'reason'=>'unavailable'];
  $entry=$state['entries'][$identity]??null;
  if($entry&&$entry['locked_until']>$now)return ['allow'=>false,'reason'=>'temporary_lockout','until'=>$entry['locked_until']];
  return ['allow'=>true,'reason'=>'within_limit'];
 }
 public static function failed($config,$state,$identity,$now,$owner_session=false,$classic_login=true){
  $decision=self::decision($config,$state,$identity,$now,$owner_session,$classic_login);
  if(!$decision['allow']||$decision['reason']!=='within_limit')return ['changed'=>false,'state'=>$state,'reason'=>$decision['reason']];
  $next=$state;
  foreach($next['entries'] as $key=>$e)if($e['first']+self::WINDOW<=$now&&$e['locked_until']<=$now)unset($next['entries'][$key]);
  if(!isset($next['entries'][$identity])&&count($next['entries'])>=self::MAX_IDENTITIES)return ['changed'=>false,'state'=>$state,'reason'=>'capacity_limited'];
  $e=$next['entries'][$identity]??['first'=>$now,'failures'=>0,'locked_until'=>0];
  $e['failures']=min(self::FAILURES,$e['failures']+1);
  if($e['failures']===self::FAILURES)$e['locked_until']=$now+self::LOCK;
  $next['entries'][$identity]=$e;return ['changed'=>true,'state'=>$next,'reason'=>'failure_recorded'];
 }
 public static function succeeded($config,$state,$identity,$now){
  $decision=self::decision($config,$state,$identity,$now);
  if(!$decision['allow']||$decision['reason']!=='within_limit')return ['changed'=>false,'state'=>$state];
  $next=$state;unset($next['entries'][$identity]);return ['changed'=>$next!==$state,'state'=>$next];
 }
 public static function recover($config,$state,$secret){
  $hash=self::secret_hash($secret);
  if(!self::config_valid($config)||!$config['enabled']||!$config['recovery_confirmed']||$hash===null||$config['recovery_hash']===null||!hash_equals($config['recovery_hash'],$hash))return false;
  // One-time recovery disables enforcement and burns the recovery binding. A
  // fresh saved code and explicit owner switch are required to enable again.
  return ['config'=>self::defaults(),'state'=>self::empty_state()];
 }
}
