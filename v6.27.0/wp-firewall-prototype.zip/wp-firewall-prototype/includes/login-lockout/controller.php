<?php
require_once __DIR__.'/store.php';

/** WordPress adapter for the owner-controlled, default-off login lockout. */
final class WFP_Login_Lockout_Controller {
 private $store;private $counted=false;
 function __construct($store){$this->store=$store;}
 public static function site(){
  global $wpdb;
  static $controller;
  if($controller===null)$controller=new self(new WFP_Lockout_Store(new WFP_Lockout_Option_Backend($wpdb,$wpdb->options)));
  return $controller;
 }
 function register(){
  // One accepted argument deliberately excludes username/plaintext password.
  add_filter('authenticate',[$this,'authenticate'],PHP_INT_MAX,1);
  add_action('login_form_wfp_unlock',[$this,'recovery_page']);
  add_action('admin_post_wfp_lockout_prepare',[$this,'prepare_action']);
  add_action('admin_post_wfp_lockout_enable',[$this,'enable_action']);
  add_action('admin_post_wfp_lockout_disable',[$this,'disable_action']);
 }
 private function identity(){
  $address=$_SERVER['REMOTE_ADDR']??null;
  if(!is_string($address)||filter_var($address,FILTER_VALIDATE_IP)===false)return null;
  return hash_hmac('sha256',"wfp-lockout-network-v1\0".home_url('/')."\0".$address,wp_salt('auth'));
 }
 private function classic_login(){
  foreach(['REST_REQUEST','XMLRPC_REQUEST','DOING_AJAX','WP_CLI'] as $constant)if(defined($constant)&&constant($constant))return false;
  return ($GLOBALS['pagenow']??null)==='wp-login.php'&&($_SERVER['REQUEST_METHOD']??'')==='POST'&&($_REQUEST['action']??'login')==='login';
 }
 function authenticate($user){
  if(!$this->classic_login())return $user;
  try{
   $now=time();$owner=is_user_logged_in()&&current_user_can('manage_options');$identity=function(){return $this->identity();};
   $d=$this->store->decision($identity,$now,$owner,true);
   if(!$d['allow'])return new WP_Error('wfp_temporary_lockout','Too many failed login attempts. Wait up to 15 minutes, or use the owner recovery page.');
   if($d['reason']!=='within_limit')return $user;
   if($user instanceof WP_User){$this->store->succeeded($identity,$now,$owner,true);}
   elseif(is_wp_error($user)&&!$this->counted&&array_intersect($user->get_error_codes(),['incorrect_password','invalid_username','invalid_email'])){
    $this->counted=true;$this->store->failed($identity,$now,$owner,true);
   }
  }catch(Throwable $e){/* Unavailable enforcement fails open, without logging request/identity/error details. */}
  return $user;
 }
 private function guard($action){
  return ($_SERVER['REQUEST_METHOD']??'')==='POST'&&is_ssl()&&current_user_can('manage_options')&&isset($_POST['_wpnonce'])&&is_string($_POST['_wpnonce'])&&wp_verify_nonce(wp_unslash($_POST['_wpnonce']),$action);
 }
 function owner_change($action){
  if(!in_array($action,['prepare','enable','disable'],true)||!$this->guard('wfp_lockout_'.$action))return ['status'=>'refused'];
  try{
   if($action==='prepare'){
    $secret=rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');
    $result=$this->store->prepare_recovery(WFP_Login_Lockout_Policy::secret_hash($secret));
    if($result['status']==='saved')$result['recovery_code']=$secret;
    return $result;
   }
   if($action==='enable'){
    if(($_POST['wfp_code_saved']??null)!=='yes'||($_POST['wfp_network_understood']??null)!=='yes')return ['status'=>'refused'];
    $code=$_POST['wfp_enable_code']??null;
    return $this->store->enable(true,is_string($code)&&strlen($code)===43?wp_unslash($code):null);
   }
   return $this->store->disable();
  }catch(Throwable $e){return ['status'=>'unavailable'];}
 }
 private function private_headers(){
  nocache_headers();header('Referrer-Policy: no-referrer');header('X-Frame-Options: DENY');
  header("Content-Security-Policy: default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
  header('Content-Type: text/html; charset=UTF-8');
 }
 private function owner_result($action){
  $this->private_headers();$r=$this->owner_change($action);
  echo '<!doctype html><html><head><title>Firewall login protection</title></head><body><h1>Login protection</h1>';
  if(isset($r['recovery_code'])){
   echo '<p>Save this recovery code privately before turning protection on. It is shown once and is never emailed. If this page is lost, turn protection off and prepare a new code.</p><p><code>'.esc_html($r['recovery_code']).'</code></p><p>Owner recovery page: <a href="'.esc_url(site_url('wp-login.php?action=wfp_unlock','login')).'">Open recovery page</a>. Bookmark the page; do not put the code in its URL.</p>';
  }else echo '<p>'.esc_html(in_array($r['status'],['saved','unchanged'],true)?'Setting saved.':'Setting not changed. Review the current status before trying again.').'</p>';
  echo '<p><a href="'.esc_url(admin_url('admin.php?page=wp-firewall&tab=settings')).'">Return to Firewall settings</a></p></body></html>';exit;
 }
 function prepare_action(){$this->owner_result('prepare');}
 function enable_action(){$this->owner_result('enable');}
 function disable_action(){$this->owner_result('disable');}
 function render(){
  if(!current_user_can('manage_options'))return;
  try{$s=$this->store->status(time());}catch(Throwable $e){$s=['phase'=>'unavailable'];}
  echo '<section><h2>Login protection</h2><p>Off by default. When you turn it on, five failed attempts from the same network address within 15 minutes temporarily stop standard WordPress logins from that address for 15 minutes. Blocked attempts do not extend the wait.</p><p>People sharing a network or a proxy may share a limit. REST, XML-RPC, application passwords and custom sign-in pages are outside this first version. Your existing signed-in administrator session remains usable.</p>';
  echo '<p>Status: '.esc_html(['off'=>'Off','prepared'=>'Off — recovery code prepared','on'=>'On','unavailable'=>'Unavailable — protection cannot be relied on'][$s['phase']]).'.</p>';
  echo '<p><a href="'.esc_url(site_url('wp-login.php?action=wfp_unlock','login')).'">Owner recovery page</a> accepts your saved code and turns protection off. Check that you can open this page before enabling.</p>';
  if(!is_ssl()){echo '<p>HTTPS is required to change protection or use recovery.</p></section>';return;}
  if($s['phase']==='off')$this->form('prepare','Prepare private recovery code');
  if($s['phase']==='prepared')$this->form('enable','Turn on login protection',true);
  if(in_array($s['phase'],['prepared','on'],true))$this->form('disable','Turn off and discard recovery code');
  echo '</section>';
 }
 private function form($action,$label,$confirm=false){
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_lockout_'.esc_attr($action).'">';
  echo str_replace('id="_wpnonce"','id="wfp-lockout-'.esc_attr($action).'-nonce"',wp_nonce_field('wfp_lockout_'.$action,'_wpnonce',true,false));
  if($confirm)echo '<p><label><input type="checkbox" name="wfp_code_saved" value="yes" required> I saved my private recovery code and checked the recovery page.</label></p><p><label>Confirm your saved recovery code <input type="password" name="wfp_enable_code" minlength="43" maxlength="43" autocomplete="off" required></label></p><p><label><input type="checkbox" name="wfp_network_understood" value="yes" required> I understand that shared networks or proxies may affect other people signing in.</label></p>';
  echo '<button type="submit">'.esc_html($label).'</button></form>';
 }
 function recovery_result(){
  if(!is_ssl())return 'HTTPS is required. No setting changed.';
  if(($_SERVER['REQUEST_METHOD']??'')!=='POST')return null;
  if(!isset($_POST['_wpnonce'])||!is_string($_POST['_wpnonce'])||!wp_verify_nonce(wp_unslash($_POST['_wpnonce']),'wfp_lockout_recover'))return 'Recovery not accepted. No setting changed.';
  $secret=$_POST['wfp_recovery_code']??null;
  if(!is_string($secret)||strlen($secret)!==43)return 'Recovery not accepted. No setting changed.';
  try{$r=$this->store->recover(wp_unslash($secret));}catch(Throwable $e){return 'Recovery unavailable. Keep an existing administrator session open; no success is assumed.';}
  return $r['status']==='saved'?'Login protection is off. The recovery code has been discarded; save a new code before enabling again.':'Recovery not accepted or unavailable. No success is assumed; an existing administrator session can still turn protection off.';
 }
 function recovery_page(){
  $this->private_headers();$message=$this->recovery_result();
  echo '<!doctype html><html><head><title>Firewall owner recovery</title></head><body><h1>Owner login recovery</h1><p>This only turns Firewall login protection off. It does not reset your WordPress password or bypass another security product.</p>';
  if($message!==null)echo '<p>'.esc_html($message).'</p>';
  if(is_ssl()){
   echo '<form method="post" action="'.esc_url(site_url('wp-login.php?action=wfp_unlock','login')).'">';wp_nonce_field('wfp_lockout_recover');
   echo '<label>Private recovery code <input type="password" name="wfp_recovery_code" minlength="43" maxlength="43" autocomplete="off" required></label><button type="submit">Turn off login protection</button></form>';
  }
  echo '<p><a href="'.esc_url(wp_login_url()).'">Return to sign in</a></p></body></html>';exit;
 }
}
