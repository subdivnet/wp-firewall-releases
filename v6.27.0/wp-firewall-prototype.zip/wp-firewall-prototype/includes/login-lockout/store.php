<?php
require_once __DIR__.'/policy.php';

/** Dedicated option row. No hooks, login attempts or site access on inclusion. */
final class WFP_Lockout_Option_Backend {
 private $db; private $table;
 const OPTION='wfp_login_lockout_v1';
 function __construct($db,$table){
  if(!is_string($table)||!preg_match('/^[A-Za-z0-9_]+$/D',$table))throw new InvalidArgumentException('Invalid option table');
  $this->db=$db;$this->table=$table;
 }
 private function quietly($operation){
  $previous=$this->db->suppress_errors(true);
  try{return $operation();}catch(Throwable $e){return false;}
  finally{$this->db->suppress_errors($previous);}
 }
 function read(){
  return $this->quietly(function(){
   $value=$this->db->get_var($this->db->prepare('SELECT option_value FROM `'.$this->table.'` WHERE option_name=%s',self::OPTION));
   return $this->db->last_error!==''?false:$value;
  });
 }
 function compare_exchange($before,$after){
  $n=$this->quietly(function()use($before,$after){
   if($before===null){
    $sql=$this->db->prepare('INSERT IGNORE INTO `'.$this->table.'` (option_name,option_value,autoload) VALUES (%s,%s,%s)',self::OPTION,$after,'no');
   }else{
    // Binary equality avoids collation treating two different JSON values alike.
    $sql=$this->db->prepare('UPDATE `'.$this->table.'` SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s',$after,self::OPTION,$before);
   }
   return $this->db->query($sql);
  });
  if($n===false)return 'unavailable';
  if($n!==1)return 'conflict';
  if(function_exists('wp_cache_delete'))wp_cache_delete(self::OPTION,'options');
  return 'written';
 }
}

/** All config and attempt transitions share one compare-and-exchange record. */
final class WFP_Lockout_Store {
 private $backend;
 function __construct($backend){$this->backend=$backend;}
 private static function decode($raw){
  if($raw===null)return ['config'=>WFP_Login_Lockout_Policy::defaults(),'state'=>WFP_Login_Lockout_Policy::empty_state()];
  if(!is_string($raw)||strlen($raw)>524288)return false;
  $record=json_decode($raw,true,8);
  return is_array($record)&&count($record)===2&&is_array($record['config']??null)&&array_key_exists('state',$record)?$record:false;
 }
 private function change($transition){
  // Bounded optimistic retry; every conflict reloads config, so recovery cannot
  // be undone by an in-flight failure based on a formerly enabled snapshot.
  for($i=0;$i<3;$i++){
   $raw=$this->backend->read();$record=self::decode($raw);
   if($record===false)return ['status'=>'unavailable'];
   $next=$transition($record);
   if($next===false)return ['status'=>'refused'];
   if($next===$record)return ['status'=>'unchanged'];
   $encoded=json_encode($next,JSON_UNESCAPED_SLASHES);
   if(!is_string($encoded)||strlen($encoded)>524288)return ['status'=>'unavailable'];
   $result=$this->backend->compare_exchange($raw,$encoded);
   if($result==='written')return ['status'=>'saved'];
   if($result!=='conflict')return ['status'=>'unavailable'];
  }
  return ['status'=>'contended'];
 }
 function prepare_recovery($hash){
  if(!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash))return ['status'=>'refused'];
  return $this->change(function($r)use($hash){
   // Never silently replace an enabled or corrupt configuration.
   if($r['config']!==WFP_Login_Lockout_Policy::defaults()||$r['state']!==WFP_Login_Lockout_Policy::empty_state())return false;
   $r['config']['recovery_hash']=$hash;return $r;
  });
 }
 function enable($confirmed,$secret){
  $hash=WFP_Login_Lockout_Policy::secret_hash($secret);
  if($hash===null)return ['status'=>'refused'];
  return $this->change(function($r)use($confirmed,$hash){
  $saved=$r['config']['recovery_hash']??null;
  if(($r['config']['enabled']??null)!==false||$r['state']!==WFP_Login_Lockout_Policy::empty_state()
   ||!is_string($saved)||!hash_equals($saved,$hash))return false;
  $config=WFP_Login_Lockout_Policy::arm($r['config'],$confirmed);
  if($config===false)return false;$r['config']=$config;return $r;
 });}
 function disable(){return $this->change(function($r){return ['config'=>WFP_Login_Lockout_Policy::defaults(),'state'=>WFP_Login_Lockout_Policy::empty_state()];});}
 function recover($secret){return $this->change(function($r)use($secret){return WFP_Login_Lockout_Policy::recover($r['config'],$r['state'],$secret);});}
 function status($now){
  $r=self::decode($this->backend->read());
  if($r===false||!WFP_Login_Lockout_Policy::snapshot_valid($r['config'],$r['state'],$now))return ['phase'=>'unavailable'];
  $locks=0;foreach($r['state']['entries'] as $e)if($e['locked_until']>$now)$locks++;
  return ['phase'=>$r['config']['enabled']?'on':($r['config']['recovery_hash']!==null?'prepared':'off'),'tracked'=>count($r['state']['entries']),'locked'=>$locks];
 }
 function decision($identity,$now,$owner=false,$classic=true){
  $r=self::decode($this->backend->read());
  if($r===false)return ['allow'=>true,'reason'=>'unavailable'];
  if(($r['config']['enabled']??false)!==true||$owner===true||$classic!==true)return WFP_Login_Lockout_Policy::decision($r['config'],$r['state'],null,$now,$owner,$classic);
  // The caller supplies a lazy salted identity, never a raw address. OFF does
  // not invoke it, including when the option does not exist yet.
  return WFP_Login_Lockout_Policy::decision($r['config'],$r['state'],$identity(),$now,$owner,$classic);
 }
 function failed($identity,$now,$owner=false,$classic=true){return $this->change(function($r)use($identity,$now,$owner,$classic){
  if(($r['config']['enabled']??false)!==true||$owner===true||$classic!==true)return $r;
  $result=WFP_Login_Lockout_Policy::failed($r['config'],$r['state'],$identity(),$now,$owner,$classic);
  if(!$result['changed'])return $r;$r['state']=$result['state'];return $r;
 });}
 function succeeded($identity,$now,$owner=false,$classic=true){return $this->change(function($r)use($identity,$now,$owner,$classic){
  if(($r['config']['enabled']??false)!==true||$owner===true||$classic!==true)return $r;
  $result=WFP_Login_Lockout_Policy::succeeded($r['config'],$r['state'],$identity(),$now);
  if(!$result['changed'])return $r;$r['state']=$result['state'];return $r;
 });}
}
