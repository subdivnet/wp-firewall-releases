<?php
if(!defined('ABSPATH'))exit;
/** Read-only runtime release evidence. Never returns log text or accepts a request-supplied path. */
final class WFP_Release_Evidence {
 const MAX_LOG_BYTES=131072;
 const MAX_LINE_BYTES=4096;
 const LOG_SCOPE_OPTION='wfp_release_log_scope_v1';
 public static function init(){
  add_action('rest_api_init',function(){register_rest_route('wfp/v1','/release-evidence',['methods'=>'GET','permission_callback'=>function(){return current_user_can('manage_options');},'callback'=>function(){return rest_ensure_response(self::report());}]);});
  add_action('admin_post_wfp_bind_release_log',[__CLASS__,'bind_action']);
 }
 private static function site_key(){return hash_hmac('sha256','wfp-release-log-site-v1|'.home_url(),wp_salt('auth'));}
 public static function bind_configured_log(){
  if(!current_user_can('manage_options'))throw new RuntimeException('permission_required');
  if(!defined('WP_DEBUG')||WP_DEBUG!==true||!defined('WP_DEBUG_DISPLAY')||WP_DEBUG_DISPLAY!==false||!defined('WP_DEBUG_LOG')||!is_string(WP_DEBUG_LOG)||WP_DEBUG_LOG==='')throw new RuntimeException('private_log_unavailable');
  $check=self::read_log(WP_DEBUG_LOG,ABSPATH);
  if(empty($check['available'])||empty($check['complete']))throw new RuntimeException('private_log_unavailable');
  $scope=['schema'=>1,'site_key'=>self::site_key(),'path_sha256'=>hash('sha256',WP_DEBUG_LOG)];
  if(!update_option(self::LOG_SCOPE_OPTION,$scope,false)&&get_option(self::LOG_SCOPE_OPTION)!==$scope)throw new RuntimeException('scope_write_failed');
 }
 public static function bind_action(){
  if(!current_user_can('manage_options'))wp_die('Insufficient permissions');
  check_admin_referer('wfp_bind_release_log');
  if(($_POST['wfp_release_log_consent']??null)!=='yes')wp_die('Confirm the private-log check first.');
  try{self::bind_configured_log();}catch(Throwable $error){wp_die('The private log was not connected. Confirm private logging is available and error display is off.');}
  wp_safe_redirect(admin_url('admin.php?page=wp-firewall&tab=settings&wfp_log_bound=1'));exit;
 }
 public static function settings_html(){
  $bound=self::private_log();
  echo '<section class="wfp-check"><h3>Private release-log checks</h3><p>'.(!empty($bound['available'])?'Connected to this site’s configured private log.':'Not connected.').'</p><p>Connect only after confirming the configured log belongs to this site, is outside public website roots and has private permissions. Only dates, types, source areas and counts are returned; log text and paths are never displayed.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_bind_release_log">';
  wp_nonce_field('wfp_bind_release_log');
  echo '<p><label><input type="checkbox" name="wfp_release_log_consent" value="yes" required> Allow read-only checks of this site’s configured private log.</label></p>';
  submit_button('Connect configured private log','secondary','submit',true,['id'=>'wfp-release-log-submit']);
  echo '</form><p>This saves a site-specific binding only. It does not change WordPress logging, display settings or enforcement.</p></section>';
 }
 private static function unavailable(){return ['available'=>false,'complete'=>false,'checked_at_utc'=>gmdate('Y-m-d H:i:s')];}
 public static function private_log(){
  if(!function_exists('home_url')||!defined('WP_DEBUG')||WP_DEBUG!==true||!defined('WP_DEBUG_DISPLAY')||WP_DEBUG_DISPLAY!==false||!defined('WP_DEBUG_LOG')||!is_string(WP_DEBUG_LOG)||WP_DEBUG_LOG==='')return self::unavailable();
  $scope=get_option(self::LOG_SCOPE_OPTION,null);
  if(!is_array($scope)||($scope['schema']??null)!==1||!is_string($scope['site_key']??null)||!is_string($scope['path_sha256']??null)||!preg_match('/^[a-f0-9]{64}$/D',$scope['path_sha256']))return self::unavailable();
  if(!hash_equals(self::site_key(),$scope['site_key'])||!hash_equals($scope['path_sha256'],hash('sha256',WP_DEBUG_LOG)))return self::unavailable();
  return self::read_log(WP_DEBUG_LOG,ABSPATH);
 }
 /** Internal fixture-testable reader; the authenticated route always uses the fixed scope above. */
 public static function read_log($path,$publicRoot){
  $stream=null;
  try{
   if(!is_string($path))return self::unavailable();clearstatcache(true,$path);
   if(is_link($path)||!is_file($path)||!is_readable($path)||is_link(dirname($path)))return self::unavailable();
   $parent=realpath(dirname($path));$public=realpath($publicRoot);
   if(!$parent||!$public||$parent===$public||strpos($parent.'/',rtrim($public,'/').'/')===0)return self::unavailable();
   $stat=lstat($path);$dir=lstat($parent);
   if(!$stat||!$dir||($stat['mode']&0777)!==0600||($dir['mode']&0777)!==0700||$stat['nlink']!==1||$stat['size']>self::MAX_LOG_BYTES)return self::unavailable();
   $stream=@fopen($path,'rb');if(!$stream)return self::unavailable();$opened=fstat($stream);
   if(!$opened||$opened['ino']!==$stat['ino']||$opened['dev']!==$stat['dev'])return self::unavailable();
   $types=['warnings'=>0,'notices'=>0,'deprecations'=>0,'fatal_errors'=>0,'parse_errors'=>0,'recoverable_errors'=>0,'other_php_errors'=>0,'uncaught_errors'=>0,'database_errors'=>0];
   $bytes=0;$lines=0;$other=0;$classified=[];
   while(!feof($stream)){
    $line=fgets($stream,self::MAX_LINE_BYTES+1);if($line===false){if(feof($stream))break;return self::unavailable();}
    $bytes+=strlen($line);if($bytes>self::MAX_LOG_BYTES||strlen($line)>=self::MAX_LINE_BYTES)return self::unavailable();
    $lines++;if(trim($line)==='')continue;
    if(count($classified)>=1024)return self::unavailable();
    $classified[]=self::classify_line($line);
    if(preg_match('/PHP\s+(Warning|Notice|Deprecated|Fatal error|Parse error|Recoverable fatal error|Catchable fatal error|Error|Strict Standards)\s*:/i',$line,$m)){
     $map=['warning'=>'warnings','notice'=>'notices','deprecated'=>'deprecations','fatal error'=>'fatal_errors','parse error'=>'parse_errors','recoverable fatal error'=>'recoverable_errors','catchable fatal error'=>'recoverable_errors','error'=>'other_php_errors','strict standards'=>'other_php_errors'];$types[$map[strtolower($m[1])]]++;
    }elseif(preg_match('/\bUncaught\s+(?:Error|Exception|[^\s:]+(?:Error|Exception))\b/',$line))$types['uncaught_errors']++;
    elseif(stripos($line,'WordPress database error')!==false)$types['database_errors']++;
    else $other++;
   }
   $after=fstat($stream);clearstatcache(true,$path);$named=lstat($path);
   foreach(['ino','dev','size','mtime','ctime'] as $key)if(!$after||!$named||$after[$key]!==$stat[$key]||$named[$key]!==$stat[$key])return self::unavailable();
   if($bytes!==$stat['size'])return self::unavailable();
   return ['available'=>true,'complete'=>true,'checked_at_utc'=>gmdate('Y-m-d H:i:s'),'bytes'=>$bytes,'lines'=>$lines,'error_count'=>array_sum($types),'types'=>$types,'other_lines'=>$other,'classifications'=>$classified];
  }catch(Throwable $error){return self::unavailable();}
  finally{if(is_resource($stream))fclose($stream);}
 }
 /** Only fixed labels and validated dates leave the server; never log substrings or paths. */
 public static function classify_line($line){
  $date=null;
  if(preg_match('/^\[([^\]\r\n]{1,50})\]/',$line,$m)){
   foreach(['!d-M-Y H:i:s T','!Y-m-d H:i:s T','!Y-m-d H:i:s'] as $format){
    $dt=DateTimeImmutable::createFromFormat($format,$m[1],new DateTimeZone('UTC'));
    $errors=DateTimeImmutable::getLastErrors();
    if($dt&&($errors===false||($errors['warning_count']===0&&$errors['error_count']===0))){$date=$dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');break;}
   }
  }
  $type='other';
  if(preg_match('/PHP\s+Warning\s*:/i',$line))$type='warning';
  elseif(preg_match('/PHP\s+Notice\s*:/i',$line))$type='notice';
  elseif(preg_match('/PHP\s+Deprecated\s*:/i',$line))$type='deprecation';
  elseif(preg_match('/PHP\s+(?:Fatal error|Parse error|Recoverable fatal error|Catchable fatal error|Error|Strict Standards)\s*:|\bUncaught\s+\S*(?:Error|Exception)\b|WordPress database error/i',$line))$type='error';
  elseif(preg_match('/(?:verif|test|marker|logging|debug.log)/i',$line))$type='verification marker';
  $area='unidentified';
  if(preg_match('~(?:wp-content[/\\\\]plugins[/\\\\]wp-firewall-prototype(?:[/\\\\]|\b)|\bWFP_[A-Za-z_]+\b|\bWP Firewall\b)~i',$line))$area='WP Firewall';
  elseif(preg_match('~wp-content[/\\\\](?:mu-plugins|plugins)[/\\\\]([a-z0-9_-]{1,80})(?:[/\\\\]|\.php\b)~i',$line,$p))$area='plugin: '.strtolower($p[1]);
  elseif(preg_match('~wp-content[/\\\\]themes[/\\\\]([a-z0-9_-]{1,80})[/\\\\]~i',$line,$p))$area='theme: '.strtolower($p[1]);
  elseif(preg_match('~[/\\\\](?:wp-includes|wp-admin)[/\\\\]~i',$line))$area='WordPress core';
  elseif($type==='verification marker')$area='logging verification';
  elseif(preg_match('/\b(?:WP_DEBUG|debug.log|logging)\b/i',$line))$area='logging configuration';
  return ['date_utc'=>$date,'type'=>$type,'source_area'=>$area];
 }
 public static function report(){
  $checks=['available'=>false];
  if(is_callable(['WFP_Observer','self_test'])){
   $result=WFP_Observer::self_test();
   if(is_int($result['total']??null)&&is_int($result['passed']??null)&&$result['total']>0&&$result['total']<=100&&$result['passed']>=0&&$result['passed']<=$result['total'])$checks=['available'=>true,'passed'=>$result['passed'],'total'=>$result['total']];
  }
  return ['checked_at_utc'=>gmdate('Y-m-d H:i:s'),'diagnostics'=>$checks,'private_log'=>self::private_log()];
 }
 public static function html(){
  $report=self::report();$checks=$report['diagnostics'];$log=$report['private_log'];
  $text='<h3>Release checks</h3><p>Internal self-checks: '.(!empty($checks['available'])?esc_html((string)$checks['passed']).' of '.esc_html((string)$checks['total']).' passed.':'Not checked yet.').'</p>';
  if(empty($log['available'])||empty($log['complete']))return $text.'<p>Private PHP log: Not checked yet. A complete, correctly scoped read was unavailable; this is not a clean-log result.</p>';
  $text.='<p>Private PHP log checked at '.esc_html($log['checked_at_utc']).' UTC: '.esc_html((string)$log['error_count']).' recognized PHP or database errors across '.esc_html((string)$log['lines']).' lines. Other lines: '.esc_html((string)$log['other_lines']).'. No log text is displayed.</p>';
  foreach($log['types'] as $name=>$count)if($count)$text.='<p>'.esc_html(ucfirst(str_replace('_',' ',$name))).': '.esc_html((string)$count).'.</p>';
  return $text;
 }
}
WFP_Release_Evidence::init();
