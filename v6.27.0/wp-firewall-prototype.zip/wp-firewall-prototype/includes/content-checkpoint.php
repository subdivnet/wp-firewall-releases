<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Private transport for future multi-request content scans.
 * Used by bounded multi-request scans. Never writes options or advances a reference.
 */
final class WFP_Content_Checkpoint {
 const TTL = 1800;
 const MAX_ITEMS = 10000;
 const MAX_BYTES = 33554432;
 const MAX_JSON = 3000000;
 private static function supported() {
  return function_exists('openssl_encrypt') && function_exists('openssl_decrypt')
   && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
 }
 private static function valid($state, $now) {
  if (!is_array($state) || count($state) !== 10
   || ($state['schema'] ?? null) !== 1 || ($state['revision'] ?? null) !== 4
   || !is_int($state['started'] ?? null) || $state['started'] < 1 || $state['started'] > $now
   || $now - $state['started'] >= self::TTL
   || !is_int($state['ceiling'] ?? null) || $state['ceiling'] < 0
   || !is_int($state['cursor'] ?? null) || $state['cursor'] < 0 || $state['cursor'] > $state['ceiling']
   || !in_array($state['pass'] ?? null, [1, 2], true)
   || !is_int($state['bytes'] ?? null) || $state['bytes'] < 0 || $state['bytes'] > self::MAX_BYTES
   || !is_string($state['reference'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $state['reference'])) { return false; }
  foreach (['first', 'second'] as $field) {
   if (!is_array($state[$field] ?? null) || count($state[$field]) > self::MAX_ITEMS) { return false; }
   foreach ($state[$field] as $key => $digest) {
    if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key)
     || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) { return false; }
   }
  }
  if ($state['pass'] === 1 && $state['second'] !== []) { return false; }
  if ($state['pass'] === 2 && count($state['second']) > count($state['first'])) { return false; }
  return true;
 }
 /** Caller supplies a site-specific secret and a digest binding the original reference. */
 public static function seal($state, $secret, $now) {
  if (!is_int($now) || !is_string($secret) || strlen($secret) < 32 || !self::supported() || !self::valid($state, $now)) { return false; }
  $json = json_encode($state);
  if (!is_string($json) || strlen($json) > self::MAX_JSON) { return false; }
  $key = hash_hmac('sha256', 'wfp-content-checkpoint-v1', $secret, true);
  $nonce = random_bytes(12); $tag = '';
  $cipher = openssl_encrypt($json, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag, 'wfp-content-checkpoint-v1', 16);
  if (!is_string($cipher) || strlen($tag) !== 16) { return false; }
  return ['schema' => 1, 'payload' => base64_encode($nonce . $tag . $cipher)];
 }
 /** Reject malformed, expired, wrong-key, tampered or reference-mismatched state. */
 public static function open($envelope, $secret, $reference, $now) {
  if (!is_int($now) || !is_string($secret) || strlen($secret) < 32 || !self::supported()
   || !is_string($reference) || !preg_match('/^[a-f0-9]{64}$/D', $reference)
   || !is_array($envelope) || count($envelope) !== 2 || ($envelope['schema'] ?? null) !== 1
   || !is_string($envelope['payload'] ?? null) || strlen($envelope['payload']) > 4 * (int) ceil((self::MAX_JSON + 28) / 3)) { return false; }
  $packed = base64_decode($envelope['payload'], true);
  if (!is_string($packed) || strlen($packed) < 30 || base64_encode($packed) !== $envelope['payload']) { return false; }
  $key = hash_hmac('sha256', 'wfp-content-checkpoint-v1', $secret, true);
  $json = openssl_decrypt(substr($packed, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($packed, 0, 12), substr($packed, 12, 16), 'wfp-content-checkpoint-v1');
  if (!is_string($json) || strlen($json) > self::MAX_JSON) { return false; }
  $state = json_decode($json, true, 16);
  return self::valid($state, $now) && hash_equals($reference, $state['reference']) ? $state : false;
 }
}
