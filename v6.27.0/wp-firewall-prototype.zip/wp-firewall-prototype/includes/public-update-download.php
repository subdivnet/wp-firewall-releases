<?php

require_once __DIR__ . '/public-update-manifest.php';

// The origin and key must come from trusted plugin configuration.
function wfp_fetch_public_release($origin, $public_key, $channel, $installed) {
    if (!preg_match('~\Ahttps://[a-z0-9.-]+\z~i', $origin)
        && $origin !== 'https://raw.githubusercontent.com/subdivnet/wp-firewall-releases/refs/heads/main') {
        return new WP_Error('wfp_public_origin', 'Invalid Firewall release origin.');
    }

    $args = ['timeout' => 15, 'redirection' => 0, 'sslverify' => true];
    $manifest = wp_safe_remote_get($origin . '/release.json', $args + ['limit_response_size' => 4097]);
    $signature = wp_safe_remote_get($origin . '/release.sig', $args + ['limit_response_size' => 1025]);
    if (is_wp_error($manifest) || is_wp_error($signature)
        || wp_remote_retrieve_response_code($manifest) !== 200 || wp_remote_retrieve_response_code($signature) !== 200) {
        return new WP_Error('wfp_public_metadata', 'Firewall release metadata is unavailable.');
    }

    $release = wfp_verify_public_manifest(wp_remote_retrieve_body($manifest), wp_remote_retrieve_body($signature), $public_key, $channel, $installed, time());
    return $release ?: new WP_Error('wfp_public_manifest', 'Firewall release metadata failed verification.');
}

function wfp_public_release_marker(array $release) {
    return 'wfp-public-release://' . $release['version'] . '/' . $release['sha256'];
}

function wfp_download_public_update($origin, $public_key, $channel, $installed, $package) {
    $release = wfp_fetch_public_release($origin, $public_key, $channel, $installed);
    if (is_wp_error($release)) {
        return $release;
    }
    if ($package !== wfp_public_release_marker($release)) {
        return new WP_Error('wfp_public_release', 'Firewall release metadata did not match the requested update.');
    }

    $file = wp_tempnam('wfp-public-release.zip');
    if (!$file) {
        return new WP_Error('wfp_public_temp', 'Could not create a temporary Firewall download.');
    }

    $response = wp_safe_remote_get($origin . '/' . $release['path'], [
        'timeout' => 60, 'redirection' => 0, 'sslverify' => true, 'stream' => true,
        'filename' => $file, 'limit_response_size' => $release['bytes'] + 1,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200 || !wfp_verify_public_package($file, $release)) {
        unlink($file);
        return new WP_Error('wfp_public_package', 'Firewall download did not pass verification.');
    }
    return $file;
}
