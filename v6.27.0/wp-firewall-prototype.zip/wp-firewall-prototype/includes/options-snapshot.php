<?php
if (!defined('ABSPATH')) { exit; }
/** Policy v1, single-site options table only. Not registered or enabled yet. */
final class WFP_Options_Snapshot {
 const POLICY = 1;
 const NAMES = ['users_can_register','default_role','active_plugins','template','stylesheet','permalink_structure','blog_public'];
 const MAX_ITEM_BYTES = 1048576;
 const MAX_BYTES = 4194304;
 const MAX_SECONDS = 5;
 private static function failure($reason) { return ['status'=>'incomplete','reason'=>$reason,'items'=>null]; }
 /** Internal fingerprint map only. Callers must never expose it as telemetry. */
 public static function read($db, $salt) {
  if (!is_string($salt) || $salt === '') { return self::failure('key_unavailable'); }
  $secret = hash_hmac('sha256','wfp-site-options-policy-1',$salt,true);
  $start = microtime(true); $bytes = 0; $first = null;
  $old = $db->suppress_errors(true);
  try {
   $marks=implode(', ',array_fill(0,count(self::NAMES),'%s'));
   $where=$db->prepare("BINARY option_name IN ($marks)",self::NAMES);
   // Only lengths and hashes leave SQL. Observed values are never deserialized.
   $size="OCTET_LENGTH(option_name) + OCTET_LENGTH(COALESCE(option_value, ''))";
   $hash="SHA2(CONCAT(OCTET_LENGTH(option_name), ':', option_name, OCTET_LENGTH(COALESCE(option_value, '')), ':', COALESCE(option_value, '')), 256)";
   for ($pass=0;$pass<2;$pass++) {
    if (microtime(true)-$start >= self::MAX_SECONDS) { return self::failure('time_limit'); }
    $rows=$db->get_results("SELECT option_id AS ID, ($size) AS bytes FROM {$db->options} WHERE $where ORDER BY option_id LIMIT 8",ARRAY_A);
    if ($db->last_error !== '' || !is_array($rows)) { return self::failure('database_unavailable'); }
    if (count($rows)>count(self::NAMES)) { return self::failure('invalid_database_metadata'); }
    $sizes=[]; $pass_bytes=0;
    foreach($rows as $row) {
     $id=filter_var($row['ID'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
     $n=filter_var($row['bytes'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>0]]);
     if ($id===false || $n===false || isset($sizes[$id])) { return self::failure('invalid_database_metadata'); }
     if ($n>self::MAX_ITEM_BYTES) { return self::failure('single_item_byte_limit'); }
     $sizes[$id]=$n; $pass_bytes+=$n;
    }
    if ($bytes+$pass_bytes>self::MAX_BYTES) { return self::failure('total_byte_limit'); }
    if (microtime(true)-$start >= self::MAX_SECONDS) { return self::failure('time_limit'); }
    $current=[];
    if ($sizes) {
     $cases=[]; foreach($sizes as $id=>$n) { $cases[]='WHEN '.$id.' THEN '.$n; }
     $approved='CASE option_id '.implode(' ',$cases).' ELSE -1 END';
     $digests=$db->get_results("SELECT option_id AS ID, ($size) AS bytes, SHA2(option_name, 256) AS identity_digest,
      CASE WHEN ($size) <= ".self::MAX_ITEM_BYTES." AND ($size) = ($approved) THEN $hash ELSE NULL END AS digest
      FROM {$db->options} WHERE $where ORDER BY option_id LIMIT 8",ARRAY_A);
     if ($db->last_error !== '' || !is_array($digests)) { return self::failure('database_unavailable'); }
     if (count($digests)!==count($sizes)) { return self::failure('changed_during_scan'); }
     foreach($digests as $row) {
      $id=filter_var($row['ID'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
      $n=filter_var($row['bytes'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>0]]);
      if ($id===false || !isset($sizes[$id]) || $n!==$sizes[$id]
       || !is_string($row['identity_digest'] ?? null) || !preg_match('/^[a-f0-9]{64}$/Di',$row['identity_digest'])
       || !is_string($row['digest'] ?? null) || !preg_match('/^[a-f0-9]{64}$/Di',$row['digest'])) { return self::failure('changed_during_scan'); }
      $opaque=hash_hmac('sha256','name:'.strtolower($row['identity_digest']),$secret);
      if (isset($current[$opaque])) { return self::failure('invalid_database_metadata'); }
      $current[$opaque]=hash_hmac('sha256',strtolower($row['digest']),$secret);
     }
    }
    ksort($current); $bytes+=$pass_bytes;
    if ($pass===0) { $first=$current; }
    elseif ($first!==$current) { return self::failure('changed_during_scan'); }
   }
   if (microtime(true)-$start >= self::MAX_SECONDS) { return self::failure('time_limit'); }
   return ['status'=>'complete','reason'=>'none','items'=>$first,'rows_checked'=>count($first),'bytes_accounted'=>$bytes,'policy'=>self::POLICY];
  } finally { $db->suppress_errors($old); }
 }
}
