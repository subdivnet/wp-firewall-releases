<?php
if (!defined('ABSPATH')) { exit; }
/** Published-content change detection. Reference snapshots are never called clean. */
require_once __DIR__ . '/content-checkpoint.php';
require_once __DIR__ . '/observed-returns.php';
require_once __DIR__ . '/observed-reversions.php';
require_once __DIR__ . '/bulk-changes.php';
final class WFP_Content_Integrity {
 const REVISION = 4;
 const CHECKPOINT = 'wfp_content_checkpoint_v1';
 const CONTINUE_HOOK = 'wfp_content_integrity_continue';
 const REQUEST_BATCHES = 4;
 const RETURN_WINDOW = 604800;
 const MAX_ABSENT = 2000;
 const HOOK = 'wfp_content_integrity_scan';
 const STATE = 'wfp_content_fingerprints_v1';
 const REPORTS = 'wfp_content_integrity_reports_v1';
 const LOCK = 'wfp_content_integrity_lock_v1';
 const MAX_ITEMS = 10000;
 const BATCH = 50;
 const MAX_ITEM_BYTES = 1048576;
 const MAX_BYTES = 33554432;
 const MAX_SECONDS = 5;
 public static function init() {
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::HOOK, [__CLASS__, 'scheduled_scan']);
  add_action(self::CONTINUE_HOOK, [__CLASS__, 'scheduled_scan']);
  add_action('admin_post_wfp_content_integrity', [__CLASS__, 'manual']);
  if (function_exists('register_deactivation_hook')) { register_deactivation_hook(WFP_Observer::PLUGIN_FILE, [__CLASS__, 'deactivate']); }
 }
 public static function ensure_schedule() {
  $next = wp_next_scheduled(self::HOOK);
  if (!$next) { wp_schedule_event(time() + 60, 'hourly', self::HOOK); return; }
  $last = self::status()['latest'];
  if (isset($last['time_utc']) && ($last['scanner_revision'] ?? 1) !== self::REVISION && $next > time() + 660) { wp_schedule_single_event(time() + 60, self::HOOK); }
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); wp_clear_scheduled_hook(self::CONTINUE_HOOK); }
 public static function scheduled_scan() { return self::scan(true); }
 public static function manual() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_content_integrity');
  self::scan(true);
  wp_safe_redirect(admin_url('tools.php?page=wfp-observer')); exit;
 }
 private static function unlock($lock) {
  global $wpdb;
  // Compare-and-delete only our own lock. A stale worker cannot delete a new lock.
  $wpdb->delete($wpdb->options, ['option_name' => self::LOCK, 'option_value' => maybe_serialize($lock)], ['%s', '%s']);
  wp_cache_delete(self::LOCK, 'options'); wp_cache_delete('notoptions', 'options');
 }
 private static function acquire() {
  $existing = get_option(self::LOCK, false);
  if ($existing !== false && (!is_array($existing) || !isset($existing['token'], $existing['expires'])
   || !is_string($existing['token']) || !preg_match('/^[a-f0-9]{32}$/D', $existing['token'])
   || !is_int($existing['expires']) || $existing['expires'] < time())) { self::unlock($existing); }
  $lock = ['token' => bin2hex(random_bytes(16)), 'expires' => time() + 120];
  return add_option(self::LOCK, $lock, '', false) ? $lock : false;
 }
 public static function valid_state($state, $key_id) {
  if (!is_array($state) || ($state['schema'] ?? null) !== 1 || ($state['key_id'] ?? '') !== $key_id
   || WFP_State_Sanitizer::timestamp($state['time'] ?? null) === '' || $state['time'] > gmdate('Y-m-d H:i:s')
   || !isset($state['items']) || !is_array($state['items']) || count($state['items']) > self::MAX_ITEMS) { return false; }
  foreach ($state['items'] as $key => $digest) {
   if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key) || !is_string($digest) || !preg_match('/^[a-f0-9]{64}$/D', $digest)) { return false; }
  }
  return true;
 }
 /** Observe same-item returns only. No inference that a returned object is malicious. */
 public static function returns($old, $current, $stamp) { return WFP_Observed_Returns::returns($old, $current, $stamp); }
 private static function ceiling() {
  global $wpdb;
  $value = $wpdb->get_var($wpdb->prepare("SELECT MAX(ID) FROM {$wpdb->posts} WHERE post_status = %s AND post_type IN (%s, %s, %s)", 'publish', 'post', 'page', 'product'));
  if ($wpdb->last_error !== '') { return false; }
  if ($value === null) { return 0; }
  return is_numeric($value) && (float) $value <= PHP_INT_MAX && (int) $value >= 0 ? (int) $value : false;
 }
 private static function capture($ceiling, $secret, &$bytes, $start, &$status, &$reason, &$progress, &$partial = null, &$batches = 0) {
  global $wpdb;
  $items = is_array($partial) ? $partial['items'] : []; $cursor = is_array($partial) ? $partial['cursor'] : 0;
  $resumable = is_array($partial);
  $fields = ['post_type', 'post_name', 'post_title', 'post_content', 'post_excerpt'];
  $size_parts = []; $hash_parts = [];
  foreach ($fields as $field) {
   $size_parts[] = "OCTET_LENGTH(COALESCE($field, ''))";
   $hash_parts[] = "OCTET_LENGTH(COALESCE($field, ''))";
   $hash_parts[] = "':'"; $hash_parts[] = "COALESCE($field, '')";
  }
  $size_sql = implode(' + ', $size_parts);
  $hash_sql = "SHA2(CONCAT(" . implode(', ', $hash_parts) . "), 256)";
  while ($cursor < $ceiling) {
   if (microtime(true) - $start >= self::MAX_SECONDS || ($resumable && $batches >= self::REQUEST_BATCHES)) {
    if ($resumable) { $partial = ['items' => $items, 'cursor' => $cursor]; return null; }
    $status = 'partial'; $reason = 'time_limit'; return false;
   }
   $rows = $wpdb->get_results($wpdb->prepare(
    "SELECT ID, ($size_sql) AS bytes FROM {$wpdb->posts}
     WHERE ID > %d AND ID <= %d AND post_status = %s AND post_type IN (%s, %s, %s) ORDER BY ID ASC LIMIT %d",
    $cursor, $ceiling, 'publish', 'post', 'page', 'product', self::BATCH
   ), ARRAY_A);
   if ($wpdb->last_error !== '' || !is_array($rows)) { $status = 'unavailable'; $reason = 'database_unavailable'; return false; }
   if (!$rows) { break; }
   $batch_cursor = $cursor;
   $ids = []; $sizes = []; $batch_bytes = 0;
   foreach ($rows as $row) {
    $id = filter_var($row['ID'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => $cursor + 1, 'max_range' => $ceiling]]);
    $size = filter_var($row['bytes'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => PHP_INT_MAX]]);
    if ($id === false) { $status = 'unavailable'; $reason = 'invalid_database_metadata'; return false; }
    if ($size === false) { $status = 'unavailable'; $reason = 'invalid_database_metadata'; return false; }
    if ($size > self::MAX_ITEM_BYTES) { $status = 'partial'; $reason = 'single_item_byte_limit'; return false; }
    if (count($items) + count($ids) >= self::MAX_ITEMS) { $status = 'partial'; $reason = 'item_limit'; return false; }
    $ids[] = $id; $sizes[] = $size; $batch_bytes += $size; $cursor = $id;
   }
   if ($bytes + $batch_bytes > self::MAX_BYTES) { $status = 'partial'; $reason = 'total_byte_limit'; return false; }
   if (microtime(true) - $start >= self::MAX_SECONDS || ($resumable && $batches >= self::REQUEST_BATCHES)) {
    if ($resumable) { $partial = ['items' => $items, 'cursor' => $batch_cursor]; return null; }
    $status = 'partial'; $reason = 'time_limit'; return false;
   }
   $marks = implode(', ', array_fill(0, count($ids), '%d'));
   $size_cases = []; $size_args = [];
   foreach ($ids as $index => $id) { $size_cases[] = 'WHEN %d THEN %d'; $size_args[] = $id; $size_args[] = $sizes[$index]; }
   $approved_size = 'CASE ID ' . implode(' ', $size_cases) . ' ELSE -1 END';
   $digests = $wpdb->get_results($wpdb->prepare(
    "SELECT ID, ($size_sql) AS bytes, CASE WHEN ($size_sql) <= %d AND ($size_sql) = ($approved_size) THEN $hash_sql ELSE NULL END AS digest
     FROM {$wpdb->posts} WHERE ID IN ($marks) AND post_status = %s AND post_type IN (%s, %s, %s) ORDER BY ID ASC",
    array_merge([self::MAX_ITEM_BYTES], $size_args, $ids, ['publish', 'post', 'page', 'product'])
   ), ARRAY_A);
   if ($wpdb->last_error !== '' || !is_array($digests)) { $status = 'unavailable'; $reason = 'database_unavailable'; return false; }
   if (count($digests) !== count($ids)) { $status = 'unstable'; $reason = 'changed_during_scan'; return false; }
   $bytes += $batch_bytes;
   foreach ($digests as $index => $row) {
    if ((string) ($row['ID'] ?? '') !== (string) $ids[$index]
     || (string) ($row['bytes'] ?? '') !== (string) $sizes[$index]
     || !is_string($row['digest'] ?? null) || !preg_match('/^[a-f0-9]{64}$/iD', $row['digest'])) { $status = 'unstable'; $reason = 'changed_during_scan'; return false; }
    $opaque = hash_hmac('sha256', 'item:' . $ids[$index], $secret);
    $items[$opaque] = hash_hmac('sha256', strtolower($row['digest']), $secret);
    $progress = count($items);
   }
   $batches++;
  }
  return $items;
 }
 public static function scan($resumable = false) {
  global $wpdb;
  $report = ['reversion_tracking'=>'not_tracked', 'reversion_tracking_since_utc'=>null, 'reverted_items'=>null, 'completion_reason' => 'database_unavailable', 'first_pass_items' => 0, 'second_pass_items' => 0, 'content_bytes_accounted' => 0, 'scanner_revision' => self::REVISION, 'return_tracking' => 'not_tracked', 'return_tracking_since_utc' => null, 'reappeared_items' => null, 'matching_reappeared_items' => null, 'status' => 'unavailable', 'time_utc' => gmdate('Y-m-d H:i:s'), 'items_checked' => 0, 'new_items' => null, 'changed_items' => null, 'left_published_scope' => null];
  $lock = self::acquire();
  if (!$lock) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return $report; }
  $previous_errors = $wpdb->suppress_errors(true);
  try {
   $secret = hash_hmac('sha256', 'wfp-content-reference-v1', wp_salt('auth'), true);
   $key_id = hash_hmac('sha256', 'reference-key-check', $secret);
   $original = get_option(self::STATE, false);
   $reference = hash_hmac('sha256', serialize($original), $secret);
   $start = microtime(true); $status = 'unavailable'; $reason = 'database_unavailable'; $batches = 0;
   $job = false; $saved = false;
   if ($resumable) {
    $saved = get_option(self::CHECKPOINT, false);
    if ($saved !== false) {
     $job = WFP_Content_Checkpoint::open($saved, $secret, $reference, time());
     if ($job === false) { $report['completion_reason'] = 'checkpoint_invalid'; return self::finish_job($report, $lock); }
    }
   }
   $ceiling = $job !== false ? $job['ceiling'] : self::ceiling();
   $bytes = $job !== false ? $job['bytes'] : 0;
   if ($ceiling === false) { return self::finish_job($report, $lock, $resumable); }
   if ($resumable && $job === false) {
    $job = ['schema' => 1, 'revision' => self::REVISION, 'started' => time(), 'ceiling' => $ceiling, 'cursor' => 0,
     'pass' => 1, 'bytes' => 0, 'reference' => $reference, 'first' => [], 'second' => []];
   }
   $first = $job !== false ? $job['first'] : [];
   $second = $job !== false ? $job['second'] : [];
   $report['first_pass_items'] = count($first); $report['second_pass_items'] = count($second);
   for ($pass = $job !== false ? $job['pass'] : 1; $pass <= 2; $pass++) {
    $field = $pass === 1 ? 'first' : 'second';
    $progress_field = $pass === 1 ? 'first_pass_items' : 'second_pass_items';
    $partial = $resumable ? ['items' => $job[$field], 'cursor' => $job['cursor']] : null;
    $items = self::capture($ceiling, $secret, $bytes, $start, $status, $reason, $report[$progress_field], $partial, $batches);
    $report['content_bytes_accounted'] = $bytes;
    if ($items === false) { $report['status'] = $status; $report['completion_reason'] = $reason; return self::finish_job($report, $lock, $resumable); }
    if ($items === null) {
     $job[$field] = $partial['items']; $job['cursor'] = $partial['cursor']; $job['pass'] = $pass; $job['bytes'] = $bytes;
     if ($pass === 2 && count($job['second']) > count($job['first'])) {
      $report['status'] = 'unstable'; $report['completion_reason'] = 'changed_during_scan'; return self::finish_job($report, $lock);
     }
     if (!self::owns($lock)) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return $report; }
     if (get_option(self::STATE, false) !== $original || get_option(self::CHECKPOINT, false) !== $saved) {
      $report['status'] = 'unstable'; $report['completion_reason'] = 'changed_during_scan'; return self::finish_job($report, $lock);
     }
     $envelope = WFP_Content_Checkpoint::seal($job, $secret, time());
     if ($envelope === false) { $report['completion_reason'] = 'checkpoint_unavailable'; return self::finish_job($report, $lock); }
     update_option(self::CHECKPOINT, $envelope, false);
     if (get_option(self::CHECKPOINT, false) !== $envelope) { $report['completion_reason'] = 'checkpoint_unavailable'; return self::finish_job($report, $lock); }
     if (!wp_next_scheduled(self::CONTINUE_HOOK) && !wp_schedule_single_event(time() + 15, self::CONTINUE_HOOK)) {
      $report['completion_reason'] = 'continuation_unavailable'; return self::finish_job($report, $lock);
     }
     $report['status'] = 'in_progress'; $report['completion_reason'] = 'continuation_pending'; return $report;
    }
    if ($pass === 1) { $first = $items; if ($resumable) { $job['first'] = $items; $job['cursor'] = 0; $job['pass'] = 2; } }
    else { $second = $items; }
   }
   $report['content_bytes_accounted'] = $bytes;
   $final_ceiling = self::ceiling();
   if ($final_ceiling === false) { $report['completion_reason'] = 'database_unavailable'; return self::finish_job($report, $lock, $resumable); }
   if ($first !== $second || $final_ceiling !== $ceiling || ($resumable && (time() - $job['started'] >= WFP_Content_Checkpoint::TTL || get_option(self::STATE, false) !== $original || get_option(self::CHECKPOINT, false) !== $saved))) { $report['status'] = 'unstable'; $report['completion_reason'] = 'changed_during_scan'; return self::finish_job($report, $lock, $resumable); }
   if (!self::owns($lock)) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return $report; }
   if (!$resumable && microtime(true) - $start >= self::MAX_SECONDS) { $report['status'] = 'partial'; $report['completion_reason'] = 'time_limit'; return self::remember($report); }
   $report['items_checked'] = count($second); $report['completion_reason'] = 'none';
   $old = get_option(self::STATE, false);
   if ($old !== $original) { $report['status']='unstable'; $report['completion_reason']='changed_during_scan'; return self::finish_job($report, $lock, $resumable); }
   if (self::valid_state($old, $key_id)) {
    $report['status'] = 'compared';
    $report['previous_items'] = count($old['items']); $report['previous_time_utc'] = $old['time'];
    $report['new_items'] = 0; $report['changed_items'] = 0; $report['left_published_scope'] = 0;
    foreach ($second as $key => $value) {
     if (!isset($old['items'][$key])) { $report['new_items']++; }
     elseif (!hash_equals($old['items'][$key], $value)) { $report['changed_items']++; }
    }
    foreach ($old['items'] as $key => $value) { if (!isset($second[$key])) { $report['left_published_scope']++; } }
   } else {
    $report['status'] = $old === false ? 'reference_created' : 'reference_reinitialized';
   }
   $returns = self::returns($report['status'] === 'compared' ? $old : false, $second, $report['time_utc']);
   foreach (['return_tracking','reappeared_items','matching_reappeared_items'] as $field) { $report[$field] = $returns[$field]; }
   $report['return_tracking_since_utc'] = $returns['state']['since'];
   $reversions = WFP_Observed_Reversions::observe($report['status'] === 'compared' ? $old : false, $second, $report['time_utc']);
   $report['reversion_tracking'] = $reversions['reversion_tracking'];
   $report['reversion_tracking_since_utc'] = $reversions['reversion_tracking_since_utc'];
   // Shared engine preserves its original file-count name; expose the content count in item units.
   $report['reverted_items'] = $reversions['reverted_files'];
   $next = ['schema' => 1, 'key_id' => $key_id, 'time' => $report['time_utc'], 'items' => $second, 'returns' => $returns['state'], 'reversions' => $reversions['state']];
   if (!self::owns($lock)) { return self::finish_job($report, $lock, false); }
   if (get_option(self::STATE, false) !== $original || ($resumable && (time() - $job['started'] >= WFP_Content_Checkpoint::TTL || get_option(self::CHECKPOINT, false) !== $saved))) {
    $report = self::clear_comparison($report); $report['status']='unstable'; $report['completion_reason']='changed_during_scan';
    return self::finish_job($report, $lock, $resumable);
   }
   update_option(self::STATE, $next, false);
   if (get_option(self::STATE, false) !== $next) {
    $report['status'] = 'unavailable'; $report['completion_reason'] = 'reference_storage_unavailable';
    $report['reversion_tracking']='not_tracked'; $report['reversion_tracking_since_utc']=null; $report['reverted_items']=null;
    $report['return_tracking'] = 'not_tracked'; $report['return_tracking_since_utc'] = null; $report['reappeared_items'] = null; $report['matching_reappeared_items'] = null;
    $report['new_items'] = null; $report['changed_items'] = null; $report['left_published_scope'] = null;
   }
   return self::finish_job($report, $lock, $resumable);
  } finally {
   $wpdb->suppress_errors($previous_errors); self::unlock($lock);
  }
 }
 private static function owns($lock) { return get_option(self::LOCK, false) === $lock && $lock['expires'] >= time(); }
 private static function clear_comparison($report) {
  foreach (['new_items','changed_items','left_published_scope','reappeared_items','matching_reappeared_items','reverted_items','return_tracking_since_utc','reversion_tracking_since_utc','previous_items','previous_time_utc'] as $field) { $report[$field]=null; }
  $report['return_tracking']='not_tracked'; $report['reversion_tracking']='not_tracked';
  $report['bulk_assessment']=self::assess($report);
  return $report;
 }
 private static function finish_job($report, $lock, $clear = true) {
  if (!self::owns($lock)) { $report['status'] = 'busy'; $report['completion_reason'] = 'scan_in_progress'; return self::clear_comparison($report); }
  $report['bulk_assessment'] = self::assess($report);
  if ($clear) { delete_option(self::CHECKPOINT); wp_clear_scheduled_hook(self::CONTINUE_HOOK); }
  return self::remember($report);
 }
 public static function progress() {
  $saved = get_option(self::CHECKPOINT, false);
  if ($saved === false) { return null; }
  $secret = hash_hmac('sha256', 'wfp-content-reference-v1', wp_salt('auth'), true);
  $reference = hash_hmac('sha256', serialize(get_option(self::STATE, false)), $secret);
  $job = WFP_Content_Checkpoint::open($saved, $secret, $reference, time());
  if ($job === false) { return ['status' => 'checkpoint_invalid']; }
  return ['status' => 'in_progress', 'started_utc' => gmdate('Y-m-d H:i:s', $job['started']),
   'first_pass_items' => count($job['first']), 'second_pass_items' => count($job['second']), 'content_bytes_accounted' => $job['bytes']];
 }
 public static function clean_report($raw) {
  if (!is_array($raw) || !in_array($raw['status'] ?? '', ['compared','reference_created','reference_reinitialized','partial','unavailable','unstable'], true)) { return false; }
  $time = WFP_State_Sanitizer::timestamp($raw['time_utc'] ?? null);
  if ($time === '' || $time > gmdate('Y-m-d H:i:s')) { return false; }
  $revision = $raw['scanner_revision'] ?? 1;
  if (!is_int($revision) || $revision < 1 || $revision > self::REVISION) { return false; }
  $safe = ['scanner_revision' => $revision, 'status' => $raw['status'], 'time_utc' => $time];
  $reason = $raw['completion_reason'] ?? 'legacy_unknown';
  if (!in_array($reason, ['none','legacy_unknown','database_unavailable','invalid_database_metadata','item_limit','single_item_byte_limit','total_byte_limit','time_limit','changed_during_scan','reference_storage_unavailable','checkpoint_invalid','checkpoint_unavailable','continuation_unavailable'], true)) { return false; }
  $safe['completion_reason'] = $reason;
  foreach (['first_pass_items','second_pass_items','content_bytes_accounted'] as $field) {
   $value = $raw[$field] ?? null; $max = $field === 'content_bytes_accounted' ? self::MAX_BYTES : self::MAX_ITEMS;
   if ($value !== null && (!is_int($value) || $value < 0 || $value > $max)) { return false; }
   $safe[$field] = $value;
  }
  foreach (['items_checked','new_items','changed_items','left_published_scope'] as $key) {
   if ($key !== 'items_checked' && $raw['status'] !== 'compared') { $safe[$key] = null; continue; }
   $value = $raw[$key] ?? null;
   if (!is_int($value) || $value < 0 || $value > self::MAX_ITEMS) { return false; }
   $safe[$key] = $value;
  }
  if ($reason !== 'legacy_unknown') {
   foreach (['first_pass_items','second_pass_items','content_bytes_accounted'] as $field) { if ($safe[$field] === null) { return false; } }
   $finished = in_array($safe['status'], ['compared','reference_created','reference_reinitialized'], true);
   if ($finished && ($reason !== 'none' || $safe['first_pass_items'] !== $safe['items_checked'] || $safe['second_pass_items'] !== $safe['items_checked'])) { return false; }
   if (!$finished && $reason === 'none') { return false; }
  }
  if ($safe['status'] === 'compared' && $safe['new_items'] + $safe['changed_items'] > $safe['items_checked']) { return false; }
  $tracking = $raw['return_tracking'] ?? 'not_tracked';
  if (!in_array($tracking, ['not_tracked','started','restarted','active','limited'], true)) { return false; }
  $safe['return_tracking'] = $tracking;
  $since = $raw['return_tracking_since_utc'] ?? null;
  if ($tracking === 'not_tracked') { if ($since !== null) { return false; } }
  elseif (WFP_State_Sanitizer::timestamp($since) === '' || $since > $time) { return false; }
  $safe['return_tracking_since_utc'] = $since;
  foreach (['reappeared_items','matching_reappeared_items'] as $key) {
   $value = $raw[$key] ?? null;
   if (in_array($tracking, ['active','limited'], true)) {
    if ($safe['status'] !== 'compared' || !is_int($value) || $value < 0 || $value > self::MAX_ITEMS) { return false; }
   } elseif ($value !== null) { return false; }
   $safe[$key] = $value;
  }
  if (in_array($tracking, ['active','limited'], true) && ($safe['reappeared_items'] > $safe['new_items'] || $safe['matching_reappeared_items'] > $safe['reappeared_items'])) { return false; }
  $previous = $raw['previous_items'] ?? null; $previous_time = $raw['previous_time_utc'] ?? null;
  if ($safe['status'] !== 'compared') { $previous = null; $previous_time = null; }
  if (($previous === null) !== ($previous_time === null)) { return false; }
  if ($previous !== null) {
   if (!is_int($previous) || $previous < 0 || $previous > self::MAX_ITEMS
    || WFP_State_Sanitizer::timestamp($previous_time) === '' || $previous_time > $time
    || $previous !== $safe['items_checked'] - $safe['new_items'] + $safe['left_published_scope']) { return false; }
  }
  $safe['previous_items'] = $previous; $safe['previous_time_utc'] = $previous_time;
  $safe['bulk_assessment'] = self::assess($safe);
  return WFP_Observed_Reversions::clean_fields($raw, $safe, 'items');
 }
 /** Derived only from complete saved comparisons; never a compromise verdict. */
 public static function assess($r) { return WFP_Bulk_Changes::assess($r, self::MAX_ITEMS); }
 public static function history() {
  $rows = get_option(self::REPORTS, []);
  if (!is_array($rows)) { return []; }
  $safe = [];
  foreach (array_slice($rows, 0, 48) as $row) {
   $clean = self::clean_report($row);
   if ($clean !== false) { $safe[] = $clean; }
  }
  $ranked = [];
  foreach ($safe as $index => $row) { $ranked[] = ['row' => $row, 'index' => $index]; }
  usort($ranked, function ($a, $b) { return strcmp($b['row']['time_utc'], $a['row']['time_utc']) ?: ($a['index'] <=> $b['index']); });
  return array_column(array_slice($ranked, 0, 24), 'row');
 }
 private static function remember($report) {
  $rows = self::history(); array_unshift($rows, self::clean_report($report));
  update_option(self::REPORTS, array_slice($rows, 0, 24), false);
  return $report;
 }
 public static function status() {
  $history = self::history();
  return [
   'progress' => self::progress(),
   'latest' => $history ? $history[0] : ['status' => 'not_run'],
   'history' => $history,
   'reversion_review' => array_values(array_filter($history, function ($r) { return ($r['reverted_items'] ?? 0) > 0; })),
   'bulk_review' => array_values(array_filter($history, function ($r) { return $r['bulk_assessment']['status'] === 'review'; })),
   'return_scope' => 'Same protected item identifier observed absent and later present in completed scans within seven days, starting from the displayed tracking start; no earlier history is reconstructed; up to 2000 absent-item fingerprints. Returning items are a subset of new-in-scope items. Matching means the same prior type/slug/title/body/excerpt fingerprint. Republication and restores can explain returns; this is not proof of reinfection. New identifiers and changes between scans are not linked. Expired fingerprints are discarded on the next complete comparison; limit gaps are disclosed for seven days. Limited tracking can miss returns.',
   'reference_trust' => 'Unverified observed starting state; never a known-clean baseline.',
   'scope' => 'Published posts, pages and products: type, slug, title, body and excerpt fingerprints. Raw text, URLs, author identities and readable page IDs are not retained. Post-meta-only builders, files and unpublished content are excluded.',
   'limits' => 'Up to 10000 items, 1 MiB per item, 32 MiB across two verification passes, up to 200 fingerprints per request and a five-second between-query budget; encrypted progress expires after 30 minutes; continuation depends on WordPress cron; a database query itself can take longer. Partial, failed or unstable scans never replace the reference.',
  ];
 }
 public static function render() {
  $status = self::status(); $r = $status['latest'];
  echo '<h2>Published content fingerprint comparisons</h2>';
  if ($status['progress'] !== null) {
   $p = $status['progress'];
   if ($p['status'] === 'in_progress') { echo '<p><strong>Scan in progress</strong>: pass counts '.esc_html((string) $p['first_pass_items']).' / '.esc_html((string) $p['second_pass_items']).'. Last complete reference is preserved; these are not changed-page counts. Waiting for WordPress cron or the comparison button to continue.</p>'; }
   else { echo '<p>Saved scan progress expired or could not be verified. The next scan will discard it; the last complete reference is preserved.</p>'; }
  }
  echo '<p>Last result: <strong>'.esc_html(str_replace('_', ' ', $r['status'])).'</strong>';
  if (isset($r['time_utc'])) { echo ' at '.esc_html($r['time_utc']).' UTC'; }
  echo '.</p>';
  if ($r['status'] === 'compared') {
   echo '<p>Items checked: '.esc_html((string) $r['items_checked']).'; new in published scope: '.esc_html((string) $r['new_items']).'; changed: '.esc_html((string) $r['changed_items']).'; left published scope: '.esc_html((string) $r['left_published_scope']).'.</p>';
  }
  if (isset($r['return_tracking'])) {
   echo '<p>Return tracking: <strong>'.esc_html(str_replace('_', ' ', $r['return_tracking'])).'</strong>';
   if ($r['return_tracking_since_utc'] !== null) { echo '; observed since '.esc_html($r['return_tracking_since_utc']).' UTC'; }
   if ($r['reappeared_items'] !== null) { echo '; previously absent items returned: '.esc_html((string) $r['reappeared_items']).'; matching earlier fingerprint: '.esc_html((string) $r['matching_reappeared_items']); }
   echo '.</p>';
  }
  if (isset($r['completion_reason'])) {
   $labels = ['none' => 'Complete scan', 'legacy_unknown' => 'Earlier scan: progress details unavailable',
    'database_unavailable' => 'Database could not be read', 'invalid_database_metadata' => 'Database returned invalid scan metadata',
    'item_limit' => 'Published-item limit reached', 'single_item_byte_limit' => 'An item exceeds the size limit',
    'total_byte_limit' => 'Total content-size budget reached', 'time_limit' => 'Processing-time budget reached',
    'changed_during_scan' => 'Content changed during verification', 'reference_storage_unavailable' => 'Reference could not be saved', 'checkpoint_invalid' => 'Saved progress expired or changed', 'checkpoint_unavailable' => 'Private scan progress could not be saved', 'continuation_unavailable' => 'Continuation could not be scheduled'];
   echo '<p>Coverage: <strong>'.esc_html($labels[$r['completion_reason']]).'</strong>.';
   if ($r['first_pass_items'] !== null) { echo ' Fingerprints completed in each pass: '.esc_html((string) $r['first_pass_items']).' / '.esc_html((string) $r['second_pass_items']).'. These are pass progress counts, not distinct changed pages.'; }
   echo '</p>';
  }
  WFP_Observed_Reversions::render($status, 'items');
  echo '<h3>Large published-content changes to review</h3>';
  echo '<p>Review threshold: at least 100 affected items, or at least 10 affecting 25% of the combined previous/current scope. New, changed and left-scope items count once each. This flags differences between complete snapshots, not attacks or exact edit times; imports, restores and maintenance can explain them. No notifications or automatic action occur.</p>';
  if (!$status['bulk_review']) { echo '<p>No threshold-crossing comparison in retained history. Older comparisons without a recorded previous scope are not assessed; this does not establish that content is safe.</p>'; }
  foreach ($status['bulk_review'] as $review) {
   $a = $review['bulk_assessment']; $minutes = (int) ceil($a['interval_seconds'] / 60);
   echo '<p><strong>Review content changes</strong> at '.esc_html($review['time_utc']).' UTC: '.esc_html((string) $a['affected_items']).' of '.esc_html((string) $a['scope_items']).' items affected ('.esc_html(number_format($a['percent_tenths'] / 10, 1)).'%). Snapshot interval: '.esc_html((string) $minutes).' minutes';
   echo $a['interval_seconds'] > 3600 ? ' (more than one hour; not evidence of a rapid burst)' : ' (at most one hour; changes may have happened anywhere in that interval)';
   echo '. Previous/current published counts: '.esc_html((string) $review['previous_items']).' / '.esc_html((string) $review['items_checked']).'.</p>';
  }
  echo '<p>Review flags remain among the last 24 retained scan reports even if a later scan has no changes. The initial observed reference is unverified.</p>';
  echo '<details><summary>How return tracking works</summary><p>'.esc_html($status['return_scope']).'</p></details>';
  echo '<p>'.esc_html($status['reference_trust']).' Comparisons are against the preceding complete snapshot, not proof of compromise or successful cleanup. Leaving scope can mean unpublishing, a type change or deletion. Changes with falsified modification dates can still be detected.</p>';
  echo '<p>'.esc_html($status['scope']).'</p><p>'.esc_html($status['limits']).' Automatic checks depend on WordPress cron. No automatic alerts, content edits or deletions occur.</p>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_content_integrity">';
  wp_nonce_field('wfp_content_integrity'); submit_button('Compare published content now', 'secondary'); echo '</form>';
  if ($status['history']) {
   echo '<details><summary>Show content comparison history</summary><table class="widefat striped"><thead><tr><th>UTC time</th><th>Result</th><th>Bulk review</th><th>New</th><th>Changed</th><th>Left scope</th><th>Returned</th><th>Matching return</th><th>Reversions</th><th>Tracking</th></tr></thead><tbody>';
   foreach ($status['history'] as $row) {
    echo '<tr><td>'.esc_html($row['time_utc']).'</td><td>'.esc_html(str_replace('_', ' ', $row['status'])).'</td><td>'.esc_html(['review' => 'Review changes', 'below_threshold' => 'Below threshold', 'not_assessed' => 'Not assessed'][$row['bulk_assessment']['status']]).'</td>';
    foreach (['new_items','changed_items','left_published_scope','reappeared_items','matching_reappeared_items','reverted_items'] as $key) { echo '<td>'.esc_html($row[$key] === null ? 'Not compared' : (string) $row[$key]).'</td>'; }
    echo '<td>'.esc_html(str_replace('_', ' ', $row['return_tracking'])).'</td></tr>';
   }
   echo '</tbody></table></details>';
  }
 }
}
