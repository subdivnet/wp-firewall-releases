<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/wordfence-local.php';
/** Offline indexed selection; no network, mutation, inventory persistence or enforcement. */
final class WFP_Scanner_Match {
 public static function freshness($attempt,$checked,$now=null) {
  $now=$now===null?time():$now;
  $valid=function($v)use($now){if(!is_string($v)||!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D',$v))return false;$stamp=strtotime($v.' UTC');return $stamp!==false&&gmdate('Y-m-d H:i:s',$stamp)===$v&&$stamp<=$now?$stamp:false;};
  $feed=$valid($attempt);$scan=$valid($checked);
  return ['feed_status'=>$feed===false?'UNKNOWN':($now-$feed>=86400?'STALE':'FRESH'),'feed_age_seconds'=>$feed===false?null:$now-$feed,'matching_status'=>$scan===false?'UNKNOWN':($now-$scan>=7200?'STALE':'RECENT'),'matching_age_seconds'=>$scan===false?null:$now-$scan];
 }
 public static function run($feed, $index, $inventory, $key, $age) {
  $out = ['status' => 'PARTIAL', 'checked_at_utc' => gmdate('Y-m-d H:i:s'), 'feed_age_seconds' => $age, 'feed_status' => $age >= 86400 ? 'STALE' : 'FRESH', 'components_checked' => 0, 'candidate_records_checked' => 0, 'unsupported_records' => 0, 'unsupported_reason_counts' => [], 'components_without_advisories' => 0, 'unknown_components' => 0, 'findings' => [], 'reason' => 'selected_records_only_full_feed_semantics_unverified'];
  if (!is_array($inventory) || count($inventory) > 2000 || !is_string($key) || strlen($key) < 32 || !is_int($age) || $age < 0) { $out['status'] = 'UNAVAILABLE'; return $out; }
  $handle = fopen($feed, 'rb'); if (!$handle) { $out['status'] = 'UNAVAILABLE'; return $out; }
  $start = microtime(true); $seenFindings = [];
  try {
   foreach ($inventory as $component) {
    if (microtime(true) - $start > 4 || count($out['findings']) >= 200) { $out['reason'] = 'matching_budget_or_finding_limit'; break; }
    if (!is_array($component) || !is_string($component['type'] ?? null) || !is_string($component['slug'] ?? null) || !is_string($component['version'] ?? null)) { $out['unknown_components']++; continue; }
    $identity = hash('sha256', $component['type'] . ':' . $component['slug']); $path = $index . '/bucket-' . substr($identity, 0, 2); $found = false;
    if (is_link($path)) { throw new RuntimeException('unsafe_index'); }
    $bucket = is_file($path) ? fopen($path, 'rb') : null;
    try {
     if ($bucket) {
      $lines = 0;
      while (($line = fgets($bucket, 1024)) !== false) {
       if (++$lines > 10000 || substr($line, -1) !== "\n") { throw new RuntimeException('bucket_limit'); }
       $entry = json_decode($line, true, 8, JSON_THROW_ON_ERROR);
       if (!is_array($entry) || count($entry) !== 3 || !is_string($entry[0]) || !is_int($entry[1]) || !is_int($entry[2]) || $entry[1] < 0 || $entry[2] < 2 || $entry[2] > 2097152) { throw new RuntimeException('bucket_shape'); }
       if ($entry[0] !== $identity) { continue; } $found = true;
       if (microtime(true) - $start > 4 || $out['candidate_records_checked'] >= 2500) { $out['reason'] = 'matching_budget_or_record_limit'; break 2; }
       if (fseek($handle, $entry[1]) !== 0) { throw new RuntimeException('record_seek'); }
       $raw = ''; while (strlen($raw) < $entry[2]) { $part = fread($handle, $entry[2] - strlen($raw)); if ($part === false || $part === '') { throw new RuntimeException('record_short'); } $raw .= $part; }
       $record = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
       if (!is_array($record) || !is_string($record['id'] ?? null)) { throw new RuntimeException('record_shape'); }
       $result = WFP_Wordfence_Local::match_json(json_encode([$record['id'] => $record], JSON_THROW_ON_ERROR), [$component]); $out['candidate_records_checked']++;
       if ($result['status'] !== 'COMPLETE') {
        $out['unsupported_records']++;
        foreach($result['rejection_reasons']??[] as $reason=>$count){$out['unsupported_reason_counts'][$reason]=($out['unsupported_reason_counts'][$reason]??0)+$count;}
        if(!empty($result['unknown_components'])){$out['unsupported_reason_counts']['inventory_version_or_identity']=($out['unsupported_reason_counts']['inventory_version_or_identity']??0)+1;}
       }
       $out['unknown_components'] += count($result['unknown_components'] ?? []);
       foreach ($result['findings'] as $finding) {
        $token = hash_hmac('sha256', $component['type'] . ':' . $component['slug'], $key);
        $dedup = $finding['id'] . ':' . $token; if (isset($seenFindings[$dedup])) { continue; } $seenFindings[$dedup] = true;
        unset($finding['component']); $finding['component_token'] = $token; $finding['feed_status'] = $out['feed_status']; $finding['feed_age_seconds'] = $age; $out['findings'][] = $finding;
        if (count($out['findings']) >= 200) { $out['reason'] = 'finding_limit'; break 3; }
       }
      }
     }
    } finally { if (is_resource($bucket)) { fclose($bucket); } }
    $out['components_checked']++; if (!$found) { $out['components_without_advisories']++; }
   }
  } catch (Throwable $e) { $out['status'] = 'UNAVAILABLE'; $out['reason'] = 'matching_input_or_index_failed'; }
  finally { fclose($handle); }
  $out['seconds'] = round(microtime(true) - $start, 4); return $out;
 }
}
