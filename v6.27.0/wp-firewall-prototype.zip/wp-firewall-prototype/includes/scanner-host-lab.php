<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/scanner-stream.php';
require_once __DIR__ . '/scanner-match.php';
/** SecurityLab-only measurement plus bounded cached-feed version checks. Never downloads automatically. */
final class WFP_Scanner_Host_Lab {
 const STATE = 'wfp_scanner_host_lab_v1';
 const LOCK = 'wfp_scanner_host_lab_lock_v1';
 const FENCE = 'wfp_wordfence_attempt_v1';
 const ALERTS = 'wfp_wordfence_selected_alerts_v1';
 const AUTO_HOOK = 'wfp_scanner_cached_version_check';
 const LAST_RUN = 'wfp_scanner_cached_check_run_v1';
 const MAX_BYTES = 268435456;
 public static function init() {
  add_action('admin_menu', [__CLASS__, 'menu']);
  add_action('admin_post_wfp_scanner_host_lab', [__CLASS__, 'action']);
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::AUTO_HOOK, [__CLASS__, 'automatic']);
  add_action('upgrader_process_complete', [__CLASS__, 'queue_check'], 10, 2);
  add_action('switch_theme', [__CLASS__, 'queue_check']);
  add_action('admin_notices', [__CLASS__, 'notice']);
  add_action('deactivate_wp-firewall-prototype/wp-firewall-prototype.php', [__CLASS__, 'deactivate']);
 }
 public static function ensure_schedule() {
  if(strtolower((string)parse_url(home_url(),PHP_URL_HOST))!=='securitylab.subdiv.net')return;
  $state=get_option(self::STATE,[]);
  if(is_array($state)&&($state['status']??'')==='measurement_complete'&&!wp_next_scheduled(self::AUTO_HOOK))wp_schedule_event(time()+60,'hourly',self::AUTO_HOOK);
 }
 public static function queue_check() {
  if(strtolower((string)parse_url(home_url(),PHP_URL_HOST))!=='securitylab.subdiv.net')return;
  $state=get_option(self::STATE,[]);$next=wp_next_scheduled(self::AUTO_HOOK);
  if(is_array($state)&&($state['status']??'')==='measurement_complete'&&(!$next||$next>time()+60))wp_schedule_single_event(time()+30,self::AUTO_HOOK);
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::AUTO_HOOK); }
 public static function automatic() {
  if(class_exists('WFP_Minimal_Hub')&&WFP_Minimal_Hub::enabled()){WFP_Minimal_Hub::tick();return;}
  $lock=null;
  try{
   $lock=self::acquire();$state=get_option(self::STATE,[]);
   if(!is_array($state)||($state['status']??'')!=='measurement_complete')throw new RuntimeException('feed_not_ready');
   $result=self::match_result($state,self::root(),'automatic');
   if(!update_option(self::ALERTS,$result,false)&&get_option(self::ALERTS)!==$result)throw new RuntimeException('alert_write');
   update_option(self::LAST_RUN,['time_utc'=>gmdate('Y-m-d H:i:s'),'status'=>'completed','coverage'=>$result['status']],false);
  }catch(Throwable $e){
   // Preserve the previous report and findings on failed execution, including lock contention.
   update_option(self::LAST_RUN,['time_utc'=>gmdate('Y-m-d H:i:s'),'status'=>'unavailable'],false);
  }finally{if($lock)self::unlock($lock);}
 }
 private static function match_result($state,$root,$trigger) {
  $path=$root.'/scanner.json';self::private_file($path);
  if(!is_string($state['feed_sha256']??null)||!hash_equals($state['feed_sha256'],hash_file('sha256',$path)))throw new RuntimeException('generation_changed');
  if(!function_exists('get_plugins'))require_once ABSPATH.'wp-admin/includes/plugin.php';
  global $wp_version;
  $inventory=[['type'=>'core','slug'=>'wordpress','version'=>(string)$wp_version]];
  foreach(get_plugins() as $file=>$metadata){$slug=dirname($file);if($slug==='.')$slug=basename($file,'.php');$inventory[]=['type'=>'plugin','slug'=>$slug,'version'=>(string)($metadata['Version']??'')];}
  foreach(wp_get_themes() as $slug=>$theme)$inventory[]=['type'=>'theme','slug'=>(string)$slug,'version'=>(string)$theme->get('Version')];
  $fresh=WFP_Scanner_Match::freshness($state['attempt_utc']??null,gmdate('Y-m-d H:i:s'));
  if($fresh['feed_age_seconds']===null)throw new RuntimeException('feed_time_invalid');
  $result=WFP_Scanner_Match::run($path,$root.'/index',$inventory,hash_hmac('sha256','wfp-vulnerability-component-v1',wp_salt('auth'),true),$fresh['feed_age_seconds']);
  if($result['status']==='UNAVAILABLE')throw new RuntimeException('matching_failed');
  $result['feed_sha256']=$state['feed_sha256'];$result['feed_attempt_utc']=$state['attempt_utc'];$result['trigger']=$trigger;
  return $result;
 }
 public static function notice() {
  if(!current_user_can('manage_options'))return;
  $alerts=get_option(self::ALERTS,[]);if(!is_array($alerts)||!$alerts)return;
  $state=get_option(self::STATE,[]);$fresh=WFP_Scanner_Match::freshness($alerts['feed_attempt_utc']??(is_array($state)?($state['attempt_utc']??null):null),$alerts['checked_at_utc']??null);
  $findings=is_array($alerts['findings']??null)?count($alerts['findings']):0;
  if(!$findings&&($alerts['status']??'')==='COMPLETE'&&$fresh['feed_status']==='FRESH'&&$fresh['matching_status']==='RECENT')return;
  echo '<div class="notice notice-warning"><p>Known-vulnerability checks need review: '.esc_html((string)$findings).' confirmed matches; coverage or freshness may be incomplete. <a href="'.esc_url(admin_url('tools.php?page=wfp-scanner-host-lab')).'">Review vulnerability checks</a>.</p></div>';
 }
 public static function menu() { add_management_page('Scanner feed host test', 'Scanner feed host test', 'manage_options', 'wfp-scanner-host-lab', [__CLASS__, 'page']); }
 private static function root() {
  if (strtolower((string) parse_url(home_url(), PHP_URL_HOST)) !== 'securitylab.subdiv.net' || !defined('WP_DEBUG_LOG') || !is_string(WP_DEBUG_LOG) || !WP_DEBUG_LOG) { throw new RuntimeException('lab_private_logging_required'); }
  $parent = realpath(dirname(WP_DEBUG_LOG)); $public = realpath(ABSPATH);
  if (!$parent || !$public || $parent === $public || strpos($parent . '/', rtrim($public, '/') . '/') === 0 || is_link(dirname(WP_DEBUG_LOG))) { throw new RuntimeException('private_root_required'); }
  $root = $parent . '/wp-firewall-feed-lab';
  if (is_link($root) || (file_exists($root) && !is_dir($root))) { throw new RuntimeException('private_root_required'); }
  if (!is_dir($root) && !mkdir($root, 0700)) { throw new RuntimeException('private_root_create'); }
  if (!chmod($root, 0700) || (fileperms($root) & 0777) !== 0700) { throw new RuntimeException('private_root_permissions'); }
  return $root;
 }
 private static function save($state) { if (!update_option(self::STATE, $state, false) && get_option(self::STATE) !== $state) { throw new RuntimeException('state_write'); } }
 private static function acquire() {
  $lock = ['token' => bin2hex(random_bytes(16)), 'expires' => time() + 120];
  if (!add_option(self::LOCK, $lock, '', false)) { throw new RuntimeException('lab_busy_review_lock'); } return $lock;
 }
 private static function unlock($lock) { global $wpdb; $wpdb->delete($wpdb->options, ['option_name' => self::LOCK, 'option_value' => maybe_serialize($lock)], ['%s','%s']); wp_cache_delete(self::LOCK, 'options'); wp_cache_delete('notoptions', 'options'); }
 private static function private_file($path) {
  if (is_link($path) || !is_file($path) || (fileperms($path) & 0777) !== 0600) { throw new RuntimeException('private_file_required'); }
 }
 public static function action() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); } check_admin_referer('wfp_scanner_host_lab');
  $lock = null; $state = get_option(self::STATE, []);
  try {
   $lock = self::acquire(); $root = self::root(); $op = $_POST['operation'] ?? '';
   if ($op === 'download') {
    if ($state) { throw new RuntimeException('single_attempt_already_recorded'); }
    $fence = get_option(self::FENCE, null);
    if ($fence !== null && (!is_array($fence) || !is_int($fence['not_before'] ?? null) || time() < $fence['not_before'])) { throw new RuntimeException('provider_backoff_or_invalid_fence'); }
    $free = disk_free_space($root); if ($free === false || $free < 805306368) { throw new RuntimeException('disk_headroom_required'); }
    $upload = $_FILES['feed_key'] ?? null;
    if (!is_array($upload) || ($upload['error'] ?? 1) !== UPLOAD_ERR_OK || ($upload['size'] ?? 0) > 4096 || !is_uploaded_file($upload['tmp_name'])) { throw new RuntimeException('private_key_upload_required'); }
    $key = file_get_contents($upload['tmp_name']);
    if (!is_string($key) || strlen($key) < 16 || !preg_match('/^[A-Za-z0-9._~+\/-]+=*$/D', $key)) { throw new RuntimeException('key_format'); }
    // Key stays request-local: neither an option, a retained file, a URL nor a response contains it.
    $state = ['schema' => 1, 'status' => 'download_started', 'attempt_utc' => gmdate('Y-m-d H:i:s'), 'download_seconds' => null, 'feed_bytes' => 0, 'feed_sha256' => '', 'download_php_start_bytes' => memory_get_usage(true), 'download_php_peak_bytes' => 0, 'free_before_bytes' => $free, 'free_after_download_bytes' => null, 'index_seconds' => 0.0, 'index_max_slice_seconds' => 0.0, 'index_php_peak_bytes' => 0, 'index_php_max_growth_bytes' => 0, 'slices' => 0, 'records' => 0, 'entries' => 0, 'offset' => 0, 'index_bytes' => 0, 'coverage' => 'measurement_only_not_semantic_acceptance'];
    self::save($state); $fence = ['attempt' => time(), 'not_before' => time() + 1800];
    if (!update_option(self::FENCE, $fence, false) && get_option(self::FENCE) !== $fence) { throw new RuntimeException('fence_write'); }
    $path = $root . '/scanner.json'; if (file_exists($path) || is_link($path)) { throw new RuntimeException('feed_exists'); }
    $fp = fopen($path, 'x'); if (!$fp) { throw new RuntimeException('stage_create'); } fclose($fp); chmod($path, 0600);
    $start = microtime(true);
    $response = wp_safe_remote_get('https://www.wordfence.com/api/intelligence/v3/vulnerabilities/scanner', ['headers' => ['Authorization' => 'Bearer ' . $key, 'Accept' => 'application/json', 'Accept-Encoding' => 'identity'], 'user-agent' => 'PEBKAC404-FeedClient', 'timeout' => 20, 'redirection' => 0, 'sslverify' => true, 'stream' => true, 'filename' => $path, 'limit_response_size' => self::MAX_BYTES]); unset($key);
    $state['download_seconds'] = round(microtime(true) - $start, 4); $state['download_php_peak_bytes'] = memory_get_peak_usage(true); $state['free_after_download_bytes'] = disk_free_space($root);
    if (is_wp_error($response)) { $state['status'] = 'download_failed'; self::save($state); throw new RuntimeException('download_failed_no_retry'); }
    $code = wp_remote_retrieve_response_code($response); $state['http_status'] = $code;
    if ($code === 429) { $retry = wp_remote_retrieve_header($response, 'retry-after'); $until = ctype_digit((string)$retry) ? time() + min((int)$retry, 315360000) : strtotime((string)$retry); if ($until) { $fence['not_before'] = max($fence['not_before'], $until); update_option(self::FENCE, $fence, false); } }
    clearstatcache(true, $path); $bytes = filesize($path); $state['feed_bytes'] = $bytes;
    $length = wp_remote_retrieve_header($response, 'content-length');
    if ($code !== 200 || stripos((string) wp_remote_retrieve_header($response, 'content-type'), 'application/json') !== 0 || !in_array(strtolower((string)wp_remote_retrieve_header($response, 'content-encoding')), ['', 'identity'], true) || !$bytes || $bytes >= self::MAX_BYTES || ($length !== '' && (!ctype_digit((string)$length) || (int)$length !== $bytes))) { $state['status'] = 'response_rejected'; self::save($state); throw new RuntimeException('response_rejected_no_retry'); }
    self::private_file($path); $state['feed_sha256'] = hash_file('sha256', $path);
    if (!mkdir($root . '/index', 0700)) { throw new RuntimeException('index_exists'); }
    $state['status'] = 'index_pending'; self::save($state);
   } elseif ($op === 'index') {
    if (($state['status'] ?? '') !== 'index_pending') { throw new RuntimeException('index_not_pending'); }
    $path = $root . '/scanner.json'; self::private_file($path); $size = filesize($path);
    if ($size !== $state['feed_bytes'] || is_link($root . '/index') || !is_dir($root . '/index')) { throw new RuntimeException('generation_changed'); }
    $start = microtime(true); $baseline = memory_get_usage(true); $reader = new WFP_Scanner_Stream($path, $state['offset']); $done = false; $count = 0;
    // Complete records only; no one-shot indexing under a 30-second PHP request budget.
    while ($count < 1500 && microtime(true) - $start < 3) {
     $row = $reader->next($state['records'] === 0);
     if ($row === null) { $done = true; break; }
     if (++$state['records'] > 60000) { throw new RuntimeException('record_count_limit'); }
     $state['entries'] += WFP_Scanner_Stream::append($root . '/index', $row); $state['offset'] = $reader->offset; $count++;
    }
    $seconds = microtime(true) - $start; $state['index_seconds'] += $seconds; $state['index_max_slice_seconds'] = max($seconds, $state['index_max_slice_seconds']); $state['index_php_peak_bytes'] = max(memory_get_peak_usage(true), $state['index_php_peak_bytes']); $state['index_php_max_growth_bytes'] = max(0, memory_get_peak_usage(true) - $baseline, $state['index_php_max_growth_bytes']); $state['slices']++;
    if ($done) {
     if (!$state['records'] || !hash_equals($state['feed_sha256'], hash_file('sha256', $path))) { throw new RuntimeException('generation_changed'); }
     $bytes = 0; foreach (new DirectoryIterator($root . '/index') as $file) { if ($file->isDot()) { continue; } if ($file->isLink() || !$file->isFile()) { throw new RuntimeException('index_shape'); } $bytes += $file->getSize(); }
     $state['index_bytes'] = $bytes; $state['free_after_index_bytes'] = disk_free_space($root); $state['status'] = 'measurement_complete'; $state['completed_utc'] = gmdate('Y-m-d H:i:s');
    }
    self::save($state);
   } elseif ($op === 'match') {
    if (($state['status'] ?? '') !== 'measurement_complete') { throw new RuntimeException('index_not_pending'); }
    $result = self::match_result($state,$root,'manual');
    if (!update_option(self::ALERTS, $result, false) && get_option(self::ALERTS) !== $result) { throw new RuntimeException('alert_write'); }
   } else { throw new RuntimeException('unknown_operation'); }
  } catch (Throwable $e) {
   // Deliberately no exception text, request data, paths or provider headers in output/logs.
   $allowed = ['provider_backoff_or_invalid_fence','lab_busy_review_lock','single_attempt_already_recorded','disk_headroom_required','private_key_upload_required','key_format','index_not_pending','unknown_operation'];
   $code = in_array($e->getMessage(), $allowed, true) ? $e->getMessage() : 'lab_operation_failed';
   if ($lock && $state) { $state['error'] = $code; if (($state['status'] ?? '') === 'index_pending') { $state['status'] = 'index_failed'; } self::save($state); }
  } finally { if ($lock) { self::unlock($lock); } }
  wp_safe_redirect(admin_url('tools.php?page=wfp-scanner-host-lab')); exit;
 }
 public static function page() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); } nocache_headers();
  echo '<div class="wrap"><h1>Scanner feed host test</h1><p>SecurityLab-only measurement. One explicit request; no retries, schedule, blocking or semantic coverage claim. API key is request-local and never retained. Feed stays outside public roots beside the private debug log.</p>';
  $state = get_option(self::STATE, []); echo '<pre id="wfp-feed-metrics">' . esc_html(json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) . '</pre>';
  try { self::root(); } catch (Throwable $e) { echo '<p>Private lab configuration unavailable. No operation permitted.</p></div>'; return; }
  if (!$state) {
   echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="wfp_scanner_host_lab"><input type="hidden" name="operation" value="download">'; wp_nonce_field('wfp_scanner_host_lab');
   echo '<label>Private API key file <input type="file" name="feed_key" required></label>'; submit_button('Download scanner feed once'); echo '</form>';
  } elseif (($state['status'] ?? '') === 'index_pending') {
   echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="wfp_scanner_host_lab"><input type="hidden" name="operation" value="index">'; wp_nonce_field('wfp_scanner_host_lab'); submit_button('Index next bounded slice'); echo '</form>';
  } elseif (($state['status'] ?? '') === 'measurement_complete') {
   echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="wfp_scanner_host_lab"><input type="hidden" name="operation" value="match">'; wp_nonce_field('wfp_scanner_host_lab'); submit_button('Check installed component versions without downloading'); echo '</form>';
  }
  $alerts = get_option(self::ALERTS, []);
  if (is_array($alerts) && $alerts) {
   $fresh=WFP_Scanner_Match::freshness($alerts['feed_attempt_utc']??($state['attempt_utc']??null),$alerts['checked_at_utc']??null);
   echo '<h2>Known-vulnerability review alerts</h2><p>Selected indexed records only. Full-feed semantic coverage is unverified; no match is not a clean result. Hourly cached-feed checks depend on WordPress cron, not real-time provider delivery. Installed version inventory is used only during a check; no identities or request data are stored.</p>';
   echo '<p>Status: ' . esc_html((string)($alerts['status'] ?? 'UNAVAILABLE')) . '; checked ' . esc_html((string)($alerts['checked_at_utc'] ?? '')) . ' UTC; trigger: '.esc_html((string)($alerts['trigger']??'legacy_manual')).'; current feed: '.esc_html($fresh['feed_status']).'; current matching age: '.esc_html($fresh['matching_status']).'.</p>';
   echo '<p>Unsupported reason counts: '.esc_html(json_encode($alerts['unsupported_reason_counts']??[])).'.</p>';
   $run=get_option(self::LAST_RUN,[]);echo '<p>Last automatic execution: '.esc_html(is_array($run)?json_encode($run):'unavailable').'. A scheduled hook alone is not execution evidence.</p>';
   echo '<p>Components checked: ' . esc_html((string)($alerts['components_checked'] ?? 0)) . '; candidate records: ' . esc_html((string)($alerts['candidate_records_checked'] ?? 0)) . '; unsupported records: ' . esc_html((string)($alerts['unsupported_records'] ?? 0)) . '; unknown component cases: ' . esc_html((string)($alerts['unknown_components'] ?? 0)) . '.</p>';
   $findings = is_array($alerts['findings'] ?? null) ? array_slice($alerts['findings'], 0, 200) : [];
   echo '<p><strong>' . esc_html((string)count($findings)) . ' known-vulnerability matches requiring owner review.</strong> No updates, blocking, email or other external notifications are sent.</p>';
   foreach ($findings as $finding) { if($fresh['feed_age_seconds']===null){echo '<p>Finding freshness unavailable; review retained evidence.</p>';continue;}$finding['feed_status']=$fresh['feed_status'];$finding['feed_age_seconds']=$fresh['feed_age_seconds'];echo WFP_Wordfence_Local::render_finding($finding); }
  }
  echo '<p>Measurement includes WordPress PHP allocator peak, not whole-host RAM/RSS. Index time sums parser/index slices, excluding waits between requests; completion validation and disk counters are reported separately by their operation. All existing observations/references remain unchanged.</p></div>';
 }
}
WFP_Scanner_Host_Lab::init();
