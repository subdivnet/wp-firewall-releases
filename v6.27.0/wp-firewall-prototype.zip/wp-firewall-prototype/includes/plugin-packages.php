<?php
if (!defined('ABSPATH')) { exit; }
/** Official WordPress.org plugin-package comparison, separate from local references. */
final class WFP_Plugin_Packages {
 const REVISION = 2;
 const HOOK = 'wfp_plugin_package_scan';
 const SUMMARY = 'wfp_plugin_package_summary_v1';
 const LOCK = 'wfp_plugin_package_lock_v1';
 const MAX_PACKAGES = 20;
 const MAX_FILES = 10000;
 const MAX_ENTRIES = 20000;
 const MAX_BYTES = 268435456;
 const MAX_FILE_BYTES = 67108864;
 const MAX_SECONDS = 12;
 public static function init() {
  add_action('init', [__CLASS__, 'ensure_schedule']);
  add_action(self::HOOK, [__CLASS__, 'scan']);
  add_action('admin_post_wfp_plugin_packages', [__CLASS__, 'manual']);
  if (function_exists('register_deactivation_hook')) { register_deactivation_hook(WFP_Observer::PLUGIN_FILE, [__CLASS__, 'deactivate']); }
 }
 public static function ensure_schedule() {
  $next = wp_next_scheduled(self::HOOK);
  if (!$next) { wp_schedule_event(time() + 60, 'hourly', self::HOOK); return; }
  $last = self::summary();
  if (isset($last['time_utc']) && ($last['scanner_revision'] ?? 1) !== self::REVISION && $next > time() + 660) {
   wp_schedule_single_event(time() + 60, self::HOOK);
  }
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::HOOK); }
 public static function manual() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_plugin_packages'); $result = self::scan(); nocache_headers();
  echo '<!doctype html><html><head><meta charset="utf-8"><title>Plugin package scan details</title></head><body><main>';
  echo '<p><a href="' . esc_url(admin_url('tools.php?page=wfp-observer')) . '">Return to Firewall Observer</a></p>';
  echo '<p>Fresh scan status: ' . esc_html($result['status']) . ' ' . esc_html($result['reason'] ?? '') . '.</p>';
  self::render();
  echo '<h2>Fresh scan file details</h2><p>Up to 20 examples from this scan only; these paths are not saved in scan history.</p>';
  foreach (($result['examples'] ?? []) as $example) { echo '<p><code>' . esc_html($example['plugin'] . '/' . $example['file']) . '</code>: ' . esc_html($example['issue']) . '</p>'; }
  echo '</main></body></html>'; exit;
 }
 private static function unlock($lock) {
  global $wpdb;
  $wpdb->delete($wpdb->options, ['option_name' => self::LOCK, 'option_value' => maybe_serialize($lock)], ['%s','%s']);
  wp_cache_delete(self::LOCK, 'options'); wp_cache_delete('notoptions', 'options');
 }
 private static function acquire() {
  $old = get_option(self::LOCK, false);
  if ($old !== false && (!is_array($old) || !is_int($old['expires'] ?? null) || !is_string($old['token'] ?? null)
   || !preg_match('/^[a-f0-9]{32}$/D', $old['token']) || $old['expires'] < time())) { self::unlock($old); }
  $lock = ['token' => bin2hex(random_bytes(16)), 'expires' => time() + 120];
  return add_option(self::LOCK, $lock, '', false) ? $lock : false;
 }
 public static function safe_relative($path) {
  if (!is_string($path) || $path === '' || strlen($path) > 512 || strpos($path, '\\') !== false
   || strpos($path, ':') !== false || preg_match('/[\x00-\x1f\x7f]/', $path)) { return false; }
  foreach (explode('/', $path) as $part) { if ($part === '' || $part === '.' || $part === '..') { return false; } }
  return true;
 }
 private static function plain($path) {
  do {
   clearstatcache(true, $path);
   if (is_link($path)) { return false; }
   $parent = dirname($path);
   if ($parent === $path || $path === '.' || $path === '') { break; }
   $path = $parent;
  } while (true);
  return true;
 }
 public static function normalize_manifest($raw) {
  if (!is_array($raw) || !$raw || count($raw) > self::MAX_FILES) { return false; }
  $safe = [];
  foreach ($raw as $path => $hashes) {
   if (!self::safe_relative($path) || !is_array($hashes)) { return false; }
   $algorithm = isset($hashes['sha256']) ? 'sha256' : 'md5';
   $values = $hashes[$algorithm] ?? null;
   if (is_string($values)) { $values = [$values]; }
   if (!is_array($values) || !$values || count($values) > 8) { return false; }
   $clean = [];
   foreach ($values as $value) {
    if (!is_string($value) || !preg_match($algorithm === 'sha256' ? '/^[a-f0-9]{64}$/iD' : '/^[a-f0-9]{32}$/iD', $value)) { return false; }
    $clean[] = strtolower($value);
   }
   $safe[$path] = ['algorithm' => $algorithm, 'hashes' => $clean];
  }
  return $safe;
 }
 private static function manifest($slug, $version, $timeout) {
  $key = 'wfp_plugin_manifest_' . hash('sha256', $slug . ':' . $version);
  $cached = get_transient($key);
  if (is_array($cached) && isset($cached['files'])) { return self::normalize_manifest($cached['files']); }
  if ($cached === 'unavailable') { return false; }
  $url = 'https://downloads.wordpress.org/plugin-checksums/' . rawurlencode($slug) . '/' . rawurlencode($version) . '.json';
  $res = wp_safe_remote_get($url, ['timeout' => $timeout, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 2097152, 'user-agent' => 'WFP-Plugin-Packages']);
  if (is_wp_error($res)) { return false; }
  $code = wp_remote_retrieve_response_code($res);
  if ($code === 404) { set_transient($key, 'unavailable', 900); return false; }
  if ($code !== 200) { return false; }
  $body = wp_remote_retrieve_body($res);
  if (!is_string($body) || strlen($body) > 2097152) { return false; }
  $raw = json_decode($body, true); $files = is_array($raw) ? ($raw['files'] ?? null) : null;
  $safe = self::normalize_manifest($files);
  if ($safe !== false) { set_transient($key, ['files' => $files], 21600); }
  return $safe;
 }
 private static function bundled_hello($version, $start, &$bytes, &$files, &$examples) {
  global $wp_version, $wp_local_package;
  $locale = $wp_local_package ?? 'en_US'; $core = $wp_version ?? '';
  $r = self::row('hello', $version, 'official_manifest_unavailable');
  $r['source'] = 'wordpress_core_bundle'; $r['source_package'] = '';
  if (!is_string($core) || !preg_match('/^[0-9][0-9A-Za-z.-]{0,39}$/D', $core)
   || !is_string($locale) || !preg_match('/^[A-Za-z0-9_@.-]{2,30}$/D', $locale)) { return $r; }
  $r['source_package'] = $core . ':' . $locale;
  $key = 'wfp_bundled_hello_' . hash('sha256', $r['source_package']);
  $hash = get_transient($key);
  if ($hash === false) {
   $remaining = self::MAX_SECONDS - (microtime(true) - $start);
   if ($remaining <= 0) { $r['reason'] = 'resource_limit'; return $r; }
   $url = 'https://api.wordpress.org/core/checksums/1.0/?' . http_build_query(['version' => $core, 'locale' => $locale], '', '&');
   $res = wp_safe_remote_get($url, ['timeout' => min(3, max(1, (int) ceil($remaining))), 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 2097152, 'user-agent' => 'WFP-Plugin-Packages']);
   if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) { return $r; }
   $body = wp_remote_retrieve_body($res);
   if (!is_string($body) || strlen($body) > 2097152) { return $r; }
   $raw = json_decode($body, true); $hash = is_array($raw) ? ($raw['checksums']['wp-content/plugins/hello.php'] ?? null) : null;
   if (!is_string($hash) || !preg_match('/^[a-f0-9]{32}$/iD', $hash)) { return $r; }
   set_transient($key, strtolower($hash), 21600);
  }
  if (!is_string($hash) || !preg_match('/^[a-f0-9]{32}$/iD', $hash)) { return $r; }
  if ($files >= self::MAX_FILES || microtime(true) - $start >= self::MAX_SECONDS) { $r['reason'] = 'resource_limit'; return $r; }
  $files++; $r['expected'] = 1; $r['checked'] = 1; $r['status'] = 'completed'; $r['reason'] = '';
  $result = self::digest(WP_PLUGIN_DIR . '/hello.php', 'md5', $bytes);
  if ($result[0] === 'ok') {
   if (hash_equals(strtolower($hash), $result[1])) { $r['matched'] = 1; } else { $r['modified'] = 1; }
  } elseif ($result[0] === 'missing') { $r['missing'] = 1; }
  else {
   $r['status'] = 'partial'; $r['reason'] = 'unverified_files';
   if ($result[0] === 'symlink') { $r['links'] = 1; } else { $r['unreadable'] = 1; }
  }
  if (($r['modified'] || $r['missing'] || $r['unreadable'] || $r['links']) && count($examples) < 20) {
   $examples[] = ['plugin' => 'hello', 'file' => 'hello.php', 'issue' => $result[0] === 'ok' ? 'core_bundle_checksum_mismatch' : $result[0]];
  }
  return $r;
 }
 private static function same($a, $b) {
  if (!is_array($a) || !is_array($b)) { return false; }
  foreach (['dev','ino','mode','size','mtime','ctime'] as $key) { if (!isset($a[$key], $b[$key]) || $a[$key] !== $b[$key]) { return false; } }
  return true;
 }
 private static function digest($path, $algorithm, &$bytes) {
  if (!self::plain($path)) { return ['symlink']; }
  $before = @lstat($path);
  if ($before === false) { return ['missing']; }
  if (($before['mode'] & 0170000) !== 0100000 || ($before['nlink'] ?? 1) > 1) { return ['unreadable']; }
  $size = $before['size'];
  if (!is_int($size) || $size < 0 || $size > self::MAX_FILE_BYTES || $bytes + $size > self::MAX_BYTES) { return ['limited']; }
  $handle = @fopen($path, 'rb');
  if (!$handle) { return ['unreadable']; }
  try {
   if (!self::same($before, fstat($handle))) { return ['unstable']; }
   $context = hash_init($algorithm); $read = hash_update_stream($context, $handle, $size + 1); $bytes += is_int($read) ? $read : 0;
   clearstatcache(true, $path);
   if ($read !== $size || !self::same($before, fstat($handle)) || !self::same($before, @lstat($path)) || !self::plain($path)) { return ['unstable']; }
   return ['ok', hash_final($context)];
  } finally { fclose($handle); }
 }
 private static function row($slug, $version, $reason = '') {
  return ['slug' => $slug, 'version' => $version, 'source' => 'wordpress_org_plugin', 'source_package' => '', 'status' => 'unavailable', 'reason' => $reason,
   'expected' => 0, 'checked' => 0, 'matched' => 0, 'modified' => 0, 'missing' => 0, 'unexpected' => 0, 'unreadable' => 0, 'links' => 0];
 }
 private static function package($slug, $version, $main, $start, &$bytes, &$files, &$entries, &$examples) {
  $r = self::row($slug, $version, 'official_manifest_unavailable');
  $remaining = self::MAX_SECONDS - (microtime(true) - $start);
  if ($remaining <= 0) { $r['reason'] = 'resource_limit'; return $r; }
  $manifest = self::manifest($slug, $version, min(3, max(1, (int) ceil($remaining))));
  if ($manifest === false || !isset($manifest[$main])) { return $r; }
  $root = WP_PLUGIN_DIR . '/' . $slug;
  if (!self::plain($root) || !is_dir($root)) { $r['reason'] = 'unsafe_or_missing_root'; return $r; }
  $r['expected'] = count($manifest); $r['status'] = 'completed'; $r['reason'] = '';
  foreach ($manifest as $relative => $expected) {
   if ($files >= self::MAX_FILES || microtime(true) - $start >= self::MAX_SECONDS) { $r['status'] = 'partial'; $r['reason'] = 'resource_limit'; return $r; }
   $files++; $r['checked']++;
   $result = self::digest($root . '/' . $relative, $expected['algorithm'], $bytes);
   if ($result[0] === 'ok') {
    if (in_array($result[1], $expected['hashes'], true)) { $r['matched']++; continue; }
    $r['modified']++; $issue = 'checksum_mismatch';
   } elseif ($result[0] === 'missing') { $r['missing']++; $issue = 'missing'; }
   else {
    $r['status'] = 'partial'; $r['reason'] = 'unverified_files';
    if ($result[0] === 'symlink') { $r['links']++; } else { $r['unreadable']++; }
    $issue = $result[0];
   }
   if (count($examples) < 20) { $examples[] = ['plugin' => $slug, 'file' => $relative, 'issue' => $issue]; }
  }
  // Extra files matter even when every official file matches. Do not follow links.
  $stack = [$root];
  try {
   while ($stack) {
    $dir = array_pop($stack);
    if (!self::plain($dir)) { $r['links']++; $r['status'] = 'partial'; $r['reason'] = 'unverified_files'; continue; }
    foreach (new DirectoryIterator($dir) as $entry) {
     if ($entry->isDot()) { continue; }
     if (++$entries > self::MAX_ENTRIES || microtime(true) - $start >= self::MAX_SECONDS) { $r['status'] = 'partial'; $r['reason'] = 'resource_limit'; return $r; }
     $path = $entry->getPathname();
     $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($path, strlen($root) + 1));
     if ($entry->isLink()) { if (!isset($manifest[$relative])) { $r['links']++; } $r['status'] = 'partial'; $r['reason'] = 'unverified_files'; continue; }
     if ($entry->isDir()) { $stack[] = $path; continue; }
     $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($path, strlen($root) + 1));
     if (!isset($manifest[$relative])) {
      $r['unexpected']++;
      if (count($examples) < 20 && self::safe_relative($relative)) { $examples[] = ['plugin' => $slug, 'file' => $relative, 'issue' => 'unexpected']; }
     }
    }
   }
  } catch (UnexpectedValueException $e) { $r['status'] = 'partial'; $r['reason'] = 'unverified_files'; }
  return $r;
 }
 public static function scan() {
  $lock = self::acquire();
  if (!$lock) { return ['status' => 'busy']; }
  try {
   if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
   $start = microtime(true); $plugins = get_plugins(); $bytes = 0; $files = 0; $entries = 0; $rows = []; $examples = [];
   $r = ['scanner_revision' => self::REVISION, 'status' => 'unavailable', 'time_utc' => gmdate('Y-m-d H:i:s'), 'registered_plugins' => is_array($plugins) ? count($plugins) : 0,
    'packages_completed' => 0, 'packages_unverified' => 0, 'inventory_limited' => false, 'packages' => []];
   if (!is_array($plugins)) { return $r; }
   $seen = [];
   foreach ($plugins as $file => $data) {
    if (count($rows) >= self::MAX_PACKAGES) { $r['inventory_limited'] = true; break; }
    $slug = is_string($file) ? dirname($file) : '';
    $version = is_array($data) ? ($data['Version'] ?? '') : '';
    if ($file === 'hello.php' && is_string($version) && preg_match('/^[0-9][a-zA-Z0-9.+_-]{0,39}$/D', $version)) {
     $row = self::bundled_hello($version, $start, $bytes, $files, $examples); $rows[] = $row;
     if ($row['status'] === 'completed') { $r['packages_completed']++; } else { $r['packages_unverified']++; }
     continue;
    }
    if (!is_string($slug) || !preg_match('/^[a-z0-9][a-z0-9-]{0,99}$/D', $slug)
     || !is_string($version) || !preg_match('/^[0-9][a-zA-Z0-9.+_-]{0,39}$/D', $version)
     || !self::safe_relative($file) || substr_count($file, '/') !== 1 || isset($seen[$slug])) {
     $rows[] = self::row('unsupported', '', 'unsupported_layout_or_metadata'); $r['packages_unverified']++; continue;
    }
    $seen[$slug] = true;
    $row = self::package($slug, $version, basename($file), $start, $bytes, $files, $entries, $examples);
    $rows[] = $row;
    if ($row['status'] === 'completed') { $r['packages_completed']++; } else { $r['packages_unverified']++; }
   }
   $r['packages'] = $rows;
   $r['status'] = $r['packages_completed'] > 0 ? (($r['packages_unverified'] || $r['inventory_limited']) ? 'partial' : 'completed') : 'unavailable';
   if (get_option(self::LOCK, false) !== $lock) { return ['status' => 'busy']; }
   update_option(self::SUMMARY, $r, false); // Counts and package labels only, never examples/contents.
   if (get_option(self::SUMMARY, false) !== $r) { $r['status'] = 'unavailable'; $r['reason'] = 'summary_storage_unavailable'; }
   $r['examples'] = $examples;
   return $r;
  } finally { self::unlock($lock); }
 }
 public static function summary() {
  $r = get_option(self::SUMMARY, false);
  if (!is_array($r) || !in_array($r['status'] ?? '', ['completed','partial','unavailable'], true)
   || WFP_State_Sanitizer::timestamp($r['time_utc'] ?? null) === '' || $r['time_utc'] > gmdate('Y-m-d H:i:s')
   || !is_int($r['registered_plugins'] ?? null) || $r['registered_plugins'] < 0
   || !is_int($r['packages_completed'] ?? null) || !is_int($r['packages_unverified'] ?? null)
   || !is_bool($r['inventory_limited'] ?? null) || !is_array($r['packages'] ?? null) || count($r['packages']) > self::MAX_PACKAGES) { return ['status' => 'not_run']; }
  $revision = $r['scanner_revision'] ?? 1;
  if (!is_int($revision) || $revision < 1 || $revision > self::REVISION) { return ['status' => 'not_run']; }
  $rows = [];
  foreach ($r['packages'] as $row) {
   if (!is_array($row) || !is_string($row['slug'] ?? null) || !preg_match('/^[a-z0-9][a-z0-9-]{0,99}$/D', $row['slug'])
    || !is_string($row['version'] ?? null) || !preg_match('/^[a-zA-Z0-9.+_-]{0,40}$/D', $row['version'])
    || !in_array($row['status'] ?? '', ['completed','partial','unavailable'], true)
    || !in_array($row['reason'] ?? '', ['', 'official_manifest_unavailable','resource_limit','unsafe_or_missing_root','unverified_files','unsupported_layout_or_metadata'], true)) { return ['status' => 'not_run']; }
   $safe = array_intersect_key($row, array_flip(['slug','version','status','reason']));
   $source = $row['source'] ?? 'wordpress_org_plugin'; $package = $row['source_package'] ?? '';
   if (!in_array($source, ['wordpress_org_plugin','wordpress_core_bundle'], true) || !is_string($package)
    || !preg_match('/^[A-Za-z0-9_.@:-]{0,80}$/D', $package)) { return ['status' => 'not_run']; }
   $safe['source'] = $source; $safe['source_package'] = $package;
   foreach (['expected','checked','matched','modified','missing','unexpected','unreadable','links'] as $key) {
    if (!is_int($row[$key] ?? null) || $row[$key] < 0 || $row[$key] > self::MAX_ENTRIES + 1) { return ['status' => 'not_run']; }
    $safe[$key] = $row[$key];
   }
   $classified = $safe['matched'] + $safe['modified'] + $safe['missing'] + $safe['unreadable'];
   if ($safe['checked'] < $classified || $safe['checked'] > $classified + $safe['links']
    || $safe['checked'] > $safe['expected']
    || ($safe['status'] === 'completed' && ($safe['checked'] !== $safe['expected'] || $safe['unreadable'] || $safe['links'] || $safe['reason'] !== ''))) { return ['status' => 'not_run']; }
   $rows[] = $safe;
  }
  $completed = count(array_filter($rows, function ($row) { return $row['status'] === 'completed'; }));
  $unverified = count($rows) - $completed;
  $status = $completed > 0 ? (($unverified || $r['inventory_limited']) ? 'partial' : 'completed') : 'unavailable';
  if ($r['packages_completed'] !== $completed || $r['packages_unverified'] !== $unverified || $r['status'] !== $status
   || $r['registered_plugins'] < count($rows) || $r['inventory_limited'] !== ($r['registered_plugins'] > self::MAX_PACKAGES)) { return ['status' => 'not_run']; }
  return ['scanner_revision' => $revision, 'status' => $r['status'], 'time_utc' => $r['time_utc'], 'registered_plugins' => $r['registered_plugins'],
   'packages_completed' => $r['packages_completed'], 'packages_unverified' => $r['packages_unverified'], 'inventory_limited' => $r['inventory_limited'], 'packages' => $rows];
 }
 public static function render() {
  $r = self::summary();
  echo '<h2>Compare plugins with official packages</h2><p>Last result: <strong>' . esc_html($r['status']) . '</strong>';
  if (isset($r['time_utc'])) { echo ' at ' . esc_html($r['time_utc']) . ' UTC'; }
  echo '.</p><p>Uses WordPress.org checksums for the declared installed version, including inactive folder-based plugins. Missing official metadata, private plugins, renamed folders, other single-file plugins and unsupported layouts remain unverified. Bundled hello.php is compared only with the installed WordPress core package and locale, not a guessed standalone plugin version; a separately updated file may legitimately differ. Themes, must-use plugins and unregistered directories are excluded here; local file comparisons cover different scopes. Updates and customizations may explain differences; use a fresh manual scan for file details. A match is not proof of absence of malware, vulnerabilities or compromised dependencies.</p>';
  if (isset($r['packages'])) {
   echo '<p>Completed package scans: ' . esc_html((string) $r['packages_completed']) . '; unverified: ' . esc_html((string) $r['packages_unverified']) . ($r['inventory_limited'] ? '; inventory limit reached' : '') . '.</p>';
   echo '<table class="widefat striped"><thead><tr><th>Plugin/version</th><th>Result</th><th>Matched</th><th>Modified</th><th>Missing</th><th>Unexpected</th><th>Coverage</th></tr></thead><tbody>';
   foreach ($r['packages'] as $row) {
    echo '<tr><td>' . esc_html($row['slug'] . ' ' . $row['version']) . '</td><td>' . esc_html($row['status']) . '</td>';
    foreach (['matched','modified','missing','unexpected'] as $key) { echo '<td>' . esc_html((string) $row[$key]) . '</td>'; }
    echo '<td>' . esc_html(($row['source'] === 'wordpress_core_bundle' ? 'WordPress bundle ' . $row['source_package'] . ' ' : '') . str_replace('_', ' ', $row['reason'])) . '</td></tr>';
   }
   echo '</tbody></table>';
  }
  echo '<p>Limits: 20 registered entries, 10000 expected files, 20000 directory entries, 64 MiB/file, 256 MiB total and 12 seconds between operations. HTTPS only; no insecure retries or redirects. Official metadata is cached for six hours; unavailable versions for fifteen minutes. No files are changed, blocked or deleted. Automatic runs depend on WordPress cron.</p>';
  echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="wfp_plugin_packages">';
  wp_nonce_field('wfp_plugin_packages'); submit_button('Check official plugin packages now', 'secondary'); echo '</form>';
 }
}
