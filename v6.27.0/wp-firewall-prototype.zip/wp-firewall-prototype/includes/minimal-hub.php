<?php
/** Explicitly enrolled local hub pull. Provider credentials never reach this site. */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__.'/hub-capacity.php';
final class WFP_Minimal_Hub {
 const STATE='wfp_minimal_hub_v1';
 const ENABLED='wfp_minimal_hub_enabled_v1';
 const ENROLLMENT='wfp_hub_site_enrollment_v1';
 const HOOK='wfp_minimal_hub_pull';
 const STEP_HOOK='wfp_minimal_hub_index';
 const MAX_BYTES=134217728;
 public static function legacy_lab(){return strtolower((string)parse_url(home_url(),PHP_URL_HOST))==='securitylab.subdiv.net';}
 public static function enrolled(){
  if(self::legacy_lab())return true;
  $entry=get_option(self::ENROLLMENT,null);
  if(!is_array($entry)||($entry['schema']??null)!==1||!is_string($entry['site_key']??null))return false;
  try{return hash_equals(WFP_Hub_Capacity::identity(home_url(),wp_salt('auth')),$entry['site_key']);}catch(Throwable $error){return false;}
 }
 public static function enabled(){return self::enrolled()&&in_array(get_option(self::ENABLED,false),[true,1,'1'],true);}
 public static function init() {
  add_action('admin_menu',[__CLASS__,'menu']);
  add_action('admin_post_wfp_minimal_hub',[__CLASS__,'action']);
  add_action('rest_api_init',[__CLASS__,'routes']);
  add_action('init',[__CLASS__,'schedule']);
  add_action(self::HOOK,[__CLASS__,'tick']);
  add_action(self::STEP_HOOK,[__CLASS__,'tick']);
 }
 public static function schedule() {
  if(!self::enabled())return;
  if(!wp_next_scheduled(self::HOOK))wp_schedule_event(time()+60,'hourly',self::HOOK);
  $state=get_option(self::STATE,[]);if(is_array($state)&&!empty($state['pending'])&&!wp_next_scheduled(self::STEP_HOOK))wp_schedule_single_event(time()+10,self::STEP_HOOK);
 }
 public static function routes() {
  register_rest_route('wfp/v1','/hub',['methods'=>'GET','permission_callback'=>function(){return current_user_can('manage_options');},'callback'=>function(){return rest_ensure_response(self::status());}]);
  register_rest_route('wfp/v1','/hub/step',['methods'=>'POST','permission_callback'=>function(){return current_user_can('manage_options');},'callback'=>function(){if(!self::enabled())return new WP_Error('wfp_hub_not_enrolled','Connect this site from Settings first.',['status'=>403]);self::tick();return rest_ensure_response(self::status());}]);
 }
 private static function enable(){
  if(!self::legacy_lab()){
   if(($_POST['wfp_hub_site_consent']??null)!=='yes'||!WFP_Private_Updates::hub_configured())throw new RuntimeException('hub_site_not_enrolled');
   // Preserve existing enrollment locations; only new enrollments use the independent layout.
   $prior=get_option(self::ENROLLMENT,null);
   $layout=self::enrolled()?($prior['cache_layout']??1):2;
   self::private_parent($layout===2);
   $entry=['schema'=>1,'site_key'=>WFP_Hub_Capacity::identity(home_url(),wp_salt('auth'))];
   if($layout===2)$entry['cache_layout']=2;
   if(!update_option(self::ENROLLMENT,$entry,false)&&get_option(self::ENROLLMENT)!==$entry)throw new RuntimeException('hub_state_write');
  }
  if(!update_option(self::ENABLED,true,false)&&!in_array(get_option(self::ENABLED,false),[true,1,'1'],true))throw new RuntimeException('hub_state_write');self::schedule();
 }
 private static function private_parent($newEnrollment=false){
  $entry=get_option(self::ENROLLMENT,null);
  if(!self::legacy_lab()&&($newEnrollment||(is_array($entry)&&($entry['cache_layout']??null)===2)))return WFP_Hub_Capacity::private_parent(ABSPATH,$_SERVER['DOCUMENT_ROOT']??'');
  // Legacy caches keep their established location; logging flags are never changed.
  if(!defined('WP_DEBUG_LOG')||!is_string(WP_DEBUG_LOG)||WP_DEBUG_LOG==='')throw new RuntimeException('hub_private_root_required');
  $parent=realpath(dirname(WP_DEBUG_LOG));$public=realpath(ABSPATH);
  if(!$parent||!$public||is_link(dirname(WP_DEBUG_LOG))||$parent===$public||strpos($parent.'/',rtrim($public,'/').'/')===0)throw new RuntimeException('hub_private_root_required');
  return $parent;
 }
 private static function root($create=true){
  if(!self::enrolled())throw new RuntimeException('hub_site_not_enrolled');
  $parent=self::private_parent();
  $entry=get_option(self::ENROLLMENT,null);$modern=!self::legacy_lab()&&is_array($entry)&&($entry['cache_layout']??null)===2;
  $root=$modern?$parent.'/.wp-firewall-feed-'.WFP_Hub_Capacity::identity(home_url(),wp_salt('auth')):$parent.'/wp-firewall-hub'.(self::legacy_lab()?'':'-'.WFP_Hub_Capacity::identity(home_url(),wp_salt('auth')));
  if(is_link($root)||(file_exists($root)&&!is_dir($root)))throw new RuntimeException('hub_private_root_required');
  if(!$create){if(!is_dir($root))throw new RuntimeException('hub_storage_unavailable');return $root;}
  if($modern&&is_dir($root)){
   $stat=lstat($root);
   if(!$stat||($stat['mode']&0777)!==0700||(function_exists('posix_geteuid')&&$stat['uid']!==posix_geteuid()))throw new RuntimeException('hub_storage_unavailable');
   return $root;
  }
  if(!is_dir($root)&&!mkdir($root,0700))throw new RuntimeException('hub_storage_unavailable');
  if(!chmod($root,0700))throw new RuntimeException('hub_storage_unavailable');return $root;
 }
 private static function retired(&$state,$root){
  $protected=[];foreach(['active','previous','pending'] as $key)if(isset($state[$key]['sha256']))$protected[]=$state[$key]['sha256'];
  if(!isset($state['retired']))return;
  if(!is_array($state['retired'])||count($state['retired'])>1)throw new RuntimeException('hub_retirement_invalid');
  foreach($state['retired'] as $hash)WFP_Hub_Capacity::remove_retired($root,$hash,$protected);
  unset($state['retired']);self::save($state);
 }
 private static function cost(&$state,$budget,$start){
  $state['resources']=['cache_limit_bytes'=>$budget===null?null:WFP_Hub_Capacity::MAX_BYTES,'cache_limit_files'=>$budget===null?null:WFP_Hub_Capacity::MAX_FILES,'cache_logical_bytes'=>$budget['bytes']??null,'cache_files'=>$budget['files']??null,'php_allocator_peak_bytes'=>memory_get_peak_usage(true),'last_slice_elapsed_seconds'=>round(microtime(true)-$start,6),'captured_at_utc'=>gmdate('Y-m-d H:i:s'),'account_quota_verified'=>false];
 }
 private static function save($state) { if(!update_option(self::STATE,$state,false)&&get_option(self::STATE)!==$state)throw new RuntimeException('hub_state_write'); }
 public static function validate($manifest) {
  if(!is_array($manifest)||($manifest['schema']??null)!==1||!is_int($manifest['bytes']??null)||$manifest['bytes']<1||$manifest['bytes']>=self::MAX_BYTES||!is_string($manifest['sha256']??null)||!preg_match('/^[a-f0-9]{64}$/D',$manifest['sha256'])||!is_int($manifest['asset_id']??null)||$manifest['asset_id']<1||!is_int($manifest['records']??null)||$manifest['records']<1||$manifest['records']>60000||!is_string($manifest['acquired_at_utc']??null)||strtotime($manifest['acquired_at_utc'])===false||strtotime($manifest['acquired_at_utc'])>time()+300)throw new RuntimeException('hub_manifest_invalid');
  return ['sha256'=>$manifest['sha256'],'bytes'=>$manifest['bytes'],'asset_id'=>$manifest['asset_id'],'records'=>$manifest['records'],'acquired_at_utc'=>gmdate('Y-m-d H:i:s',strtotime($manifest['acquired_at_utc']))];
 }
 public static function tick() {
  if(!self::enabled())return;
  $lock=null;$state=get_option(self::STATE,[]);if(!is_array($state))$state=[];
  try {
   $operationStart=microtime(true);$root=self::root();$lock=fopen($root.'/pull.lock','c');
   if(!$lock||!chmod($root.'/pull.lock',0600)||!flock($lock,LOCK_EX|LOCK_NB))throw new RuntimeException('hub_busy');
   wp_cache_delete(self::STATE,'options');$state=get_option(self::STATE,[]);if(!is_array($state))$state=[];
   // Grandfather only the pre-existing SecurityLab cache. Measure it before any capacity migration.
   // This preserves its old acquisition/retention behavior; every newly enrolled rollout site is capped.
   $legacy=self::legacy_lab()&&(($state['cache_policy']??null)==='legacy_measurement'||(!isset($state['cache_policy'])&&isset($state['active']['sha256'])));
   $state['cache_policy']=$legacy?'legacy_measurement':'bounded';
   if(!$legacy)self::retired($state,$root);$budget=$legacy?null:WFP_Hub_Capacity::scan($root);
   if(empty($state['pending'])) {
    $manifest=self::validate(WFP_Private_Updates::hub_manifest());
    if(($state['active']['sha256']??'')===$manifest['sha256']) {
     self::match_active($state,$root);$state['last_execution_utc']=gmdate('Y-m-d H:i:s');$state['status']='ready';unset($state['error']);self::cost($state,$budget,$operationStart);self::save($state);return;
    }
    $free=disk_free_space($root);if($free===false||$free<2*$manifest['bytes']+33554432)throw new RuntimeException('hub_storage_headroom_required');
    if(!$legacy)WFP_Hub_Capacity::reserve($budget,$manifest['bytes'],[$root.'/'.$manifest['sha256'].'/scanner.json']);
    $generation=$root.'/'.$manifest['sha256'];
    if(file_exists($generation)||is_link($generation))throw new RuntimeException('hub_generation_needs_review');
    if(!mkdir($generation,0700))throw new RuntimeException('hub_storage_unavailable');
    $part=$generation.'/scanner.part';$file=fopen($part,'x');if(!$file)throw new RuntimeException('hub_storage_unavailable');fclose($file);chmod($part,0600);
    WFP_Private_Updates::hub_download($manifest['asset_id'],$part,self::MAX_BYTES);
    clearstatcache(true,$part);
    if(filesize($part)!==$manifest['bytes']||!hash_equals($manifest['sha256'],hash_file('sha256',$part)))throw new RuntimeException('hub_feed_checksum_invalid');
    if(!rename($part,$generation.'/scanner.json')||!mkdir($generation.'/index',0700))throw new RuntimeException('hub_storage_unavailable');
    $state['pending']=$manifest+['offset'=>0,'indexed_records'=>0,'entries'=>0,'slices'=>0,'index_elapsed_seconds'=>0.0,'max_index_slice_seconds'=>0.0];$state['status']='indexing';unset($state['error']);self::save($state);
   }
   $pending=$state['pending'];$generation=$root.'/'.$pending['sha256'];$feed=$generation.'/scanner.json';
   $reader=new WFP_Scanner_Stream($feed,$pending['offset']);$start=microtime(true);$count=0;$done=false;
   while($count<1500&&microtime(true)-$start<3) {
    $row=$reader->next($pending['indexed_records']===0);
    if($row===null){$done=true;break;}
    if(++$pending['indexed_records']>60000)throw new RuntimeException('hub_record_limit');
    if(!$legacy)WFP_Hub_Capacity::reserve_row($budget,$generation.'/index',$row);
    $pending['entries']+=WFP_Scanner_Stream::append($generation.'/index',$row);$pending['offset']=$reader->offset;$count++;
   }
   $elapsed=microtime(true)-$start;$pending['index_elapsed_seconds']=($pending['index_elapsed_seconds']??0)+$elapsed;$pending['max_index_slice_seconds']=max($pending['max_index_slice_seconds']??0,$elapsed);
   $pending['slices']++;$state['pending']=$pending;$state['last_execution_utc']=gmdate('Y-m-d H:i:s');
   if($done) {
    if($pending['indexed_records']!==$pending['records']||!hash_equals($pending['sha256'],hash_file('sha256',$feed)))throw new RuntimeException('hub_feed_checksum_invalid');
    if(!$legacy&&isset($state['previous']['sha256']))$state['retired']=[$state['previous']['sha256']];
    if(isset($state['active']))$state['previous']=$state['active'];
    $state['active']=$pending;unset($state['pending']);self::match_active($state,$root);$state['status']='ready';$state['activated_at_utc']=gmdate('Y-m-d H:i:s');
   } else {
    $state['status']='indexing';wp_schedule_single_event(time()+10,self::STEP_HOOK);
   }
   unset($state['error']);self::cost($state,$legacy?null:WFP_Hub_Capacity::scan($root),$operationStart);self::save($state);
  } catch(Throwable $error) {
   if($error->getMessage()==='hub_busy')return;
   $allowed=['hub_cache_capacity','hub_cache_unknown_object','hub_retirement_invalid','hub_site_not_enrolled','hub_busy','hub_metadata_unavailable','hub_metadata_invalid','hub_manifest_invalid','hub_credentials_unavailable','hub_download_unavailable','hub_download_host_invalid','hub_storage_headroom_required','hub_generation_needs_review','hub_feed_checksum_invalid','hub_record_limit'];
   $state['error']=in_array($error->getMessage(),$allowed,true)?$error->getMessage():'hub_operation_unavailable';$state['status']='unavailable';$state['last_execution_utc']=gmdate('Y-m-d H:i:s');self::save($state);
   // Existing findings stay intact. No retry loop, repair or new recovery mechanism.
  } finally { if(is_resource($lock)){flock($lock,LOCK_UN);fclose($lock);} }
 }
 private static function match_active($state,$root) {
  $active=$state['active'];$directory=$root.'/'.$active['sha256'];$feed=$directory.'/scanner.json';
  if(!hash_equals($active['sha256'],hash_file('sha256',$feed)))throw new RuntimeException('hub_feed_checksum_invalid');
  if(!function_exists('get_plugins'))require_once ABSPATH.'wp-admin/includes/plugin.php';
  global $wp_version;$inventory=[['type'=>'core','slug'=>'wordpress','version'=>(string)$wp_version]];
  foreach(get_plugins() as $file=>$metadata){$slug=dirname($file);if($slug==='.')$slug=basename($file,'.php');$inventory[]=['type'=>'plugin','slug'=>$slug,'version'=>(string)($metadata['Version']??'')];}
  foreach(wp_get_themes() as $slug=>$theme)$inventory[]=['type'=>'theme','slug'=>(string)$slug,'version'=>(string)$theme->get('Version')];
  $fresh=WFP_Scanner_Match::freshness($active['acquired_at_utc'],gmdate('Y-m-d H:i:s'));
  if($fresh['feed_age_seconds']===null)throw new RuntimeException('hub_manifest_invalid');
  $result=WFP_Scanner_Match::run($feed,$directory.'/index',$inventory,hash_hmac('sha256','wfp-vulnerability-component-v1',wp_salt('auth'),true),$fresh['feed_age_seconds']);
  if($result['status']==='UNAVAILABLE')throw new RuntimeException('hub_matching_unavailable');
  $result['feed_sha256']=$active['sha256'];$result['feed_attempt_utc']=$active['acquired_at_utc'];$result['trigger']='hub_pull';
  if(!update_option(WFP_Scanner_Host_Lab::ALERTS,$result,false)&&get_option(WFP_Scanner_Host_Lab::ALERTS)!==$result)throw new RuntimeException('hub_alert_write');
  update_option(WFP_Scanner_Host_Lab::LAST_RUN,['time_utc'=>gmdate('Y-m-d H:i:s'),'status'=>'completed','coverage'=>$result['status'],'source'=>'private_hub'],false);
 }
 public static function status() {
  $state=get_option(self::STATE,[]);$state=is_array($state)?$state:[];$alerts=get_option(WFP_Scanner_Host_Lab::ALERTS,[]);
  if(self::legacy_lab()&&isset($state['active']['sha256'])&&in_array($state['cache_policy']??null,[null,'legacy_measurement'],true)){
   $state['cache_policy']='legacy_measurement';
   try{$state['cache_audit']=WFP_Hub_Capacity::audit(self::root(false));}catch(Throwable $error){$state['cache_audit']=['logical_bytes'=>0,'files'=>0,'complete'=>false,'captured_at_utc'=>gmdate('Y-m-d H:i:s')];}
  }
  $fresh=WFP_Scanner_Match::freshness($alerts['feed_attempt_utc']??null,$alerts['checked_at_utc']??null);
  return ['distribution_repository'=>'subdivnet/wp-firewall-feed','read_credential_configured'=>WFP_Private_Updates::hub_configured(),'enabled'=>self::enabled(),'state'=>$state,'findings_retained'=>true,'matching'=>is_array($alerts)?['status'=>$alerts['status']??'UNAVAILABLE','checked_at_utc'=>$alerts['checked_at_utc']??null,'feed_attempt_utc'=>$alerts['feed_attempt_utc']??null,'feed_status'=>$fresh['feed_status'],'matching_status'=>$fresh['matching_status'],'components_checked'=>$alerts['components_checked']??null,'candidate_records_checked'=>$alerts['candidate_records_checked']??null,'matches'=>count($alerts['findings']??[]),'trigger'=>$alerts['trigger']??null]:null];
 }
 public static function menu(){add_management_page('Firewall Feed Hub','Firewall Feed Hub','manage_options','wfp-minimal-hub',[__CLASS__,'page']);}
 public static function action(){if(!current_user_can('manage_options'))wp_die('Insufficient permissions');check_admin_referer('wfp_minimal_hub');try{self::enable();}catch(Throwable $error){wp_die('The feed connection was not enabled. Confirm the separate feed credential and private logging setup with your site maintainer. No protection setting was changed.');}wp_safe_redirect(admin_url('admin.php?page=wp-firewall&tab=settings'));exit;}
 public static function page(){
  if(!current_user_can('manage_options'))wp_die('Insufficient permissions');nocache_headers();
  $report=self::status();$state=$report['state'];$matching=$report['matching']??[];$phase=$state['status']??'not_started';
  $connection=!$report['read_credential_configured']?'Setup needed':(!$report['enabled']?'Not enabled':($phase==='ready'?'Connected':($phase==='indexing'?'Preparing feed':'Needs attention')));
  $feed=$matching['feed_status']??'UNAVAILABLE';$coverage=$matching['status']??'UNAVAILABLE';$pending=$state['pending']??null;$prepared=$pending??($state['active']??[]);
  echo '<style>.wfp-hub-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;max-width:1100px}.wfp-hub-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:22px}.wfp-hub-card h2{font-size:14px;color:#50575e;margin:0 0 12px}.wfp-hub-value{font-size:28px;font-weight:600;line-height:1.3;margin:0 0 10px}.wfp-hub-warning{max-width:1060px;padding:18px;border-left:4px solid #b86600;background:#fff4da;margin:22px 0}.wfp-hub-table{max-width:1100px;margin-top:22px}.wfp-hub-table th{width:220px;text-align:left;padding:14px}.wfp-hub-table td{padding:14px}</style>';
  echo '<div class="wrap"><h1>SecurityLab owner view</h1><p>Actual results from this site. Updates automatically every 30 seconds. All displayed times are UTC.</p>';
  if($feed!=='FRESH'||$coverage!=='COMPLETE'||$phase!=='ready')echo '<div class="wfp-hub-warning"><strong>Review coverage and freshness.</strong> A zero-match result covers selected records only and does not establish that the site is free of vulnerabilities. Earlier results stay visible while a new feed is being prepared.</div>';
  echo '<div class="wfp-hub-grid"><section class="wfp-hub-card"><h2>Private hub connection</h2><p class="wfp-hub-value">'.esc_html($connection).'</p><p>Distribution: subdivnet/wp-firewall-feed. Displayed results may use the retained earlier cache until the new connection is configured.</p></section>';
  echo '<section class="wfp-hub-card"><h2>Known-vulnerability matches</h2><p class="wfp-hub-value">'.esc_html(isset($matching['matches'])?(string)$matching['matches']:'Unavailable').'</p><p>Coverage: '.esc_html($coverage).'. '.esc_html((string)($matching['components_checked']??0)).' components checked.</p></section>';
  echo '<section class="wfp-hub-card"><h2>Feed freshness for displayed results</h2><p class="wfp-hub-value">'.esc_html($feed).'</p><p>Latest local check: '.esc_html($matching['matching_status']??'UNAVAILABLE').'.</p></section>';
  echo '<section class="wfp-hub-card"><h2>Feed preparation</h2><p class="wfp-hub-value">'.esc_html((string)($prepared['indexed_records']??0)).' / '.esc_html((string)($prepared['records']??0)).'</p><p>Records prepared locally'.($pending?' for the incoming update.':'.').'</p></section></div>';
  echo '<table class="widefat striped wfp-hub-table"><tbody><tr><th>Provider feed acquired</th><td>'.esc_html($matching['feed_attempt_utc']??'Not available').'</td></tr><tr><th>Local vulnerability check</th><td>'.esc_html($matching['checked_at_utc']??'Not completed').'</td></tr><tr><th>Latest hub execution</th><td>'.esc_html($state['last_execution_utc']??'Not completed').'</td></tr><tr><th>Candidate records checked</th><td>'.esc_html((string)($matching['candidate_records_checked']??0)).'</td></tr><tr><th>Privacy and response</th><td>Matching stays on SecurityLab. The Wordfence API key stays on the owner machine. No blocking, email or automatic remediation.</td></tr></tbody></table>';
  echo '<h2>Feed repository access</h2><p>Use a separate expiring fine-grained token: subdivnet/wp-firewall-feed only, Contents read-only. The source updater credential remains separate. No credential is displayed here.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_hub_save_read_token">';
  wp_nonce_field('wfp_hub_save_read_token');
  echo '<label for="wfp_hub_read_token">Feed repository read-only token</label><p><input id="wfp_hub_read_token" name="wfp_hub_read_token" type="password" value="" autocomplete="new-password" size="55"></p>';
  submit_button('Save feed read credential','secondary');echo '</form>';
  echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_minimal_hub">';wp_nonce_field('wfp_minimal_hub');submit_button(self::enabled()?'Refresh from private hub':'Enable SecurityLab hub pull');echo '</form>';
  echo '<details><summary>Connection details</summary><pre>'.esc_html(json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)).'</pre></details><h2>Findings requiring review</h2>';
  $alerts=get_option(WFP_Scanner_Host_Lab::ALERTS,[]);foreach(($alerts['findings']??[]) as $finding)echo WFP_Wordfence_Local::render_finding($finding);echo '</div>';
  echo '<script>window.setTimeout(function(){window.location.reload();},30000);</script>';
 }
}
WFP_Minimal_Hub::init();
