<?php
/** Read-only fact projection. No WordPress bootstrap, settings reads or writes. */
final class WFP_Hardening_Facts {

 /** Read current non-secret booleans only. Never persist configuration or enumerate users. */
 public static function capture(){
  $facts=[];
  $display=ini_get('display_errors');
  if(is_string($display)){
   $mode=strtolower(trim($display));
   if(in_array($mode,['','0','off','false','none'],true))$facts['public_error_display']=false;
   elseif(in_array($mode,['1','on','true','stdout'],true))$facts['public_error_display']=true;
   // stderr and unrecognized modes are not proof of browser display.
  }
  if(function_exists('get_option')){
   foreach(['home'=>'home_https','siteurl'=>'site_https'] as $option=>$key){
    $value=get_option($option,null);
    if(is_string($value)){$scheme=parse_url($value,PHP_URL_SCHEME);if($scheme==='https')$facts[$key]=true;elseif($scheme==='http')$facts[$key]=false;}
   }
   $name=get_option('default_role',null);
   if(is_string($name)&&function_exists('get_role')){
    $role=get_role($name);
    if(is_object($role)&&isset($role->capabilities)&&is_array($role->capabilities)){
     $sensitive=false;$known=true;
     foreach(['manage_options','edit_users','promote_users','create_users','delete_users','install_plugins','activate_plugins','edit_plugins','edit_themes','switch_themes','update_core','edit_others_posts','unfiltered_html'] as $cap){
      $value=$role->capabilities[$cap]??false;
      if($value===true||$value===1){$sensitive=true;break;}
      if($value!==false&&$value!==0)$known=false;
     }
     if($sensitive||$known)$facts['default_role_sensitive']=$sensitive;
    }
   }
  }
  if(function_exists('force_ssl_admin')){$value=force_ssl_admin();if(is_bool($value))$facts['admin_https_required']=$value;}
  return self::evaluate($facts);
 }
 public static function evaluate(array $facts) {
  $allowed=['public_error_display','home_https','site_https','admin_https_required','default_role_sensitive'];
  foreach($facts as $key=>$value){if(!in_array($key,$allowed,true)||($value!==null&&!is_bool($value)))throw new InvalidArgumentException('invalid_sanitized_fact');}
  $display=$facts['public_error_display']??null;$home=$facts['home_https']??null;$site=$facts['site_https']??null;$admin=$facts['admin_https_required']??null;$role=$facts['default_role_sensitive']??null;
  $https=($home===false||$site===false)?false:(($home===true&&$site===true)?true:null);
  return ['mode'=>'observation_only','changes_made'=>false,'checks'=>[
   self::row('error_display',$display===null?'unknown':($display?'review':'pass'),'Error messages shown to visitors',$display===true?'Error messages may be shown to visitors.':($display===false?'Error messages are not shown in this request.':'Not checked yet.'),'Ask your maintainer to turn visitor display off while keeping private error logging enabled.','This request does not prove every page or server error path has the same policy.'),
   self::row('site_addresses',$https===null?'unknown':($https?'pass':'review'),'Configured site addresses',$https===true?'Both site addresses are configured to use HTTPS.':($https===false?'A site address is configured without HTTPS.':'Not checked yet.'),'Review the site addresses with your maintainer before making changes.','Address schemes do not verify certificates, redirects or login transport.'),
   self::row('admin_https',$admin===null?'unknown':($admin?'pass':'neutral'),'Encrypted administration',$admin===true?'WordPress requires HTTPS for administration.':($admin===false?'WordPress does not require it here; your host may enforce it.':'Not checked yet.'),'Review host and proxy enforcement before changing this setting.','A disabled WordPress policy is not proof that credentials are exposed.'),
   self::row('default_role_access',$role===null?'unknown':($role?'review':'pass'),'Default account access',$role===true?'New accounts could receive more access than expected.':($role===false?'The checked default-role permissions are limited.':'Not checked yet.'),'Review registration and default-role permissions with your maintainer.','This checks a bounded permission set, not every custom capability or account.')
  ]];
 }
 private static function row($id,$status,$title,$sentence,$action,$limit){return ['id'=>$id,'status'=>$status,'badge'=>$status==='review'?'Worth a look':($status==='pass'?'No problem found':($status==='neutral'?'For reference':'Not checked yet')),'color'=>$status==='review'?'yellow':($status==='pass'?'green':'grey'),'title'=>$title,'sentence'=>$sentence,'action'=>$status==='review'?$action:null,'details'=>$limit,'scope'=>'sanitized current facts only'];}
}
