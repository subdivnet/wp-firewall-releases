<?php
/** Observation-only prevention policy prototypes. No WordPress hooks or writes. */
final class WFP_Prevention_Preview {
 public static function login(array $buckets, $now, $threshold=5) {
  if (!is_int($now) || $now<0 || !is_int($threshold) || $threshold<1 || $threshold>100) throw new InvalidArgumentException('invalid_policy');
  $count=0;$complete=true;$current=intdiv($now,300)*300;
  for($t=$current-600;$t<=$current;$t+=300){
   if(!array_key_exists($t,$buckets)){$complete=false;continue;}
   $n=$buckets[$t];if(!is_int($n)||$n<0||$n>1000000)throw new InvalidArgumentException('invalid_aggregate');$count+=$n;
  }
  return ['mode'=>'observation_only','action'=>'allow','window'=>'current and previous two five-minute buckets','failed_attempts'=>$count,'coverage'=>$complete?'COMPLETE_BUCKETS':'PARTIAL_BUCKETS','pressure'=>$count>=$threshold?'REVIEW':($complete?'BELOW_THRESHOLD':'UNKNOWN'),'threshold'=>$threshold,'would_block'=>null,'scope'=>'site aggregate, not people or per-actor rate limiting'];
 }
 public static function audit(array $facts) {
  $registration=$facts['registration_enabled']??null;$role=$facts['default_role']??null;
  if($registration!==null&&!is_bool($registration))throw new InvalidArgumentException('invalid_registration_fact');
  return ['mode'=>'observation_only','checks'=>[
   ['id'=>'public_registration','result'=>$registration===null?'UNKNOWN':($registration?'REVIEW':'PASS'),'meaning'=>'Public registration off reduces one account-creation entry point; it is not complete account protection.'],
   ['id'=>'registration_role','result'=>$role===null?'UNKNOWN':($role==='subscriber'?'PASS':(in_array($role,['administrator','editor','author'],true)?'REVIEW':'UNKNOWN')),'meaning'=>'Default role only; custom role capabilities and other account-creation paths need separate review.'],
   ['id'=>'login_enforcement','result'=>'NOT_ENABLED','meaning'=>'Preview never rejects authentication or changes sessions.'],
   ['id'=>'mfa_coverage','result'=>'UNKNOWN','meaning'=>'No per-account MFA coverage was inspected.'],
   ['id'=>'https_login','result'=>'UNKNOWN','meaning'=>'An HTTPS site URL alone does not verify login transport or proxy configuration.'],
   ['id'=>'application_passwords','result'=>'UNKNOWN','meaning'=>'Integration dependencies have not been inventoried.'],
   ['id'=>'country_coverage','result'=>'UNKNOWN','meaning'=>'No trusted country resolver or observation sample is configured.']]];
 }
 public static function country(array $sample,array $selected) {
  if(count($sample)>251||count($selected)>249)throw new InvalidArgumentException('country_cap');
  $chosen=[];foreach($selected as $code){if(!is_string($code)||!preg_match('/^[A-Z]{2}$/D',$code))throw new InvalidArgumentException('invalid_country');$chosen[$code]=true;}
  $total=0;$affected=0;$unknown=0;$protected=0;
  foreach($sample as $code=>$row){
   if(!is_string($code)||($code!=='UNKNOWN'&&!preg_match('/^[A-Z]{2}$/D',$code))||!is_array($row))throw new InvalidArgumentException('invalid_sample');
   if(array_diff(array_keys($row),['requests','protected_requests']))throw new InvalidArgumentException('unexpected_sample_fields');
   $n=$row['requests']??null;$p=$row['protected_requests']??null;
   if(!is_int($n)||!is_int($p)||$n<0||$n>1000000||$p<0||$p>$n)throw new InvalidArgumentException('invalid_count');
   $total+=$n;$protected+=$p;
   if($code==='UNKNOWN')$unknown+=$n;elseif(isset($chosen[$code]))$affected+=($n-$p);
  }
  return ['mode'=>'observation_only','action'=>'allow','sample_requests'=>$total,'selected_country_requests_excluding_protected'=>$affected,'protected_requests'=>$protected,'unknown_country_requests'=>$unknown,'impact_percent_of_sample'=>$total?round(100*$affected/$total,2):null,'coverage'=>$total===0?'UNAVAILABLE':($unknown?'PARTIAL':'SAMPLE_ONLY'),'projection_only'=>true,'actual_blocked'=>0];
 }
}
