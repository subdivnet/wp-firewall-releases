<?php
/** Per-installation feed-cache accounting. No credentials or observed inventory. */
final class WFP_Hub_Capacity {
 const MAX_BYTES=536870912;
 const MAX_FILES=2048;
 /** New installations keep feed data outside both WordPress and the server web root. */
 public static function private_parent($wordpressRoot,$documentRoot){
  $wordpress=realpath($wordpressRoot);
  if(!$wordpress||!is_dir($wordpress))throw new RuntimeException('hub_private_root_required');
  $public=$wordpress;
  if(is_string($documentRoot)&&$documentRoot!==''){
   $document=realpath($documentRoot);
   if(!$document||!is_dir($document))throw new RuntimeException('hub_private_root_required');
   if($wordpress===$document||strpos($wordpress.'/',rtrim($document,'/').'/')===0)$public=$document;
   elseif(strpos($document.'/',rtrim($wordpress,'/').'/')!==0)throw new RuntimeException('hub_private_root_required');
  }
  $parent=dirname($public);
  if($parent===$public||$parent===DIRECTORY_SEPARATOR||!is_dir($parent)||!is_writable($parent))throw new RuntimeException('hub_private_root_required');
  return $parent;
 }
 /** Read-only legacy admission measurement. Never opens file contents or returns names. */
 public static function audit($root,$maximumFiles=32768,$seconds=1.0){
  $out=['logical_bytes'=>0,'files'=>0,'complete'=>false,'captured_at_utc'=>gmdate('Y-m-d H:i:s')];
  $start=microtime(true);$directories=0;
  try{
   if(is_link($root)||!is_dir($root))return $out;
   $walk=function($dir,$depth)use(&$walk,&$out,&$directories,$start,$maximumFiles,$seconds){
    if($depth>3||++$directories>2048)throw new RuntimeException('measurement_incomplete');
    foreach(new DirectoryIterator($dir) as $entry){
     if($entry->isDot())continue;
     if(microtime(true)-$start>$seconds||$out['files']>=$maximumFiles)throw new RuntimeException('measurement_incomplete');
     if($entry->isLink())throw new RuntimeException('measurement_incomplete');
     if($entry->isDir())$walk($entry->getPathname(),$depth+1);
     elseif($entry->isFile()){$out['logical_bytes']+=$entry->getSize();$out['files']++;}
     else throw new RuntimeException('measurement_incomplete');
    }
   };$walk($root,0);$out['complete']=true;
  }catch(Throwable $error){ /* Partial totals are explicitly labelled and never authorize cleanup. */ }
  return $out;
 }
 public static function identity($url,$salt){
  if(!is_string($url)||strlen($url)>2048||!is_string($salt)||$salt==='')throw new RuntimeException('hub_site_identity_unavailable');
  $parts=parse_url($url);if(!is_array($parts)||($parts['scheme']??'')!=='https'||empty($parts['host'])||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment']))throw new RuntimeException('hub_site_identity_unavailable');
  return hash_hmac('sha256','wfp-private-hub-site-v1|'.rtrim($url,'/'),$salt);
 }
 public static function scan($root){
  if(is_link($root)||!is_dir($root))throw new RuntimeException('hub_storage_unavailable');
  $out=['bytes'=>0,'files'=>0,'directories'=>0,'paths'=>[]];
  $walk=function($dir,$depth)use(&$walk,&$out,$root){
   if($depth>3)throw new RuntimeException('hub_cache_capacity');
   $names=scandir($dir);if($names===false)throw new RuntimeException('hub_storage_unavailable');
   foreach($names as $name){if($name==='.'||$name==='..')continue;$path=$dir.'/'.$name;
    if(is_link($path))throw new RuntimeException('hub_cache_unknown_object');
    if(is_dir($path)){if(++$out['directories']>64)throw new RuntimeException('hub_cache_capacity');$walk($path,$depth+1);}
    elseif(is_file($path)){$stat=lstat($path);if(!$stat||$stat['nlink']!==1)throw new RuntimeException('hub_cache_unknown_object');$out['bytes']+=$stat['size'];$out['files']++;$out['paths'][$path]=true;}
    else throw new RuntimeException('hub_cache_unknown_object');
    if($out['bytes']>self::MAX_BYTES||$out['files']>self::MAX_FILES)throw new RuntimeException('hub_cache_capacity');
   }
  };$walk($root,0);return $out;
 }
 public static function reserve(&$budget,$bytes,array $paths){
  if(!is_int($bytes)||$bytes<0)throw new RuntimeException('hub_cache_capacity');
  $added=[];foreach($paths as $path)if(!isset($budget['paths'][$path]))$added[$path]=true;
  if($budget['bytes']+$bytes>self::MAX_BYTES||$budget['files']+count($added)>self::MAX_FILES)throw new RuntimeException('hub_cache_capacity');
  $budget['bytes']+=$bytes;$budget['files']+=count($added);$budget['paths']+=$added;
 }
 public static function reserve_row(&$budget,$directory,array $row){
  $software=$row['record']['software']??null;if(!is_array($software)||count($software)>4096)throw new RuntimeException('hub_cache_capacity');
  $paths=[$directory.'/seen-'.substr(hash('sha256',$row['id']),0,2)];$identities=[];
  foreach($software as $entry){if(!is_array($entry)||!is_string($entry['type']??null)||!is_string($entry['slug']??null)||strlen($entry['slug'])>512)throw new RuntimeException('software_shape');$hash=hash('sha256',$entry['type'].':'.$entry['slug']);$identities[$hash]=true;$paths[]=$directory.'/bucket-'.substr($hash,0,2);}
  // Feed/record bounds make every appended index line <112bytes; UUID line is65bytes.
  self::reserve($budget,65+112*count($identities),$paths);
 }
 public static function remove_retired($root,$hash,array $protected){
  if(!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash)||in_array($hash,$protected,true))throw new RuntimeException('hub_retirement_invalid');
  $dir=$root.'/'.$hash;if(!file_exists($dir)&&!is_link($dir))return;
  if(is_link($dir)||!is_dir($dir))throw new RuntimeException('hub_cache_unknown_object');
  $files=[];$index=false;
  foreach(scandir($dir) as $name){if($name==='.'||$name==='..')continue;$path=$dir.'/'.$name;
   if($name==='index'&&is_dir($path)&&!is_link($path)){$index=true;foreach(scandir($path) as $leaf){if($leaf==='.'||$leaf==='..')continue;if(!preg_match('/^(?:seen|bucket)-[a-f0-9]{2}$/D',$leaf))throw new RuntimeException('hub_cache_unknown_object');$files[]=$path.'/'.$leaf;}}
   elseif($name==='scanner.json')$files[]=$path;
   else throw new RuntimeException('hub_cache_unknown_object');
  }
  // Validate the complete deletion set before unlinking any object. Unknown files stay untouched.
  foreach($files as $file){$st=lstat($file);if(is_link($file)||!is_file($file)||!$st||$st['nlink']!==1||(function_exists('posix_geteuid')&&$st['uid']!==posix_geteuid())||($st['mode']&0777)!==0600)throw new RuntimeException('hub_cache_unknown_object');}
  foreach($files as $file)if(!unlink($file))throw new RuntimeException('hub_storage_unavailable');
  if($index&&!rmdir($dir.'/index'))throw new RuntimeException('hub_storage_unavailable');
  if(!rmdir($dir))throw new RuntimeException('hub_storage_unavailable');
 }
}
