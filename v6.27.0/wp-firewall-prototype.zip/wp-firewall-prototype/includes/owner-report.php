<?php
/** Narrow, read-only owner notification report. No mail, credentials or writes. */
if (!defined('ABSPATH')) { exit; }
final class WFP_Owner_Report {
 public static function current(){
  if(!function_exists('get_plugins'))require_once ABSPATH.'wp-admin/includes/plugin.php';
  $key=hash_hmac('sha256','wfp-vulnerability-component-v1',wp_salt('auth'),true);
  $plugins=[];
  foreach(get_plugins() as $file=>$metadata){$slug=dirname($file);if($slug==='.')$slug=basename($file,'.php');$plugins[hash_hmac('sha256','plugin:'.$slug,$key)]=true;}
  $raw=get_option(WFP_Observer::STATE,null);
  $state=is_array($raw)?WFP_Observer::read_state():null;
  return self::build(home_url(),get_option(WFP_Scanner_Host_Lab::ALERTS,null),$plugins,$state,time(),$key);
 }
 public static function build($site,$alerts,$plugins,$state,$now,$key){
  $stamp=is_array($alerts)?WFP_State_Sanitizer::timestamp($alerts['checked_at_utc']??null):'';
  $valid=$stamp!==''&&strtotime($stamp.' UTC')<=$now&&in_array($alerts['status']??'', ['COMPLETE','PARTIAL'],true)&&is_int($alerts['components_checked']??null)&&$alerts['components_checked']>0;
  $coverage=$valid?$alerts['status']:'UNAVAILABLE';$found=[];$revision=[];$known=$valid;
  if($valid){
   if(!is_array($alerts['findings']??null)||count($alerts['findings'])>200)$known=false;
   else foreach($alerts['findings'] as $f){
    if(!is_array($f)||!is_string($f['component_token']??null)||!preg_match('/^[a-f0-9]{64}$/D',$f['component_token'])||!is_string($f['id']??null)||strlen($f['id'])>200){$known=false;continue;}
    if(isset($plugins[$f['component_token']])){$found[$f['component_token']]=true;$revision[]=$f['component_token'].':'.$f['id'];}
   }
  }
  sort($revision,SORT_STRING);$revision=array_values(array_unique($revision));
  $fresh=$valid?WFP_Scanner_Match::freshness($alerts['feed_attempt_utc']??null,$stamp,$now):['feed_status'=>'UNKNOWN'];
  return ['site'=>rtrim($site,'/'),'checked_at_utc'=>$valid?$stamp:null,'coverage'=>$coverage,'feed_status'=>$fresh['feed_status'],'vulnerable_plugins'=>$known?count($found):null,'components_checked'=>$valid?$alerts['components_checked']:null,'plugin_revision'=>$known?hash_hmac('sha256',implode('|',$revision),$key):null,'attacks'=>self::attacks($state,$now)];
 }
 public static function attacks($state,$now,$seconds=604800){
  if(!in_array($seconds,[86400,604800],true))throw new InvalidArgumentException('Fixed observation window required');
  if(!is_array($state)||!is_array($state['events']??null))return null;
  $start=$now-$seconds;$out=['failed_logins'=>0,'guessing_bursts'=>0,'sensitive_file_probes'=>0,'xmlrpc_abuse_signals'=>0,'window_start_utc'=>gmdate('Y-m-d H:i:s',$start),'window_end_utc'=>gmdate('Y-m-d H:i:s',$now),'partial'=>true];
  foreach(array_slice($state['events'],0,100) as $e){
   if(!is_array($e))continue;$a=WFP_State_Sanitizer::timestamp($e['time']??null);$b=WFP_State_Sanitizer::timestamp($e['last_seen_utc']??($e['time']??null));
   if($a===''||$b==='')continue;$a=strtotime($a.' UTC');$b=strtotime($b.' UTC');
   if($a<$start||$b<$a||$b>$now)continue;
   $n=$e['occurrences']??1;if(!is_int($n)||$n<1||$n>1000000)continue;
   $signals=array_map('trim',explode(',',(string)($e['signals']??'')));
   if(in_array('failed_login',$signals,true)){
    $out['failed_logins']=min(1000000,$out['failed_logins']+$n);
    if($n>=3&&$b-$a<=15){$out['guessing_bursts']++;if(($e['entry_point']??'')==='XML-RPC')$out['xmlrpc_abuse_signals']++;}
   }
   if(in_array('sensitive_file_probe',$signals,true))$out['sensitive_file_probes']=min(1000000,$out['sensitive_file_probes']+$n);
  }
  return $out;
 }
}
