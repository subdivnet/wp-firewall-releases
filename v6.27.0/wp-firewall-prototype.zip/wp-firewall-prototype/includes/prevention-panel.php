<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__.'/prevention-preview.php';
/** Read-only composition over existing sanitized observations. No auth filters/writes. */
final class WFP_Prevention_Panel {
 public static function init(){add_action('admin_menu',[__CLASS__,'menu']);add_action('rest_api_init',[__CLASS__,'routes']);}
 public static function menu(){add_management_page('Firewall Prevention','Firewall Prevention','manage_options','wfp-prevention',[__CLASS__,'page']);}
 public static function routes(){register_rest_route('wfp/v1','/prevention',['methods'=>'GET','permission_callback'=>function(){return current_user_can('manage_options');},'callback'=>[__CLASS__,'status']]);}
 public static function buckets(array $events,$now){
  $current=intdiv($now,300)*300;$counts=[$current-600=>0,$current-300=>0,$current=>0];$ambiguous=0;
  foreach(array_slice($events,0,100) as $event){
   if(!is_array($event)||($event['signals']??'')!=='failed_login')continue;
   $first=WFP_State_Sanitizer::timestamp($event['time']??'');$last=WFP_State_Sanitizer::timestamp($event['last_seen_utc']??($event['time']??''));
   if($first===''||$last===''){$ambiguous++;continue;}
   $a=strtotime($first.' UTC');$b=strtotime($last.' UTC');
   if($a===false||$b===false||$b<$a||$b>$now){$ambiguous++;continue;}
   if($b<$current-600)continue;
   $slot=intdiv($a,300)*300;
   if(!isset($counts[$slot])||intdiv($b,300)*300!==$slot){$ambiguous++;continue;}
   $n=$event['occurrences']??1;if(!is_int($n)||$n<1||$n>1000000){$ambiguous++;continue;}$counts[$slot]=min(1000000,$counts[$slot]+$n);
  }
  $preview=WFP_Prevention_Preview::login($counts,$now);$preview['coverage']='RETAINED_GROUPS_ONLY';
  if($preview['pressure']==='BELOW_THRESHOLD')$preview['pressure']='NO_THRESHOLD_IN_RETAINED_GROUPS';
  $preview['ambiguous_groups_excluded']=$ambiguous;
  return ['buckets'=>array_map(function($t,$n){return ['bucket_start_utc'=>gmdate('Y-m-d H:i:s',$t),'failed_attempts'=>$n];},array_keys($counts),array_values($counts)),'preview'=>$preview];
 }
 public static function status(){
  $state=WFP_Observer::read_state();$now=time();$registration=get_option('users_can_register',null);$role=get_option('default_role',null);
  $facts=['registration_enabled'=>in_array($registration,[0,'0',false],true)?false:(in_array($registration,[1,'1',true],true)?true:null),'default_role'=>is_string($role)?$role:null];
  return ['schema'=>1,'captured_at_utc'=>gmdate('Y-m-d H:i:s',$now),'mode'=>'observation_only','enforcement_enabled'=>false,'login'=>self::buckets($state['events']??[],$now),'audit'=>WFP_Prevention_Preview::audit($facts),'country'=>WFP_Prevention_Preview::country([],[]),'limits'=>['Counts are retained hook observations, not distinct people or complete traffic.','Concurrent option updates can lose observations.','Cross-bucket groups are excluded; zero is not proof of protection.','No country resolver or country sample is configured.']];
 }
 public static function page(){
  if(!current_user_can('manage_options'))wp_die('Insufficient permissions');nocache_headers();$r=self::status();
  echo '<div class="wrap"><h1>Firewall Prevention</h1><p><strong>Observation only — enforcement OFF.</strong> Actual local data. Updated '.esc_html($r['captured_at_utc']).' UTC. Refreshes every 30 seconds.</p><h2>Login protection preview</h2><p>Site-wide advisory threshold: 5 failed attempts across the current and previous two five-minute buckets. This is not per-person throttling.</p><table class="widefat striped"><thead><tr><th>Five-minute bucket begins (UTC)</th><th>Retained failed attempts</th></tr></thead><tbody>';
  foreach($r['login']['buckets'] as $b)echo '<tr><td>'.esc_html($b['bucket_start_utc']).'</td><td>'.esc_html((string)$b['failed_attempts']).'</td></tr>';
  echo '</tbody></table><p>Preview: <strong>'.esc_html($r['login']['preview']['pressure']).'</strong>. Coverage: retained groups only. Ambiguous groups excluded: '.esc_html((string)$r['login']['preview']['ambiguous_groups_excluded']).'. No request is blocked.</p><h2>Prevention audit</h2><table class="widefat striped"><thead><tr><th>Check</th><th>Result</th><th>Evidence and limit</th></tr></thead><tbody>';
  $labels=['public_registration'=>'Public registration','registration_role'=>'Default new-account role','login_enforcement'=>'Login enforcement','mfa_coverage'=>'Multi-factor authentication','https_login'=>'Login HTTPS and proxy','application_passwords'=>'Application Password dependencies','country_coverage'=>'Country observation coverage'];
  foreach($r['audit']['checks'] as $check)echo '<tr><td>'.esc_html($labels[$check['id']]).'</td><td>'.esc_html($check['result']).'</td><td>'.esc_html($check['meaning']).'</td></tr>';
  echo '</tbody></table><h2>Country impact preview</h2><p><strong>UNAVAILABLE: no trusted country sample.</strong> No country selection or blocking is active. Future preview separates unknown locations and protected requests; sampled requests are not people or projected business impact.</p><h2>Coverage limits</h2><ul>';
  foreach($r['limits'] as $limit)echo '<li>'.esc_html($limit).'</li>';
  echo '</ul><p>No settings are changed by this page. Existing observations and schedules are retained.</p></div><script>window.setTimeout(function(){window.location.reload();},30000);</script>';
 }
}
WFP_Prevention_Panel::init();
