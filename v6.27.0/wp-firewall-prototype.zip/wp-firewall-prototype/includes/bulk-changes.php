<?php
if (!defined('ABSPATH')) { exit; }
/** Aggregate-only assessment shared across independently scoped scanners. */
final class WFP_Bulk_Changes {
 public static function assess($r, $max) {
  $unknown = ['status' => 'not_assessed', 'affected_items' => null, 'scope_items' => null, 'percent_tenths' => null, 'interval_seconds' => null];
  if (($r['status'] ?? '') !== 'compared' || !is_int($r['previous_items'] ?? null)
   || WFP_State_Sanitizer::timestamp($r['previous_time_utc'] ?? null) === ''
   || WFP_State_Sanitizer::timestamp($r['time_utc'] ?? null) === '') { return $unknown; }
  foreach (['items_checked','new_items','changed_items','left_published_scope','previous_items'] as $field) {
   if (!is_int($r[$field] ?? null) || $r[$field] < 0 || $r[$field] > $max) { return $unknown; }
  }
  if ($r['previous_items'] !== $r['items_checked'] - $r['new_items'] + $r['left_published_scope']
   || $r['new_items'] + $r['changed_items'] > $r['items_checked'] || $r['previous_time_utc'] > $r['time_utc']) { return $unknown; }
  $scope = $r['previous_items'] + $r['new_items'];
  $affected = $r['new_items'] + $r['changed_items'] + $r['left_published_scope'];
  $interval = strtotime($r['time_utc'] . ' UTC') - strtotime($r['previous_time_utc'] . ' UTC');
  $flag = $affected >= 100 || ($affected >= 10 && $affected * 4 >= $scope);
  return ['status' => $flag ? 'review' : 'below_threshold', 'affected_items' => $affected, 'scope_items' => $scope,
   'percent_tenths' => $scope ? intdiv($affected * 1000, $scope) : 0, 'interval_seconds' => $interval];
 }
 public static function files($r, $max) {
  return self::assess([
   'status' => $r['status'] ?? null, 'time_utc' => $r['time_utc'] ?? null,
   'previous_time_utc' => $r['previous_time_utc'] ?? null,
   'previous_items' => $r['previous_files'] ?? null, 'items_checked' => $r['files_checked'] ?? null,
   'new_items' => $r['new_files'] ?? null, 'changed_items' => $r['changed_files'] ?? null,
   'left_published_scope' => $r['absent_files'] ?? null,
  ], $max);
 }
 public static function render_files($status) {
  if (!isset($status['latest']['bulk_assessment'])) { return; }
  $a = $status['latest']['bulk_assessment'];
  echo '<p>Bulk file change review: <strong>'.esc_html(str_replace('_', ' ', $a['status'])).'</strong>.</p>';
  foreach ($status['bulk_review'] as $r) {
   $a = $r['bulk_assessment'];
   echo '<p><strong>Large file changes to review</strong> at '.esc_html($r['time_utc']).' UTC: '.esc_html((string) $a['affected_items']).' affected paths out of '.esc_html((string) $a['scope_items']).' observed across both snapshots ('.esc_html(number_format($a['percent_tenths'] / 10, 1)).'%). Previous snapshot '.esc_html($r['previous_time_utc']).' UTC, '.esc_html((string) $r['previous_files']).' files; current '.esc_html((string) $r['files_checked']).' files. Observed interval: '.esc_html((string) $a['interval_seconds']).' seconds. Changes could have occurred at any point in this interval; this does not establish a rapid burst or compromise.</p>';
  }
  echo '<details><summary>How bulk file review works</summary><p>Review at least 100 new, changed or absent paths, or at least 10 affecting 25% of the union of the previous and current complete snapshots. Each scoped path counts once; returning paths are included in new paths. Updates, installations, restores and renames can explain changes. Only complete comparisons with saved previous counts and times are assessed; older reports remain unknown. A below-threshold result is not a clean-site verdict. Comparison scopes stay separate. Review summaries remain among the last 24 reports after quiet scans. No automatic notification or action occurs.</p></details>';
 }
}
