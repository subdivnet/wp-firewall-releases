<?php
if (!defined('ABSPATH')) { exit; }
/** Read-only projections of validated stored reports. Never initiates scans. */
final class WFP_Scan_Overview {
 const OLD_AFTER = 7200;
 public static function status($now = null) {
  return self::build([
   'core' => WFP_Core_Integrity::summary(),
   'content' => WFP_Content_Integrity::status(),
   'metadata' => WFP_Metadata_Integrity::status(),
   'options' => WFP_Options_Integrity::status(),
   'files' => WFP_Extension_Integrity::status(),
   'packages' => WFP_Plugin_Packages::summary(),
   'uploads' => WFP_Uploads_Inventory::status(),
   'candidates' => WFP_Upload_Candidates::status(),
   'config' => WFP_Config_Integrity::status(),
  ], $now);
 }
 private static function count($r, $key) {
  return is_int($r[$key] ?? null) && $r[$key] >= 0 ? $r[$key] : null;
 }
 private static function values($r, $fields) {
  $parts = [];
  foreach ($fields as $key => $label) {
   $n = self::count($r, $key);
   $parts[] = $label . ': ' . ($n === null ? 'unknown' : $n);
  }
  return implode('; ', $parts);
 }
 /** Input comes only from the scanners' validated read-only status/history methods. */
 public static function build($sources, $now = null) {
  $now = $now === null ? time() : (int) $now;
  $rows = [];
  foreach (['core' => 'WordPress core', 'content' => 'Published content', 'files' => 'Plugin and theme files',
   'packages' => 'Official plugin packages', 'uploads' => 'Upload filename inventory', 'candidates' => 'Upload candidate contents', 'config' => 'Configuration and drop-ins', 'metadata' => 'Published metadata rows', 'options' => 'Selected site settings'] as $id => $label) {
   $source = $sources[$id] ?? [];
   $r = in_array($id, ['core','packages'], true) ? $source : ($source['latest'] ?? []);
   $stamp = WFP_State_Sanitizer::timestamp($r[$id === 'core' ? 'checked_at_utc' : 'time_utc'] ?? null);
   $age = $stamp === '' ? null : $now - strtotime($stamp . ' UTC');
   $valid = $age !== null && $age >= 0;
   $row = ['scope' => $id, 'label' => $label, 'anchor' => 'wfp-scan-' . $id,
    'report_time_utc' => $valid ? $stamp : null, 'age_seconds' => $valid ? $age : null,
    'freshness' => !$valid ? 'unknown' : ($age > self::OLD_AFTER ? 'older_than_two_hours' : 'within_two_hours'),
    'coverage' => 'unknown', 'latest_observations' => 'No valid saved report available.',
    'retained_bulk_comparisons' => 0, 'retained_return_comparisons' => 0, 'retained_reversion_comparisons' => 0,
    'last_reversion_review_utc' => null, 'reversion_tracking' => null,
    'last_bulk_review_utc' => null, 'last_return_review_utc' => null, 'review_observations' => false,
    'progress' => null, 'return_tracking' => null, 'latest_bulk_assessment' => null];
   if ($valid) {
    $status = $r['status'] ?? 'not_run';
    $row['coverage'] = in_array($status, ['completed','compared'], true) ? 'complete' :
     (in_array($status, ['reference_created','reference_reinitialized'], true) ? 'initial_unverified_reference' : 'incomplete');
    if (in_array($id, ['content','files','candidates','config','metadata','options'], true)) {
     $item = in_array($id, ['content','metadata','options'], true);
     { $row['reversion_tracking'] = in_array($r['reversion_tracking'] ?? '', ['not_tracked','started','restarted','active','limited'],true) ? $r['reversion_tracking'] : 'not_tracked'; }
     $row['return_tracking'] = in_array($r['return_tracking'] ?? '', ['not_tracked','started','restarted','active','limited'], true) ? $r['return_tracking'] : 'not_tracked';
     $row['latest_bulk_assessment'] = in_array($r['bulk_assessment']['status'] ?? '', ['review','below_threshold','not_assessed'], true) ? $r['bulk_assessment']['status'] : 'not_assessed';
     if ($status === 'compared') {
      $fields = $item ? ['items_checked'=>($id === 'metadata' ? 'Rows checked' : 'Items checked'),'new_items'=>'New','changed_items'=>'Changed','left_published_scope'=>($id === 'options' ? 'Left selected scope' : 'Left published scope')]
       : ['files_checked'=>'Files checked','new_files'=>'New','changed_files'=>'Changed','absent_files'=>'Absent'];
      $row['latest_observations'] = self::values($r, $fields);
      foreach ($item ? ['new_items','changed_items','left_published_scope'] : ['new_files','changed_files','absent_files'] as $key) {
       if ((self::count($r, $key) ?? 0) > 0) { $row['review_observations'] = true; }
      }
     } else { $row['latest_observations'] = in_array($status, ['reference_created','reference_reinitialized'], true)
      ? 'Starting reference is unverified; changes were not compared.' : 'Comparison incomplete; previous complete reference preserved. See scope details.'; }
     // Revalidate history and recompute verdicts; never accept caller-supplied review lists.
     $cleaner = $item ? ($id === 'options' ? 'WFP_Options_Integrity' : ($id === 'metadata' ? 'WFP_Metadata_Integrity' : 'WFP_Content_Integrity')) : ($id === 'files' ? 'WFP_Extension_Integrity' : ($id === 'config' ? 'WFP_Config_Integrity' : 'WFP_Upload_Candidates'));
     $history = is_array($source['history'] ?? null) ? array_slice($source['history'], 0, 24) : [];
     foreach ($history as $raw) {
      $h = $cleaner::clean_report($raw);
      if ($h === false || $h['time_utc'] > gmdate('Y-m-d H:i:s', $now)) { continue; }
      if (($h['bulk_assessment']['status'] ?? '') === 'review') {
       $row['retained_bulk_comparisons']++;
       if ($row['last_bulk_review_utc'] === null || $h['time_utc'] > $row['last_bulk_review_utc']) { $row['last_bulk_review_utc'] = $h['time_utc']; }
      }
      if (($h[$item ? 'reverted_items' : 'reverted_files'] ?? 0) > 0) {
       $row['retained_reversion_comparisons']++;
       if ($row['last_reversion_review_utc'] === null || $h['time_utc'] > $row['last_reversion_review_utc']) { $row['last_reversion_review_utc'] = $h['time_utc']; }
      }
      if (($h[$item ? 'reappeared_items' : 'reappeared_files'] ?? 0) > 0) {
       $row['retained_return_comparisons']++;
       if ($row['last_return_review_utc'] === null || $h['time_utc'] > $row['last_return_review_utc']) { $row['last_return_review_utc'] = $h['time_utc']; }
      }
     }
    } elseif ($id === 'core') {
     $row['latest_observations'] = self::values($r, ['matched_files'=>'Matched','modified_files'=>'Modified','missing_files'=>'Missing','unexpected_files'=>'Unexpected']);
     foreach (['modified_files','missing_files','unexpected_files'] as $key) { if ((self::count($r, $key) ?? 0) > 0) { $row['review_observations'] = true; } }
     if (($r['matches_current_package'] ?? false) !== true || ($r['scanner_revision'] ?? null) !== WFP_Core_Integrity::REVISION) { $row['coverage'] = 'package_or_engine_changed'; }
     if ($status !== 'completed') { $row['latest_observations'] .= '. Observed counts only; coverage is incomplete.'; }
    } elseif ($id === 'packages') {
     $totals = ['matched'=>0,'modified'=>0,'missing'=>0,'unexpected'=>0];
     foreach (is_array($r['packages'] ?? null) ? $r['packages'] : [] as $package) {
      foreach ($totals as $key => $n) { $totals[$key] += self::count($package, $key) ?? 0; }
     }
     $row['latest_observations'] = self::values($r, ['packages_completed'=>'Packages completed','packages_unverified'=>'Unverified'])
      . '. ' . self::values($totals, ['matched'=>'Matched files','modified'=>'Modified','missing'=>'Missing','unexpected'=>'Unexpected']);
     $row['review_observations'] = $totals['modified'] + $totals['missing'] + $totals['unexpected'] > 0;
     if ($status !== 'completed') { $row['latest_observations'] .= '. Private plugins or unavailable official metadata can explain unverified coverage; not a malware finding.'; }
    } elseif ($id === 'uploads') {
     $row['latest_observations'] = $status === 'completed' ? self::values($r, ['script_named_files'=>'Script-like names','configuration_files'=>'Configuration names'])
      : 'Inventory incomplete; observed per-pass counts appear in scope details, not complete totals.';
     $row['review_observations'] = $status === 'completed' && (self::count($r, 'script_named_files') + self::count($r, 'configuration_files') > 0);
    }
   }
   if (in_array($id, ['content','metadata','options'], true) && ($source['progress']['status'] ?? '') === 'in_progress') {
    $row['progress'] = 'A comparison is in progress; the saved report above remains separate.';
   }
   $row['review_observations'] = $row['review_observations'] || $row['retained_bulk_comparisons'] > 0 || $row['retained_return_comparisons'] > 0 || $row['retained_reversion_comparisons'] > 0;
   $row['review_coverage'] = $row['coverage'] !== 'complete' || $row['freshness'] !== 'within_two_hours'
    || ($row['return_tracking'] !== null && $row['return_tracking'] !== 'active')
    || $row['latest_bulk_assessment'] === 'not_assessed'
    || ($row['reversion_tracking'] !== null && $row['reversion_tracking'] !== 'active');
   $rows[] = $row;
  }
  return ['schema_version' => 1, 'as_of_utc' => gmdate('Y-m-d H:i:s', $now), 'scopes' => $rows,
   'meaning' => 'Separate stored observations, not a whole-site clean or compromise verdict. Scopes overlap; do not add their findings. No automatic alerts or enforcement.'];
 }
 public static function render($report = null) {
  $report = $report === null ? self::status() : $report;
  echo '<section aria-labelledby="wfp-scan-review"><h2 id="wfp-scan-review">Scan review overview</h2>';
  echo '<p>Start here for saved findings and coverage gaps. Differences, bulk changes and returning paths need context: updates and restores can explain them. A name match is not a malware verdict. Each row links to its evidence and scan controls.</p>';
  echo '<table class="widefat striped"><thead><tr><th>Scan scope</th><th>Latest saved observations</th><th>Coverage and time</th><th>Retained review</th></tr></thead><tbody>';
  foreach ($report['scopes'] as $row) {
   echo '<tr><th><a href="#'.esc_html($row['anchor']).'">'.esc_html($row['label']).'</a></th><td>'.esc_html($row['latest_observations']);
   if ($row['progress'] !== null) { echo '<p>'.esc_html($row['progress']).'</p>'; }
   if ($row['return_tracking'] !== null) { echo '<p>Return tracking: '.esc_html(str_replace('_', ' ', $row['return_tracking'])).'; latest bulk review: '.esc_html(str_replace('_', ' ', $row['latest_bulk_assessment'])).'.</p>'; }
   if ($row['reversion_tracking'] !== null) { echo '<p>Reversion tracking: '.esc_html(str_replace('_',' ',$row['reversion_tracking'])).'.</p>'; }
   echo '</td><td>'.esc_html(str_replace('_', ' ', $row['coverage'])).'<br>';
   echo $row['report_time_utc'] === null ? 'Time unknown' : esc_html($row['report_time_utc']).' UTC';
   if ($row['freshness'] === 'older_than_two_hours') { echo '<br><strong>Report older than two hours</strong>'; }
   if ($row['review_coverage']) { echo '<br>Review coverage details'; }
   echo '</td><td>';
   if ($row['retained_bulk_comparisons'] || $row['retained_return_comparisons'] || $row['retained_reversion_comparisons']) {
    echo 'Bulk comparisons: '.esc_html((string)$row['retained_bulk_comparisons']).'; return comparisons: '.esc_html((string)$row['retained_return_comparisons']).'; reversion comparisons: '.esc_html((string)$row['retained_reversion_comparisons']);
    if ($row['last_reversion_review_utc'] !== null) { echo '<br>Latest reversion review: '.esc_html($row['last_reversion_review_utc']).' UTC'; }
    if ($row['last_bulk_review_utc'] !== null) { echo '<br>Latest bulk review: '.esc_html($row['last_bulk_review_utc']).' UTC'; }
    if ($row['last_return_review_utc'] !== null) { echo '<br>Latest return review: '.esc_html($row['last_return_review_utc']).' UTC'; }
   } elseif (in_array($row['scope'], ['content','files','candidates','config','metadata','options'], true)) { echo 'No retained bulk, return or reversion review in these reports; earlier history may be unavailable.'; }
   else { echo 'Bulk and same-path return tracking belong to the separate comparison scopes.'; }
   if ($row['review_observations']) { echo '<br><strong>Review observed differences or names in scope details</strong>'; }
   echo '</td></tr>';
  }
  echo '</tbody></table><p>Retention is at most 24 reports per comparison scope; review counts are comparisons, not distinct incidents or files, and one comparison can appear in multiple categories. Other scanners have different retention. Complete describes bounded scan coverage, not site safety. Older than two hours describes saved report age, not proof of downtime or why a scan was delayed. WordPress cron depends on traffic or a runner; enabled schedules do not prove execution. Core and official package results describe the package observed at that scan; refresh after maintenance.</p><p>'.esc_html($report['meaning']).'</p></section>';
 }
}
