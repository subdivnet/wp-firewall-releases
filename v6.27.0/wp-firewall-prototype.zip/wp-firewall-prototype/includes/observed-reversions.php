<?php
if (!defined('ABSPATH')) { exit; }
/** Bounded immediately-prior fingerprint evidence; caller supplies protected maps only. */
final class WFP_Observed_Reversions {
 const WINDOW = 604800;
 const MAX_CHANGED = 2000;
 public static function observe($old, $current, $stamp) {
  $now = strtotime($stamp . ' UTC'); $cutoff = $now - self::WINDOW;
  $old_items = is_array($old) && is_array($old['items'] ?? null) ? $old['items'] : [];
  $prior = is_array($old) ? ($old['reversions'] ?? null) : null;
  $valid = is_array($prior) && ($prior['schema'] ?? null) === 1
   && ($prior['snapshot_time'] ?? '') === ($old['time'] ?? '')
   && WFP_State_Sanitizer::timestamp($prior['since'] ?? null) !== ''
   && WFP_State_Sanitizer::timestamp($old['time'] ?? null) !== ''
   && $prior['since'] <= $old['time'] && $old['time'] <= $stamp
   && is_array($prior['changed'] ?? null) && count($prior['changed']) <= self::MAX_CHANGED;
  if ($valid) {
   $until = $prior['limited_until'] ?? null;
   if ($until !== null && (WFP_State_Sanitizer::timestamp($until) === '' || $until < $prior['since']
    || $until > gmdate('Y-m-d H:i:s', strtotime($old['time'] . ' UTC') + self::WINDOW))) { $valid = false; }
   foreach ($prior['changed'] as $key => $row) {
    if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key) || !is_array($row)
     || !is_string($row['digest'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $row['digest'])
     || WFP_State_Sanitizer::timestamp($row['displaced_utc'] ?? null) === '' || $row['displaced_utc'] < $prior['since']
     || $row['displaced_utc'] > $old['time'] || !isset($old_items[$key]) || hash_equals($old_items[$key], $row['digest'])) { $valid = false; break; }
   }
  }
  $state = ['schema'=>1, 'since'=>$valid ? $prior['since'] : $stamp, 'snapshot_time'=>$stamp, 'limited_until'=>null, 'changed'=>[]];
  if ($valid && ($prior['limited_until'] ?? '') >= $stamp) { $state['limited_until'] = $prior['limited_until']; }
  if ($valid) {
   foreach ($prior['changed'] as $key => $row) {
    if (isset($current[$key]) && strtotime($row['displaced_utc'] . ' UTC') >= $cutoff) {
     $state['changed'][$key] = ['digest'=>$row['digest'], 'displaced_utc'=>$row['displaced_utc']];
    }
   }
  }
  $count = $valid ? 0 : null;
  foreach ($old_items as $key => $digest) {
   if (!isset($current[$key])) { unset($state['changed'][$key]); continue; }
   if (hash_equals($digest, $current[$key])) { continue; }
   if (isset($state['changed'][$key]) && hash_equals($state['changed'][$key]['digest'], $current[$key])) { $count++; }
   // Always keep only the immediately preceding distinct fingerprint, not arbitrary older versions.
   $state['changed'][$key] = ['digest'=>$digest, 'displaced_utc'=>$stamp];
  }
  uasort($state['changed'], function($a,$b) { return strcmp($b['displaced_utc'],$a['displaced_utc']); });
  if (count($state['changed']) > self::MAX_CHANGED) {
   $state['changed'] = array_slice($state['changed'],0,self::MAX_CHANGED,true);
   $state['limited_until'] = gmdate('Y-m-d H:i:s',$now+self::WINDOW);
  }
  $tracking = !$valid ? ($prior === null ? 'started' : 'restarted') : ($state['limited_until'] !== null ? 'limited' : 'active');
  return ['state'=>$state,'reversion_tracking'=>$tracking,'reversion_tracking_since_utc'=>$state['since'],'reverted_files'=>$count];
 }
 public static function clean_fields($raw, $safe, $unit = 'files') {
  if (!in_array($unit, ['files','items'], true)) { return false; }
  $field = 'reverted_' . $unit;
  $tracking = $raw['reversion_tracking'] ?? 'not_tracked'; $since = $raw['reversion_tracking_since_utc'] ?? null; $count = $raw[$field] ?? null;
  if (!in_array($tracking,['not_tracked','started','restarted','active','limited'],true)) { return false; }
  if ($tracking === 'not_tracked') { if ($since !== null || $count !== null) { return false; } }
  else {
   if (!in_array($safe['status'],['compared','reference_created','reference_reinitialized'],true)
    || WFP_State_Sanitizer::timestamp($since) === '' || $since > $safe['time_utc']) { return false; }
   if (in_array($tracking,['active','limited'],true)) {
    if ($safe['status'] !== 'compared' || !is_int($count) || $count < 0 || $count > $safe['changed_' . $unit]) { return false; }
   } elseif ($count !== null) { return false; }
  }
  $safe['reversion_tracking']=$tracking; $safe['reversion_tracking_since_utc']=$since; $safe[$field]=$count;
  return $safe;
 }
 public static function render($status, $unit = 'files', $label = null) {
  $field = $unit === 'items' ? 'reverted_items' : 'reverted_files';
  $noun = $label === null ? ($unit === 'items' ? 'published items' : 'files') : $label;
  $r=$status['latest'];
  if (!isset($r['reversion_tracking'])) { return; }
  echo '<p>Fingerprint reversion tracking: <strong>'.esc_html(str_replace('_',' ',$r['reversion_tracking'])).'</strong>';
  if ($r['reversion_tracking_since_utc'] !== null) { echo '; observed since '.esc_html($r['reversion_tracking_since_utc']).' UTC'; }
  if ($r[$field] !== null) { echo '; '.esc_html($noun).' matching their immediately preceding fingerprint: '.esc_html((string)$r[$field]); }
  echo '.</p>';
  foreach ($status['reversion_review'] as $review) {
   echo '<p><strong>Observed fingerprint reversions to review</strong> at '.esc_html($review['time_utc']).' UTC: '.esc_html((string)$review[$field]).' changed identifiers matched the immediately preceding fingerprint. Rollbacks and restores can explain this; it is not proof of reinfection or cleanup.</p>';
  }
  echo '<details><summary>How fingerprint reversion tracking works</summary><p>Records an observed A to B to A sequence at the same protected scoped identifier in complete comparisons, including quiet scans between transitions. Only the most recently displaced distinct fingerprint is kept for up to seven days, at most 2000 identifiers. A to B to C to A is not linked. An observed absence from the compared scope clears that identifier from this evidence; absent-then-return tracking stays separate. Different identifiers and scopes are not linked. Changes between scans, renames, expired and truncated evidence may be missed. Quiet scans never refresh displacement age. Tracking starts at the displayed time; prior reports remain unknown, and the first transition can seed evidence from the preceding saved reference without reconstructing older transitions. Reversions are a subset of changed counts, not additional entries or incidents. Review summaries remain among 24 reports after quiet scans; limited tracking can miss reversions. Initial references stay unverified. Partial/failed scans and filename previews never advance evidence. Only protected fingerprints and times are retained, never file contents or published text. No automatic alerts or remediation occur.</p></details>';
 }
}
