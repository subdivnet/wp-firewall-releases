<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Pure, side-effect-free signal classifier. Observation only.
 * Input is an untrusted request URI, never a body or cookie.
 */
final class WFP_Detector {
 public static function classify($uri) {
  if (!is_string($uri) || $uri === '') { return []; }
  $uri = substr($uri, 0, 4096);
  $path = (string) parse_url($uri, PHP_URL_PATH);
  $query = (string) parse_url($uri, PHP_URL_QUERY);
  $signals = [];
  $decoded_path = rawurldecode($path);
  // Count complete parent path segments, even when separated by normal folders.
  // One parent segment may be an innocuous relative URL; two are a stronger probe.
  $segments = preg_split('~[\\\\/]~', $decoded_path);
  $parent_count = 0;
  foreach ($segments as $segment) {
   if ($segment === '..') { $parent_count++; }
  }
  if ($parent_count >= 2) {
   $signals[] = 'repeated_path_traversal';
  }
  // Only path components are inspected; a discussion of a filename in a query
  // does not become a sensitive-file request by itself.
  $file_path = strtolower(str_replace('\\\\', '/', $decoded_path));
  if (preg_match('~(?:^|/)(?:\\.env(?:\\.[a-z0-9_-]+)?|wp-config\\.php(?:\\.[a-z0-9_-]+)?|\\.git/config|\\.aws/credentials)(?:$|/)~i', $file_path)) {
   $signals[] = 'sensitive_file_probe';
  }
  $decoded_query = rawurldecode(str_replace('+', ' ', $query));
  if (preg_match('~<script\\b~i', $decoded_query)) {
   $signals[] = 'script_tag_in_query';
  }
  // Normalize short SQL-style comments to whitespace before matching UNION SELECT.
  // Long or malformed comment sequences are not expanded recursively.
  $sql_query = preg_replace('~/\\*[^*]{0,128}\\*/~', ' ', $decoded_query);
  if (is_string($sql_query) && preg_match('~\\bunion\\s+select\\b~i', $sql_query)) {
   $signals[] = 'sql_union_select_in_query';
  }
  // Examine each key/value independently: a benign file= value must not inherit
  // a traversal indicator from some unrelated query parameter.
  foreach (explode('&', $query) as $pair) {
   $pieces = explode('=', $pair, 2);
   if (count($pieces) !== 2) { continue; }
   $key = rawurldecode(str_replace('+', ' ', $pieces[0]));
   $value = rawurldecode(str_replace('+', ' ', $pieces[1]));
   if (preg_match('~^(?:cmd|exec|shell)$~i', $key) && !in_array('command_parameter', $signals, true)) {
    $signals[] = 'command_parameter';
   }
   if (preg_match('~^(?:file|path)$~i', $key)
    && preg_match('~\\.\\.[\\\\/]~', $value)
    && !in_array('file_path_parameter_traversal', $signals, true)) {
    $signals[] = 'file_path_parameter_traversal';
   }
  }
  return $signals;
 }
}
