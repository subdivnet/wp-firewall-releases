<?php
/** Existing retained observations only. No new collector, storage or enforcement. */
if(!defined('ABSPATH'))exit;
require_once __DIR__.'/owner-report.php';
final class WFP_Attack_Visibility {
 public static function model($state,$now){
  return ['day'=>WFP_Owner_Report::attacks($state,$now,86400),'week'=>WFP_Owner_Report::attacks($state,$now,604800)];
 }
 public static function sentence($row){
  if(!is_array($row))return 'Attack activity counts are not available yet.';
  $parts=[];foreach(['failed_logins'=>['failed login attempt','failed login attempts'],'guessing_bursts'=>['possible password-guessing burst','possible password-guessing bursts'],'sensitive_file_probes'=>['sensitive-file probe','sensitive-file probes'],'xmlrpc_abuse_signals'=>['possible XML-RPC abuse group','possible XML-RPC abuse groups']] as $key=>$labels){$n=$row[$key];$parts[]=($n>=1000000?'at least ':'').number_format($n).' '.$labels[$n===1?0:1];}
  return implode(', ',array_slice($parts,0,3)).' and '.$parts[3].' were recorded in the included retained observations.';
 }
 public static function needs_review($row){return is_array($row)&&($row['guessing_bursts']>0||$row['sensitive_file_probes']>0||$row['xmlrpc_abuse_signals']>0);}
 public static function render($model){
  echo '<h2>Attack activity</h2><p>This shows what the Firewall observed, not who visited or whether anyone broke in. Observation mode does not block or challenge requests.</p>';
  $labels=['failed_logins'=>['Failed login attempts','Rejected WordPress logins can include mistakes as well as password guessing.'],
   'guessing_bursts'=>['Possible password guessing','Retained groups with at least three failed attempts over no more than 15 seconds. These are groups, not unique people.'],
   'sensitive_file_probes'=>['Sensitive-file probes','Requests resembling searches for configuration or other sensitive files, only when WordPress saw the request.'],
   'xmlrpc_abuse_signals'=>['Possible XML-RPC abuse','Rapid failed-login groups through XML-RPC. Ordinary XML-RPC use and isolated failures are not classified as abuse.']];
  foreach(['day'=>'Past 24 hours','week'=>'Past seven days'] as $key=>$title){
   $row=$model[$key]??null;echo '<section><h3>'.esc_html($title).'</h3><p>'.esc_html(self::sentence($row)).'</p>';
   foreach($labels as $field=>$text){
    $n=is_array($row)?$row[$field]:null;
    echo '<section class="wfp-check"><h4>'.esc_html($text[0]).'</h4><p><strong>'.esc_html($n===null?'Not checked yet':(($n>=1000000?'At least ':'').number_format($n))).'</strong></p><p>'.esc_html($text[1]).'</p></section>';
   }
   if(is_array($row))echo '<p>Observation window: '.esc_html($row['window_start_utc']).' to '.esc_html($row['window_end_utc']).' UTC.</p>';
   echo '</section>';
  }
  echo '<details class="wfp-details"><summary>What these counts can tell you</summary><p>These counts overlap: an XML-RPC burst also contributes to failed logins and password-guessing groups. Do not add them together.</p><p>Coverage is partial. Only up to 100 retained event groups are available. Older groups may have been discarded, and groups crossing the start of the window, invalid timestamps and future groups are excluded. A zero means none in the included groups; it is not proof that the site received no attacks.</p><p>WordPress cannot see requests stopped by the web server, host or another earlier layer. Collection interruptions and concurrent updates can lose observations. No usernames, IP addresses or raw request examples are shown.</p></details>';
 }
}
