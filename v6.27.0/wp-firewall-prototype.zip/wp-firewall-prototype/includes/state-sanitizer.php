<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Read-only validation of observer option data.
 * Never trusts option keys as request identities or displays arbitrary option fields.
 */
final class WFP_State_Sanitizer {
 public static function timestamp($value) {
  if (!is_string($value) || !preg_match('/^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$/D', $value)) { return ''; }
  $dt = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $value, new DateTimeZone('UTC'));
  return $dt && $dt->format('Y-m-d H:i:s') === $value ? $value : '';
 }
 public static function count_value($value, $minimum = 0) {
  if (!is_int($value) && !(is_string($value) && preg_match('/^\\d{1,19}$/D', $value))) { return $minimum; }
  $n = (int) $value;
  return max($minimum, $n);
 }
 public static function totals($data) {
  $safe = [];
  if (!is_array($data)) { return $safe; }
  foreach (WFP_Observer::SIGNALS as $signal) {
   if (array_key_exists($signal, $data)) { $safe[$signal] = self::count_value($data[$signal]); }
  }
  return $safe;
 }
 public static function dates($data) {
  $safe = [];
  if (!is_array($data)) { return $safe; }
  foreach (WFP_Observer::SIGNALS as $signal) {
   $stamp = self::timestamp($data[$signal] ?? null);
   if ($stamp !== '') { $safe[$signal] = $stamp; }
  }
  return $safe;
 }
 public static function events($events) {
  if (!is_array($events)) { return []; }
  $safe = [];
  foreach (array_slice($events, 0, 500) as $event) {
   if (!is_array($event)) { continue; }
   $first = self::timestamp($event['time'] ?? null);
   if ($first === '') { continue; }
   $raw = $event['signals'] ?? '';
   if (!is_string($raw)) { continue; }
   $codes = [];
   foreach (explode(',', $raw) as $code) {
    $code = trim($code);
    if (in_array($code, WFP_Observer::SIGNALS, true) && !in_array($code, $codes, true)) { $codes[] = $code; }
   }
   if (!$codes) { continue; }
   $last = self::timestamp($event['last_seen_utc'] ?? null);
   // Only an absent legacy end time may fall back to the first observation.
   // Preserve reversed windows and invalid explicit ends so reports can reject them.
   if (!array_key_exists('last_seen_utc', $event)) { $last = $first; }
   $duration = $event['duration_ms'] ?? 0;
   $duration = is_numeric($duration) ? (float) $duration : 0.0;
   if (!is_finite($duration) || $duration < 0 || $duration > 10000) { $duration = 0.0; }
   // Retain only a fixed categorical login entry point, never a URL or identity.
   $entry_point = $event['entry_point'] ?? '';
   if (!in_array($entry_point, ['WordPress login', 'XML-RPC', 'Other'], true)
    || !in_array('failed_login', $codes, true)) { $entry_point = ''; }
   $safe[] = [
    'time' => $first,
    'epoch' => strtotime($first . ' UTC'),
    'signals' => implode(', ', $codes),
    'entry_point' => $entry_point,
    'occurrences' => self::count_value($event['occurrences'] ?? 1, 1),
    'last_seen_utc' => $last,
    'duration_ms' => $duration,
   ];
   if (count($safe) >= WFP_Observer::MAX_EVENTS) { break; }
  }
  return $safe;
 }
 public static function state($data) {
  if (!is_array($data)) { $data = []; }
  $daily = WFP_Observer::recent_daily($data['daily'] ?? []);
  $safe_daily = [];
  foreach ($daily as $day => $counts) {
   $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $day, new DateTimeZone('UTC'));
   if ($dt && $dt->format('Y-m-d') === $day) { $safe_daily[$day] = self::totals($counts); }
  }
  return [
   'events' => self::events($data['events'] ?? []),
   'counts' => self::totals($data['counts'] ?? []),
   'first' => self::dates($data['first'] ?? []),
   'last' => self::dates($data['last'] ?? []),
   'daily' => $safe_daily,
  ];
 }
}
