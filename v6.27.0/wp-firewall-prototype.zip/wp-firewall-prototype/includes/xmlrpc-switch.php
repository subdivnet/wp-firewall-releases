<?php
if (!defined('ABSPATH')) { exit; }

final class WFP_XMLRPC_Switch {
 const OPTION = 'wfp_xmlrpc_disabled_v1';
 const ACTION = 'wfp_xmlrpc_switch';

 public static function init() {
  add_action('plugins_loaded', [__CLASS__, 'guard'], 1);
  add_action('admin_post_' . self::ACTION, [__CLASS__, 'save']);
 }

 public static function disabled() {
  return get_option(self::OPTION, '0') === '1';
 }

 public static function guard() {
  if (!defined('XMLRPC_REQUEST') || XMLRPC_REQUEST !== true || !self::disabled()) return;
  status_header(403);
  nocache_headers();
  header('Content-Type: text/plain; charset=UTF-8');
  echo 'XML-RPC is disabled by the site owner.';
  exit;
 }

 public static function save() {
  if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !current_user_can('manage_options')) {
   wp_die('Administrator access and a POST request are required.', '', ['response'=>403]);
  }
  check_admin_referer(self::ACTION);
  $value = $_POST['wfp_disable_xmlrpc'] ?? null;
  if ($value !== '0' && $value !== '1') wp_die('Choose whether to disable XML-RPC.', '', ['response'=>400]);
  update_option(self::OPTION, $value, false);
  if (get_option(self::OPTION, '0') !== $value) wp_die('Could not save the XML-RPC setting.', '', ['response'=>500]);
  wp_safe_redirect(WFP_Owner_Admin::url('hardening') . '#wfp-xmlrpc-switch');
  exit;
 }

 public static function render() {
  $disabled = self::disabled();
  echo '<section class="wfp-check" id="wfp-xmlrpc-switch"><h3>XML-RPC</h3><p>';
  echo $disabled ? 'WP Firewall is blocking XML-RPC on this site.' : 'WP Firewall is not blocking XML-RPC on this site.';
  echo '</p><p>Some WordPress mobile apps, remote publishing tools, Jetpack features and pingbacks may depend on XML-RPC. Check what your site uses before turning it off. This switch does not change the WordPress REST API or normal sign-in.</p>';
  echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="' . esc_attr(self::ACTION) . '">';
  echo '<input type="hidden" name="wfp_disable_xmlrpc" value="' . ($disabled ? '0' : '1') . '">';
  echo str_replace('id="_wpnonce"', 'id="wfp-xmlrpc-nonce"', wp_nonce_field(self::ACTION, '_wpnonce', true, false));
  echo '<button type="submit" class="button">' . ($disabled ? 'Restore XML-RPC' : 'Disable XML-RPC') . '</button></form></section>';
 }
}
