<?php
/**
 * Plugin Name: WP Firewall Prototype
 * Description: WordPress security monitoring and optional owner-controlled login and XML-RPC protection.
 * Version: 6.27.0
 * Update URI: https://pebkac404.com/wp-firewall-prototype
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
if (!defined('WFP_PUBLIC_UPDATES_ORIGIN')) {
 define('WFP_PUBLIC_UPDATES_ORIGIN', 'https://raw.githubusercontent.com/subdivnet/wp-firewall-releases/refs/heads/main');
}
if (!defined('WFP_PUBLIC_UPDATES_KEY')) {
 define('WFP_PUBLIC_UPDATES_KEY', <<<'WFP_RELEASE_PUBLIC_KEY'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAjihjbUW6QXtenLep4EKR
N2XlDc7rGeTkzveVYKGdwTsZIfNHYOYrrCs74liPuBhn2hc0FMoCbQqFPuT8SX5w
o3jEyeFDnlUwCETkDOoxG5Obg453zhzCxYrhq7awdH0uCQU97DDoBR7gN9bu6442
t6aA7/PHX90VtF8qkqz28gi9ygDBPpyvxFtmVAqKKhHpPKbi7K8yS9pbAXs+WsPj
x2t/vPYJlwHlJEi4pdLLBcdsy3oY7jtqCIkFANSeporEmqX752qheBOmGLvdRmPX
+yHR3Z7JgLMv4GcpQ9N+Nibe9Bg06zDE7ANrgbU8tdnIewdkjPHqVb/FWBR2Eu1X
4Zl6ZxLyq28ZBGz9juNsJ4NLryPMgGS39Blq896fcuqok0itJJuCMSlOYblTD8ne
PlMGNkAV18GIt5jGPiCGvZw48h4sT6ShCSX0B5KEvOxvkiYfuG4HRH1ww2N3uCuG
PZmX8ReBbxb1Hc2cX2qNt9fjvfhSP7b34hAnpOjcuGfdAgMBAAE=
-----END PUBLIC KEY-----
WFP_RELEASE_PUBLIC_KEY
 );
}

require_once __DIR__ . '/includes/detector.php';
require_once __DIR__ . '/includes/state-sanitizer.php';
require_once __DIR__ . '/includes/content-audit.php';
require_once __DIR__ . '/includes/core-integrity.php';
require_once __DIR__ . '/includes/content-integrity.php';
require_once __DIR__ . '/includes/extension-integrity.php';
require_once __DIR__ . '/includes/plugin-packages.php';
require_once __DIR__ . '/includes/uploads-inventory.php';
require_once __DIR__ . '/includes/upload-candidates.php';
require_once __DIR__ . '/includes/config-integrity.php';
require_once __DIR__ . '/includes/metadata-integrity.php';
require_once __DIR__ . '/includes/options-integrity.php';
require_once __DIR__ . '/includes/scan-overview.php';
final class WFP_Observer {
 const OPT = 'wfp_events_v01';
 const STATE = 'wfp_observer_state_v2';
 const PLUGIN_FILE = 'wp-firewall-prototype/wp-firewall-prototype.php';
 const MAX_EVENTS = 100;
 const COALESCE_SECONDS = 60;
 const COUNTERS = 'wfp_signal_counts_v1';
 const FIRST_SEEN = 'wfp_signal_first_seen_v1';
 const LAST_SEEN = 'wfp_signal_last_seen_v1';
 const SCHEMA = 1;
 const SIGNALS = ['repeated_path_traversal', 'script_tag_in_query', 'sql_union_select_in_query', 'command_parameter', 'file_path_parameter_traversal', 'sensitive_file_probe', 'failed_login', 'successful_login', 'administrator_role_assigned', 'plugin_activated', 'plugin_deactivated', 'plugin_updated', 'observer_updated', 'account_created', 'account_deleted', 'theme_switched', 'theme_updated', 'core_updated', 'published_content_changed'];
 public static function signal_info($signal) {
  $catalog = [
   'script_tag_in_query' => ['Possible script injection', 'A URL contained text resembling an HTML script tag. This can be a cross-site scripting probe, but the match alone does not establish exploitation.'],
   'repeated_path_traversal' => ['Repeated directory traversal', 'A URL attempted to move up through multiple folders. This can indicate a search for files outside the intended directory.'],
   'sql_union_select_in_query' => ['Possible SQL injection', 'A URL contained UNION SELECT text, a pattern sometimes used when probing database queries.'],
   'command_parameter' => ['Command-related URL parameter', 'A URL included a parameter named cmd, exec, or shell. This is a weak indicator and may be legitimate application traffic.'],
   'file_path_parameter_traversal' => ['File parameter with parent path', 'A file or path parameter included parent-directory navigation, which may indicate a file access probe.'],
   'sensitive_file_probe' => ['Sensitive configuration file request', 'A request path resembled a private environment, repository, credentials or WordPress configuration file. WordPress may not see requests rejected earlier by the web server.'],
   'failed_login' => ['Failed WordPress login', 'WordPress rejected a login attempt. This may be a user typo or unauthorized access attempt. No username is retained.'],
   'successful_login' => ['Successful WordPress login', 'WordPress accepted a login. This alone is normal activity, not evidence of a compromise. No username is retained.'],
   'administrator_role_assigned' => ['Administrator role assigned', 'A WordPress user was granted the administrator role. Confirm this was expected. No user identity is retained.'],
   'plugin_activated' => ['Plugin activated', 'A WordPress plugin was enabled. Verify this matches an authorized change.'],
   'plugin_deactivated' => ['Plugin deactivated', 'A WordPress plugin was disabled. Verify this was intentional, particularly for security tools.'],
   'plugin_updated' => ['Plugin updated', 'A WordPress plugin update completed. Confirm this was expected.'],
   'observer_updated' => ['Firewall observer updated', 'The firewall observer plugin itself was updated. This is maintenance activity, not evidence of an attack.'],
   'account_created' => ['WordPress account created', 'A new WordPress user account was registered. Confirm this matches the site registration policy. No username is stored.'],
   'account_deleted' => ['WordPress account deleted', 'A WordPress user account was removed. Confirm this was authorized. No username is stored.'],
   'theme_switched' => ['WordPress theme changed', 'The active theme changed. Confirm this matches an approved site update.'],
   'theme_updated' => ['WordPress theme updated', 'A theme update process completed. Confirm this was scheduled.'],
   'published_content_changed' => ['Published content changed', 'WordPress reported a title, body or excerpt change to an already published post, page or product. Verify unexpected edits. No content, page ID or author identity is retained.'],
   'core_updated' => ['WordPress core updated', 'A WordPress core update completed. Confirm version and site functionality separately.'],
  ];
  return $catalog[$signal] ?? ['Unrecognized detection', 'An internal rule identifier was not recognized.'];
 }
 public static function triage_guidance($signal) {
  if ($signal === 'published_content_changed') { return ['Content change', 'Confirm the edit was expected; this event alone is not evidence of compromise.']; }
  if ($signal === 'observer_updated') { return ['Expected maintenance', 'This plugin was updated, not an attempted break-in.']; }
  if (in_array($signal, ['plugin_activated', 'plugin_deactivated', 'plugin_updated'], true)) { return ['Plugin change', 'Confirm this plugin change was authorized.']; }
  if (in_array($signal, ['theme_switched', 'theme_updated', 'core_updated'], true)) { return ['WordPress change', 'Confirm this theme or WordPress update was authorized.']; }
  if (in_array($signal, ['account_created', 'account_deleted'], true)) { return ['Account change', 'Verify this account change matched expected site activity.']; }
  if ($signal === 'failed_login') { return ['Authentication activity', 'A failed login may be routine; repeated failures merit context.']; }
  if ($signal === 'successful_login') { return ['Account access', 'A successful login is not proof of unauthorized access; verify only if unexpected.']; }
  if ($signal === 'administrator_role_assigned') { return ['Review permissions', 'Verify the administrator grant was authorized.']; }
  if ($signal === 'command_parameter') { return ['Low confidence', 'This parameter may be legitimate application traffic; review repeated occurrences before investigating.']; }
  if (!in_array($signal, self::SIGNALS, true)) { return ['Unknown', 'Review the rule identifier.']; }
  return ['Possible probe', 'Corroborate with server logs before concluding an attack occurred.'];
 }
 public static function assessment($counts) {
  if (!is_array($counts)) { $counts = []; }
  $total = 0;
  foreach (self::SIGNALS as $signal) {
   $n = max(0, (int) ($counts[$signal] ?? 0));
   $total = $total >= PHP_INT_MAX - $n ? PHP_INT_MAX : $total + $n;
  }
  $admin_changes = max(0, (int) ($counts['administrator_role_assigned'] ?? 0));
  $login_failures = max(0, (int) ($counts['failed_login'] ?? 0));
  $web_patterns = 0;
  foreach (['repeated_path_traversal', 'script_tag_in_query', 'sql_union_select_in_query', 'file_path_parameter_traversal', 'sensitive_file_probe'] as $signal) {
   $n = max(0, (int) ($counts[$signal] ?? 0));
   $web_patterns = $web_patterns >= PHP_INT_MAX - $n ? PHP_INT_MAX : $web_patterns + $n;
  }
  if ($admin_changes > 0) {
   return ['category' => 'review_admin_changes', 'headline' => 'Administrator permissions changed', 'guidance' => 'Confirm the administrator grant was expected. This record alone cannot establish whether it was authorized.', 'total' => $total];
  }
  if ($web_patterns > 0) {
   return ['category' => 'possible_probing', 'headline' => 'Possible probing patterns recorded', 'guidance' => 'Review recent observations and corroborate with server logs before concluding an attack occurred.', 'total' => $total];
  }
  $account_changes = max(0, (int) ($counts['account_created'] ?? 0)) + max(0, (int) ($counts['account_deleted'] ?? 0));
  if ($account_changes > 0) {
   return ['category' => 'review_account_changes', 'headline' => 'WordPress user accounts changed', 'guidance' => 'Review account creation or deletion against expected registration and administrator actions.', 'total' => $total];
  }
  if ($login_failures >= 5) {
   return ['category' => 'repeated_login_failures', 'headline' => 'Repeated unsuccessful logins', 'guidance' => 'Review authentication logs for context. Login failures can result from typos or automated guessing.', 'total' => $total];
  }
  if ($login_failures > 0) {
   return ['category' => 'occasional_login_failures', 'headline' => 'Some unsuccessful logins', 'guidance' => 'One or a few unsuccessful logins are common and do not, by themselves, indicate intrusion.', 'total' => $total];
  }
  if (max(0, (int) ($counts['published_content_changed'] ?? 0)) > 0) {
   return ['category' => 'review_content_changes', 'headline' => 'Published content changed', 'guidance' => 'Verify unexpected edits against planned work. These are save events, not distinct pages or proof of compromise.', 'total' => $total];
  }
  $plugin_changes = 0;
  foreach (['plugin_activated', 'plugin_deactivated', 'plugin_updated', 'theme_switched', 'theme_updated', 'core_updated'] as $signal) {
   $n = max(0, (int) ($counts[$signal] ?? 0));
   $plugin_changes = $plugin_changes >= PHP_INT_MAX - $n ? PHP_INT_MAX : $plugin_changes + $n;
  }
  if ($plugin_changes > 0) {
   return ['category' => 'review_site_changes', 'headline' => 'WordPress software changes recorded', 'guidance' => 'Confirm that plugin or theme changes and WordPress updates matched planned maintenance. This is not proof of malicious activity.', 'total' => $total];
  }
  if (max(0, (int) ($counts['successful_login'] ?? 0)) > 0) {
   return ['category' => 'normal_login_activity', 'headline' => 'Successful logins recorded', 'guidance' => 'This is normally expected when authorized users sign in. It does not show whether an account was compromised.', 'total' => $total];
  }
  if (max(0, (int) ($counts['observer_updated'] ?? 0)) > 0) {
   return ['category' => 'observer_maintenance', 'headline' => 'Firewall maintenance recorded', 'guidance' => 'The firewall observer was updated. No suspicious activity is implied by this event alone.', 'total' => $total];
  }
  if ($total > 0) {
   return ['category' => 'low_confidence', 'headline' => 'Only weak indicators recorded', 'guidance' => 'Review patterns only if they persist; command-related URL parameters may be legitimate.', 'total' => $total];
  }
  return ['category' => 'no_matches', 'headline' => 'No matching observations recorded', 'guidance' => 'There are no retained detections for these rules. This does not guarantee the site has not been scanned or attacked.', 'total' => 0];
 }
 public static function filter_events($events, $signal) {
  if (!is_array($events)) { return []; }
  if (!in_array($signal, self::SIGNALS, true)) { return array_slice($events, 0, self::MAX_EVENTS); }
  $result = [];
  foreach (array_slice($events, 0, self::MAX_EVENTS) as $event) {
   if (!is_array($event)) { continue; }
   $codes = array_map('trim', explode(',', (string) ($event['signals'] ?? '')));
   if (in_array($signal, $codes, true)) { $result[] = $event; }
  }
  return $result;
 }
 public static function overview($state, $now = null) {
  if (!is_array($state)) { $state = []; }
  $now = $now === null ? time() : (int) $now;
  $day = gmdate('Y-m-d', $now);
  $daily = self::recent_daily($state['daily'] ?? [], $now);
  $today_counts = isset($daily[$day]) && is_array($daily[$day]) ? $daily[$day] : [];
  $events = isset($state['events']) && is_array($state['events']) ? array_slice($state['events'], 0, self::MAX_EVENTS) : [];
  $last = '';
  foreach ($events as $event) {
   if (!is_array($event)) { continue; }
   $stamp = WFP_State_Sanitizer::timestamp($event['last_seen_utc'] ?? ($event['time'] ?? null));
   $first = WFP_State_Sanitizer::timestamp($event['time'] ?? null);
   if ($first !== '' && $stamp !== '' && $stamp >= $first && $stamp <= gmdate('Y-m-d H:i:s', $now) && $stamp > $last) { $last = $stamp; }
  }
  $today_failed = max(0, (int) ($today_counts['failed_login'] ?? 0));
  return [
   'day_utc' => $day,
   'failed_logins_today' => $today_failed,
   'last_observation_utc' => $last,
   'retained_event_groups' => count($events),
   'observations_are_not_people' => true,
  ];
 }
 public static function login_entry_label($event) {
  $value = is_array($event) ? ($event['entry_point'] ?? '') : '';
  return in_array($value, ['WordPress login', 'XML-RPC', 'Other'], true) ? $value : 'Unknown (older event)';
 }
 public static function login_entry_summary($events) {
  $counts = ['WordPress login' => 0, 'XML-RPC' => 0, 'Other' => 0, 'Unknown (older events)' => 0];
  if (!is_array($events)) { return $counts; }
  foreach (array_slice($events, 0, self::MAX_EVENTS) as $event) {
   if (!is_array($event) || !in_array('failed_login', array_map('trim', explode(',', (string) ($event['signals'] ?? ''))), true)) { continue; }
   $key = $event['entry_point'] ?? '';
   if (!in_array($key, ['WordPress login', 'XML-RPC', 'Other'], true)) { $key = 'Unknown (older events)'; }
   $n = max(0, (int) ($event['occurrences'] ?? 1));
   $counts[$key] = $counts[$key] >= PHP_INT_MAX - $n ? PHP_INT_MAX : $counts[$key] + $n;
  }
  return $counts;
 }
 public static function recent_failed_logins($events, $now = null) {
  return self::recent_signal_occurrences($events, 'failed_login', 86400, $now);
 }
 public static function recent_content_changes($events, $now = null) {
  $recent = self::recent_signal_occurrences($events, 'published_content_changed', 900, $now);
  return [
   'changes' => $recent['attempts'], 'groups' => $recent['groups'],
   'partial_groups' => $recent['partial_groups'], 'scope' => $recent['scope'],
   'window_seconds' => 900, 'review_bulk_changes' => $recent['attempts'] >= 20,
   'meaning' => 'WordPress title/body/excerpt save events, not distinct pages. Direct SQL, post-meta-only page-builder changes and filesystem changes are not observed.',
  ];
 }
 private static function recent_signal_occurrences($events, $signal, $seconds, $now = null) {
  $now = $now === null ? time() : (int) $now;
  $since = $now - $seconds;
  $attempts = 0;
  $groups = 0;
  $partial = false;
  if (!is_array($events)) { return ['attempts' => 0, 'groups' => 0, 'partial_groups' => false, 'scope' => 'retained event groups only']; }
  foreach (array_slice($events, 0, self::MAX_EVENTS) as $event) {
   if (!is_array($event) || !in_array($signal, array_map('trim', explode(',', (string) ($event['signals'] ?? ''))), true)) { continue; }
   $first = WFP_State_Sanitizer::timestamp($event['time'] ?? '');
   $last = WFP_State_Sanitizer::timestamp($event['last_seen_utc'] ?? ($event['time'] ?? ''));
   if ($first === '' || $last === '') { continue; }
   $begin = strtotime($first . ' UTC');
   $end = strtotime($last . ' UTC');
   if ($end < $begin || $end > $now || $end < $since || $begin > $now) { continue; }
   if ($begin < $since) { $partial = true; continue; }
   $n = max(1, (int) ($event['occurrences'] ?? 1));
   $attempts = $attempts >= PHP_INT_MAX - $n ? PHP_INT_MAX : $attempts + $n;
   $groups++;
  }
  return ['attempts' => $attempts, 'groups' => $groups, 'partial_groups' => $partial, 'scope' => 'retained event groups only'];
 }
 public static function login_bursts($events, $now = null) {
  $now = $now === null ? time() : (int) $now;
  $earliest = $now - 7 * 86400;
  $groups = 0;
  $attempts = 0;
  $last = '';
  if (!is_array($events)) { $events = []; }
  foreach (array_slice($events, 0, self::MAX_EVENTS) as $event) {
   if (!is_array($event) || ($event['signals'] ?? '') !== 'failed_login') { continue; }
   // Stored timestamps are UTC, regardless of the PHP/server default timezone.
   $first_stamp = WFP_State_Sanitizer::timestamp($event['time'] ?? null);
   if ($first_stamp === '' && isset($event['epoch']) && is_int($event['epoch'])) {
    $first_stamp = gmdate('Y-m-d H:i:s', $event['epoch']);
   }
   $last_stamp = WFP_State_Sanitizer::timestamp($event['last_seen_utc'] ?? ($event['time'] ?? null));
   if ($first_stamp === '' || $last_stamp === '') { continue; }
   $first_epoch = strtotime($first_stamp . ' UTC');
   $last_epoch = strtotime($last_stamp . ' UTC');
   $n = max(0, (int) ($event['occurrences'] ?? 1));
   if ($first_epoch < $earliest || $first_epoch > $now || $last_epoch < $first_epoch || $last_epoch > $now) { continue; }
   if ($n < 3 || $last_epoch - $first_epoch > 15) { continue; }
   $groups++;
   $attempts = $attempts >= PHP_INT_MAX - $n ? PHP_INT_MAX : $attempts + $n;
   $timestamp = gmdate('Y-m-d H:i:s', $last_epoch);
   if ($timestamp > $last) { $last = $timestamp; }
  }
  return ['groups' => $groups, 'attempts' => $attempts, 'last_seen_utc' => $last, 'meaning' => 'Rapid failed-login groups, not unique people or proof of an attack.'];
 }
 public static function seven_day_rows($daily, $now = null) {
  $now = $now === null ? time() : (int) $now;
  $recent = self::recent_daily($daily, $now);
  $rows = [];
  for ($offset = 0; $offset < 7; $offset++) {
   $day = gmdate('Y-m-d', $now - $offset * 86400);
   $rows[$day] = isset($recent[$day]) && is_array($recent[$day]) ? $recent[$day] : [];
  }
  return $rows;
 }
 public static function recent_counts($daily) {
  $totals = [];
  foreach (self::recent_daily($daily) as $day => $counts) {
   foreach (self::SIGNALS as $signal) {
    $n = max(0, (int) ($counts[$signal] ?? 0));
    $old = max(0, (int) ($totals[$signal] ?? 0));
    $totals[$signal] = $old >= PHP_INT_MAX - $n ? PHP_INT_MAX : $old + $n;
   }
  }
  return $totals;
 }
 public static function signal_summary($labels) {
  $parts = explode(', ', (string) $labels);
  $names = [];
  foreach ($parts as $part) { $info = self::signal_info($part); $names[] = $info[0]; }
  return implode(', ', $names);
 }
 public static function coverage_summary() {
  return [
   'request_scope' => 'Only requests that reach WordPress are examined; server/CDN-blocked traffic is invisible.',
   'authentication_scope' => 'Only WordPress login success/failure hooks are recorded.',
   'attribution' => 'No IP addresses or usernames are stored, so attempts cannot be attributed to distinct people.',
   'accuracy' => 'Concurrent requests can race when updating WordPress options; totals are observations, not a guaranteed complete traffic count.',
   'response_mode' => 'Observation only: requests are never blocked or challenged.',
  ];
 }
 public static function self_test() {
  $cases = [
   ['/index.php', []],
   ['/?q=%3Cscript%3E', ['script_tag_in_query']],
   ['/?q=UNION+SELECT+id', ['sql_union_select_in_query']],
   ['/x/../../y', ['repeated_path_traversal']],
   ['/?file=safe.txt&note=../private', []],
   ['/?file=../private', ['file_path_parameter_traversal']],
   ['/?cmd=status', ['command_parameter']],
   ['/.env', ['sensitive_file_probe']],
  ];
  $passed = 0;
  foreach ($cases as $case) { if (WFP_Detector::classify($case[0]) === $case[1]) { $passed++; } }
  return ['total' => count($cases), 'passed' => $passed];
 }
 public static function init() {
  add_action('init', [__CLASS__, 'observe'], 1);
  add_action('wp_login_failed', [__CLASS__, 'login_failed']);
  add_action('wp_login', [__CLASS__, 'login_succeeded']);
  add_action('post_updated', [__CLASS__, 'content_updated'], 10, 3);
  // add_user_role fires for both WP_User::add_role() and new grants in set_role().
  // Monitoring set_user_role as well would double-count the same grant.
  add_action('add_user_role', [__CLASS__, 'role_assigned'], 10, 2);
  add_action('activated_plugin', [__CLASS__, 'plugin_activated']);
  add_action('deactivated_plugin', [__CLASS__, 'plugin_deactivated']);
  add_action('user_register', [__CLASS__, 'account_created']);
  add_action('deleted_user', [__CLASS__, 'account_deleted']);
  add_action('switch_theme', [__CLASS__, 'theme_switched']);
  add_action('upgrader_process_complete', [__CLASS__, 'upgrader_complete'], 10, 2);
  add_action('admin_menu', [__CLASS__, 'menu']);
  add_action('admin_post_wfp_clear', [__CLASS__, 'clear']);
  add_action('rest_api_init', [__CLASS__, 'register_status']);
 }
 public static function recent_daily($daily, $now = null) {
  if (!is_array($daily)) { return []; }
  $now = $now === null ? time() : (int) $now;
  $today = gmdate('Y-m-d', $now);
  $cutoff = gmdate('Y-m-d', $now - 6 * 86400);
  $result = [];
  foreach ($daily as $day => $counts) {
   if (is_string($day) && preg_match('/^\\d{4}-\\d{2}-\\d{2}$/D', $day)
     && $day >= $cutoff && $day <= $today && is_array($counts)) {
    $result[$day] = $counts;
   }
  }
  return $result;
 }
 public static function read_state() {
  $state = get_option(self::STATE, false);
  if (is_array($state) && isset($state['events'], $state['counts'], $state['first'], $state['last'])) {
   return WFP_State_Sanitizer::state([
    'events' => is_array($state['events']) ? $state['events'] : [],
    'counts' => is_array($state['counts']) ? $state['counts'] : [],
    'first' => is_array($state['first']) ? $state['first'] : [],
    'last' => is_array($state['last']) ? $state['last'] : [],
    'daily' => self::recent_daily($state['daily'] ?? []),
   ]);
  }
  // Read legacy options until the first v2 write; no data loss at upgrade.
  $events = get_option(self::OPT, []);
  $counts = get_option(self::COUNTERS, []);
  $first = get_option(self::FIRST_SEEN, []);
  $last = get_option(self::LAST_SEEN, []);
  return WFP_State_Sanitizer::state([
   'events' => is_array($events) ? $events : [],
   'counts' => is_array($counts) ? $counts : [],
   'first' => is_array($first) ? $first : [],
   'last' => is_array($last) ? $last : [],
   'daily' => [],
  ]);
 }
 public static function observe() {
  $start = microtime(true);
  if (defined('WP_CLI') && WP_CLI) { return; }
  $uri = isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI']) ? substr($_SERVER['REQUEST_URI'], 0, 4096) : '';
  self::record_signals(WFP_Detector::classify($uri), $start);
 }
 public static function login_failed() {
  self::record_signals(['failed_login'], null, self::login_entry_point());
 }
 public static function login_entry_point() {
  $uri = isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI']) ? substr($_SERVER['REQUEST_URI'], 0, 4096) : '';
  $path = parse_url($uri, PHP_URL_PATH);
  if (!is_string($path)) { return 'Other'; }
  if (preg_match('~(?:^|/)xmlrpc\\.php$~i', $path)) { return 'XML-RPC'; }
  if (preg_match('~(?:^|/)wp-login\\.php$~i', $path)) { return 'WordPress login'; }
  return 'Other';
 }
 public static function content_updated($post_id, $after, $before) {
  if (!is_object($after) || !is_object($before)) { return; }
  if (($before->post_status ?? '') !== 'publish' || ($after->post_status ?? '') !== 'publish'
   || !in_array($after->post_type ?? '', ['post', 'page', 'product'], true)
   || ($before->post_type ?? '') !== $after->post_type) { return; }
  foreach (['post_title', 'post_content', 'post_excerpt'] as $field) {
   if (isset($before->$field, $after->$field) && is_string($before->$field)
    && is_string($after->$field) && $before->$field !== $after->$field) {
    self::record_signals(['published_content_changed']);
    return; // One event per save, even if several content fields changed.
   }
  }
 }
 public static function login_succeeded() {
  self::record_signals(['successful_login']);
 }
 public static function role_assigned($user_id, $role) {
  if ($role === 'administrator') { self::record_signals(['administrator_role_assigned']); }
 }
 public static function plugin_activated() { self::record_signals(['plugin_activated']); }
 public static function plugin_deactivated() { self::record_signals(['plugin_deactivated']); }
 public static function account_created() { self::record_signals(['account_created']); }
 public static function account_deleted() { self::record_signals(['account_deleted']); }
 public static function theme_switched() { self::record_signals(['theme_switched']); }
 public static function upgrader_complete($upgrader, $details) {
  if (!is_array($details) || ($details['action'] ?? '') !== 'update') { return; }
  $type = $details['type'] ?? '';
  if ($type === 'plugin') {
   $files = isset($details['plugins']) && is_array($details['plugins']) ? $details['plugins'] : [];
   if (in_array(self::PLUGIN_FILE, $files, true)) {
    $signals = ['observer_updated'];
    if (count($files) > 1) { $signals[] = 'plugin_updated'; }
    self::record_signals($signals);
   } else {
    self::record_signals(['plugin_updated']);
   }
   return;
  }
  $map = ['theme' => 'theme_updated', 'core' => 'core_updated'];
  if (isset($map[$type])) { self::record_signals([$map[$type]]); }
 }
 public static function record_signals($signals, $start = null, $entry_point = '') {
  if (!is_array($signals)) { return; }
  $signals = array_values(array_unique(array_intersect($signals, self::SIGNALS)));
  if (!$signals) { return; }
  if ($start === null) { $start = microtime(true); }
  if (!in_array($entry_point, ['WordPress login', 'XML-RPC', 'Other'], true) || !in_array('failed_login', $signals, true)) { $entry_point = ''; }
  $state = self::read_state();
  $events = $state['events'];
  // Privacy by design: store no URL/path/query, IP, headers, cookies or request body.
  // Coalesce adjacent matching signals within a minute to bound event-list growth.
  $now = time();
  $labels = implode(', ', $signals);
  if (isset($events[0]) && is_array($events[0])
   && ($events[0]['signals'] ?? '') === $labels
   && ($events[0]['entry_point'] ?? '') === $entry_point
   && WFP_State_Sanitizer::timestamp($events[0]['last_seen_utc'] ?? null) !== ''
   && $events[0]['last_seen_utc'] >= $events[0]['time']
   && $events[0]['last_seen_utc'] <= gmdate('Y-m-d H:i:s', $now)
   && isset($events[0]['epoch'])
   && is_numeric($events[0]['epoch'])
   && $now >= (int) $events[0]['epoch']
   && $now - (int) $events[0]['epoch'] < self::COALESCE_SECONDS) {
   $events[0]['occurrences'] = (max(1, (int) ($events[0]['occurrences'] ?? 1)) >= PHP_INT_MAX ? PHP_INT_MAX : max(1, (int) ($events[0]['occurrences'] ?? 1)) + 1);
   $events[0]['last_seen_utc'] = gmdate('Y-m-d H:i:s', $now);
  } else {
   array_unshift($events, [
    'time' => gmdate('Y-m-d H:i:s', $now),
    'epoch' => $now,
    'signals' => $labels,
    'entry_point' => $entry_point,
    'occurrences' => 1,
    'last_seen_utc' => gmdate('Y-m-d H:i:s', $now),
    'duration_ms' => round((microtime(true)-$start)*1000, 3)
   ]);
  }
  $events = array_slice($events, 0, self::MAX_EVENTS);
  $counts = $state['counts'];
  foreach ($signals as $signal) {
   if (!in_array($signal, self::SIGNALS, true)) { continue; }
   $counts[$signal] = (max(0, (int) ($counts[$signal] ?? 0)) >= PHP_INT_MAX ? PHP_INT_MAX : max(0, (int) ($counts[$signal] ?? 0)) + 1);
  }
  $first = $state['first'];
  foreach ($signals as $signal) {
   if (in_array($signal, self::SIGNALS, true) && empty($first[$signal])) {
    $first[$signal] = gmdate('Y-m-d H:i:s');
   }
  }
  $last = $state['last'];
  foreach ($signals as $signal) {
   if (in_array($signal, self::SIGNALS, true)) {
    $last[$signal] = gmdate('Y-m-d H:i:s');
   }
  }
  // Privacy-preserving seven-day time series, capped to seven date buckets.
  $daily = $state['daily'];
  $today = gmdate('Y-m-d', $now);
  $cutoff = gmdate('Y-m-d', $now - 6 * 86400);
  foreach ($daily as $day => $totals) {
   if (!is_string($day) || $day < $cutoff || $day > $today) { unset($daily[$day]); }
  }
  if (!isset($daily[$today]) || !is_array($daily[$today])) { $daily[$today] = []; }
  foreach ($signals as $signal) {
   if (!in_array($signal, self::SIGNALS, true)) { continue; }
   $current = max(0, (int) ($daily[$today][$signal] ?? 0));
   $daily[$today][$signal] = $current >= PHP_INT_MAX ? PHP_INT_MAX : $current + 1;
  }
  update_option(self::STATE, compact('events', 'counts', 'first', 'last', 'daily'), false);
 }
 public static function menu() {
  add_management_page('Firewall Observer', 'Firewall Observer', 'manage_options', 'wfp-observer', [__CLASS__, 'page']);
 }
 public static function demo_state() {
  $now = time();
  $today = gmdate('Y-m-d', $now);
  $yesterday = gmdate('Y-m-d', $now - 86400);
  return [
   'events' => [
    ['time' => gmdate('Y-m-d H:i:s', $now - 60), 'last_seen_utc' => gmdate('Y-m-d H:i:s', $now), 'signals' => 'script_tag_in_query', 'occurrences' => 7, 'duration_ms' => 0.12],
    ['time' => gmdate('Y-m-d H:i:s', $now - 3600), 'last_seen_utc' => gmdate('Y-m-d H:i:s', $now - 3500), 'signals' => 'repeated_path_traversal', 'occurrences' => 3, 'duration_ms' => 0.15],
   ],
   'counts' => ['script_tag_in_query' => 15, 'repeated_path_traversal' => 5],
   'first' => ['script_tag_in_query' => gmdate('Y-m-d H:i:s', $now - 86400), 'repeated_path_traversal' => gmdate('Y-m-d H:i:s', $now - 7200)],
   'last' => ['script_tag_in_query' => gmdate('Y-m-d H:i:s', $now), 'repeated_path_traversal' => gmdate('Y-m-d H:i:s', $now - 3500)],
   'daily' => [
    $yesterday => ['script_tag_in_query' => 8, 'repeated_path_traversal' => 2],
    $today => ['script_tag_in_query' => 7, 'repeated_path_traversal' => 3],
   ],
  ];
 }
 public static function page() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  $demo = isset($_GET['wfp_demo']) && (string) $_GET['wfp_demo'] === '1';
  $state = $demo ? self::demo_state() : self::read_state();
  $events = $state['events'];
  echo '<div class="wrap"><h1>Firewall Observer v6.27.0</h1><p><strong>Observation only:</strong> no blocking, no early bootstrap protection, no automatic rule updates. This is not a replacement for Wordfence.</p>';
  if ($demo) {
   echo '<div class="notice notice-warning inline"><p><strong>DEMO PREVIEW ONLY:</strong> All counts, dates, and rows below are fictitious and are not persisted. Live monitoring and the REST API remain unchanged. <a href="'.esc_url(admin_url('tools.php?page=wfp-observer')).'">Return to live data</a>.</p></div>';
  } else {
   echo '<p><a class="button button-secondary" href="'.esc_url(admin_url('tools.php?page=wfp-observer&wfp_demo=1')).'">Preview dashboard with demo data</a></p>';
  }
  if (!$demo) { WFP_Scan_Overview::render(); }
  echo '<p>'.($demo ? 'Demo event groups' : 'Events stored').': '.esc_html((string)count($events)).' (maximum '.self::MAX_EVENTS.')</p>';
  echo '<p>Data handling: raw request URLs, IP addresses, headers, cookies, and bodies are not retained. Only detection labels and UTC timestamps are recorded.</p>';
  $overview = self::overview($state);
  echo '<h2>Today at a glance (UTC)</h2><p><strong>Failed logins:</strong> '.esc_html((string) $overview['failed_logins_today']).' &nbsp; | &nbsp; <strong>Most recent retained observation:</strong> '.esc_html($overview['last_observation_utc'] !== '' ? $overview['last_observation_utc'] : 'None').'</p>';
  echo '<p class="description">These are WordPress events, not unique visitors or confirmed intrusions. Times use UTC.</p>';
  if (!$demo && count($events) === 0) { echo '<p>No genuine matching observations are currently stored. This does not prove that no scans occurred.</p>'; }
  $counts = $state['counts'];
  $first = $state['first'];
  $last = $state['last'];
  $assessment = self::assessment(self::recent_counts($state['daily']));
  $last24 = self::recent_failed_logins($events);
  echo '<h2>Failed logins in the past 24 hours</h2><p><strong>'.esc_html((string) $last24['attempts']).' failed attempts</strong> in '.esc_html((string) $last24['groups']).' retained event groups (not unique people).</p>';
  echo '<p class="description">This summary uses retained event groups, not complete server access logs. Groups overlapping the 24-hour boundary are omitted rather than assigning every attempt to the wrong day.</p>';
  if ($last24['partial_groups']) { echo '<p>At least one retained group crosses the reporting boundary and was excluded.</p>'; }
  $bursts = self::login_bursts($events);
  echo '<h2>Rapid failed-login activity</h2><p><strong>'.esc_html((string) $bursts['groups']).' groups, '.esc_html((string) $bursts['attempts']).' failed attempts</strong> in short bursts during the retained last seven days. These are failed attempts, not separate people or confirmed intrusion.</p>';
  $entry_totals = self::login_entry_summary($events);
  echo '<h2>Failed login entry points (retained history)</h2>';
  echo '<p>This is an entry-point classification, not a person or IP identification. Older events lack entry-point information.</p><ul>';
  foreach ($entry_totals as $entry => $count) {
   if ($count > 0) { echo '<li>'.esc_html($entry).': '.esc_html((string) $count).' failed attempts</li>'; }
  }
  echo '</ul>';
  echo '<h2>What needs attention? (last seven days)</h2><p><strong>'.esc_html($assessment['headline']).'</strong> — '.esc_html($assessment['guidance']).'</p>';
  echo '<p class="description">This assessment uses seven-day daily buckets, available only from versions that recorded daily trends. Lifetime totals below may include older activity.</p>';
  $changes = self::recent_content_changes($events);
  echo '<h2>Published content changes in the past 15 minutes</h2><p><strong>'.esc_html((string) $changes['changes']).' observed save events</strong> in retained history. These are not distinct pages; repeated edits to one page count more than once.</p>';
  if ($changes['review_bulk_changes']) { echo '<p><strong>Review bulk content activity:</strong> at least 20 content save events were observed. Confirm whether this matches planned work.</p>'; }
  if ($changes['partial_groups']) { echo '<p>A group crosses the time-window boundary and was excluded from this count.</p>'; }
  echo '<p>'.esc_html($changes['meaning']).' Events begin with this version; earlier edits cannot be reconstructed. No automatic notification or remediation occurs.</p>';
  $health = self::self_test();
  if (!$demo) {
   echo '<div id="wfp-scan-core"></div>';
   WFP_Core_Integrity::render(WFP_Core_Integrity::summary(), true);
   WFP_Core_Integrity::render_history();
   echo '<div id="wfp-scan-content"></div>';
   WFP_Content_Integrity::render();
   echo '<div id="wfp-scan-metadata"></div>';
   WFP_Metadata_Integrity::render();
   echo '<div id="wfp-scan-options"></div>';
   WFP_Options_Integrity::render();
   echo '<div id="wfp-scan-files"></div>';
   WFP_Extension_Integrity::render();
   echo '<div id="wfp-scan-packages"></div>';
   WFP_Plugin_Packages::render();
   echo '<div id="wfp-scan-uploads"></div>';
   WFP_Uploads_Inventory::render();
   echo '<div id="wfp-scan-candidates"></div>';
   WFP_Upload_Candidates::render();
   echo '<div id="wfp-scan-config"></div>';
   WFP_Config_Integrity::render();
   echo '<p>Core scans run hourly when WordPress cron executes. No outage notifications are sent; a quiet or offline site may delay scans. Scans have file, byte and time limits.</p>';
   $core_url = wp_nonce_url(admin_url('tools.php?page=wfp-observer&wfp_core_scan=1'), 'wfp_core_scan');
   echo '<p><a class="button button-secondary" href="'.esc_url($core_url).'">Scan WordPress core files now</a></p>';
   if (isset($_GET['wfp_core_scan']) && $_GET['wfp_core_scan'] === '1') {
    check_admin_referer('wfp_core_scan');
    WFP_Core_Integrity::render(WFP_Core_Integrity::run());
   }
   echo '<h2>Check published content</h2><p>Run a read-only metadata audit for missing author accounts, unusual dates and bulk recent edits. It checks published posts, pages and products; it does not compare page text or inspect files.</p>';
   $audit_url = wp_nonce_url(admin_url('tools.php?page=wfp-observer&wfp_audit=1'), 'wfp_content_audit');
   echo '<p><a class="button button-secondary" href="'.esc_url($audit_url).'">Run content audit</a></p>';
   if (isset($_GET['wfp_audit']) && $_GET['wfp_audit'] === '1') {
    check_admin_referer('wfp_content_audit');
    WFP_Content_Audit::render(WFP_Content_Audit::run());
   }
  }
  echo '<h2>Detector diagnostics</h2><p>Self-test passed '.esc_html((string) $health['passed']).' of '.esc_html((string) $health['total']).' checks. These checks do not create stored events.</p>';
  echo '<div class="notice notice-info inline"><p>Read-only telemetry. No requests are blocked or challenged. Counters are cumulative since last reset; recent event groups are limited to 100; consecutive matching detections within 60 seconds are grouped.</p></div>';
  echo '<details><summary><strong>What can and cannot be concluded from this data</strong></summary><ul>';
  foreach (self::coverage_summary() as $explanation) { echo '<li>'.esc_html($explanation).'</li>'; }
  echo '</ul></details>';
  $show_all = isset($_GET['wfp_show_all']) && (string) $_GET['wfp_show_all'] === '1';
  echo '<h2>What was detected?</h2><p>These are possible suspicious-request patterns, not confirmed compromises. The system observes traffic only; nothing was blocked.</p><table class="widefat striped"><thead><tr><th>Detection and meaning</th><th>Assessment</th><th>Occurrences</th><th>First seen (UTC)</th><th>Last seen (UTC)</th></tr></thead><tbody>';
  foreach (self::SIGNALS as $signal) {
   if (!$show_all && max(0, (int) ($counts[$signal] ?? 0)) === 0) { continue; }
   $info = self::signal_info($signal);
   $guidance = self::triage_guidance($signal);
   echo '<tr><td><strong>'.esc_html($info[0]).'</strong><p class="description">'.esc_html($info[1]).'</p></td><td><strong>'.esc_html($guidance[0]).'</strong><p class="description">'.esc_html($guidance[1]).'</p></td><td>'.esc_html((string) max(0, (int) ($counts[$signal] ?? 0))).'</td><td>'.esc_html((string) ($first[$signal] ?? 'never')).'</td><td>'.esc_html((string) ($last[$signal] ?? 'never')).'</td></tr>';
  }
  echo '</tbody></table>';
  $view_args = $demo ? '&wfp_demo=1' : '';
  if ($show_all) {
   echo '<p><a href="'.esc_url(admin_url('tools.php?page=wfp-observer'.$view_args)).'">Show recorded detections only</a></p>';
  } else {
   echo '<p>Showing detection types with recorded activity. <a href="'.esc_url(admin_url('tools.php?page=wfp-observer'.$view_args.'&wfp_show_all=1')).'">Show every detection rule</a></p>';
  }
  echo '<h2>Last seven days (UTC)</h2><p>Every UTC day is shown, including days with no recorded matching detections. Zero detections does not mean zero visitors or complete protection.</p><table class="widefat striped"><thead><tr><th>Day</th><th>Detections by signal</th></tr></thead><tbody>';
  $daily = self::seven_day_rows($state['daily']);
  foreach ($daily as $day => $totals) {
   if (!is_array($totals)) { continue; }
   $parts = [];
   foreach (self::SIGNALS as $signal) { if (!empty($totals[$signal])) { $parts[] = self::signal_info($signal)[0] . ': ' . max(0, (int) $totals[$signal]); } }
   echo '<tr><td>'.esc_html((string) $day).'</td><td>'.esc_html($parts ? implode(' | ', $parts) : 'No matching detections recorded').'</td></tr>';
  }
  echo '</tbody></table><h2>Recent observations</h2>';
  echo '<p>Recent observations are listed newest first. Aggregate counts may exceed the retained event count.</p>';
  $selected_signal = isset($_GET['wfp_signal']) && is_string($_GET['wfp_signal']) && in_array($_GET['wfp_signal'], self::SIGNALS, true) ? $_GET['wfp_signal'] : '';
  echo '<form method="get" action="'.esc_url(admin_url('tools.php')).'"><input type="hidden" name="page" value="wfp-observer">';
  if ($demo) { echo '<input type="hidden" name="wfp_demo" value="1">'; }
  echo '<label for="wfp-filter">Filter by detection: </label><select id="wfp-filter" name="wfp_signal"><option value="">All observations</option>';
  foreach (self::SIGNALS as $signal) {
   $info = self::signal_info($signal);
   echo '<option value="'.esc_attr($signal).'"'.($selected_signal === $signal ? ' selected' : '').'>'.esc_html($info[0]).'</option>';
  }
  echo '</select> <button class="button button-secondary" type="submit">Filter observations</button></form>';

  echo '<table class="widefat striped"><thead><tr><th>First seen (UTC)</th><th>Last seen (UTC)</th><th>Detection</th><th>Login entry point</th><th>Occurrences</th><th>First-processing time (ms)</th></tr></thead><tbody>';
  foreach (self::filter_events($events, $selected_signal) as $e) {
   echo '<tr><td>'.esc_html($e['time'] ?? '').'</td><td>'.esc_html($e['last_seen_utc'] ?? $e['time'] ?? '').'</td><td>'.esc_html(self::signal_summary($e['signals'] ?? '')).'</td><td>'.esc_html(in_array('failed_login', array_map('trim', explode(',', (string) ($e['signals'] ?? ''))), true) ? self::login_entry_label($e) : 'Not applicable').'</td><td>'.esc_html((string) ($e['occurrences'] ?? 1)).'</td><td>'.esc_html((string)($e['duration_ms'] ?? '')).'</td></tr>';
  }
  echo '</tbody></table><p><strong>Action taken:</strong> None. Detection does not mean the attempted attack succeeded.</p>';
  if ($demo) {
   echo '<p><em>Demo preview: clearing actual observations is disabled while fictitious data is displayed.</em></p>';
  } else {
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
   echo '<input type="hidden" name="action" value="wfp_clear">';
   wp_nonce_field('wfp_clear');
   echo '<p><label><input type="checkbox" name="wfp_confirm_clear" value="yes" required> I understand this permanently deletes real security observation history and counters.</label></p>';
   submit_button('Clear real observations', 'secondary');
   echo '</form>';
  }
  echo '</div>';
 }
 public static function register_status() {
  register_rest_route('wfp/v1', '/extension-integrity/preview', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Extension_Integrity::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/plugin-packages', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Plugin_Packages::summary()); },
  ]);
  register_rest_route('wfp/v1', '/plugin-packages/scan', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Plugin_Packages::scan()); },
  ]);
  register_rest_route('wfp/v1', '/config-integrity', [
   'methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Config_Integrity::status()); },
  ]);
  register_rest_route('wfp/v1', '/config-integrity/scan', [
   'methods' => 'POST', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Config_Integrity::scan()); },
  ]);
  register_rest_route('wfp/v1', '/config-integrity/preview', [
   'methods' => 'POST', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { nocache_headers(); return rest_ensure_response(WFP_Config_Integrity::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/upload-candidates', [
   'methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Upload_Candidates::status()); },
  ]);
  register_rest_route('wfp/v1', '/upload-candidates/scan', [
   'methods' => 'POST', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Upload_Candidates::scan()); },
  ]);
  register_rest_route('wfp/v1', '/upload-candidates/preview', [
   'methods' => 'POST', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { nocache_headers(); return rest_ensure_response(WFP_Upload_Candidates::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/uploads-inventory', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Uploads_Inventory::status()); },
  ]);
  register_rest_route('wfp/v1', '/uploads-inventory/scan', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Uploads_Inventory::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/extension-integrity', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Extension_Integrity::status()); },
  ]);
  register_rest_route('wfp/v1', '/extension-integrity/scan', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Extension_Integrity::scan()); },
  ]);
  register_rest_route('wfp/v1', '/site-options-integrity', [
   'methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Options_Integrity::status()); },
  ]);
  register_rest_route('wfp/v1', '/site-options-integrity/scan', [
   'methods' => 'POST', 'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Options_Integrity::scan()); },
  ]);
  register_rest_route('wfp/v1', '/metadata-integrity', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Metadata_Integrity::status()); },
  ]);
  register_rest_route('wfp/v1', '/metadata-integrity/scan', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Metadata_Integrity::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/content-integrity', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Content_Integrity::status()); },
  ]);
  register_rest_route('wfp/v1', '/content-integrity/scan', [
   'methods' => 'POST',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Content_Integrity::scan(true)); },
  ]);
  register_rest_route('wfp/v1', '/core-integrity', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Core_Integrity::run()); },
  ]);
  register_rest_route('wfp/v1', '/content-audit', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => function () { return rest_ensure_response(WFP_Content_Audit::run()); },
  ]);
  register_rest_route('wfp/v1', '/status', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => [__CLASS__, 'status'],
  ]);
  register_rest_route('wfp/v1', '/events', [
   'methods' => 'GET',
   'permission_callback' => function () { return current_user_can('manage_options'); },
   'callback' => [__CLASS__, 'events_api'],
  ]);
 }
 public static function status() {
  $state = self::read_state();
  $events = $state['events'];
  $counts = $state['counts'];
  $first = $state['first'];
  $last = $state['last'];
  return rest_ensure_response([
   'schema_version' => self::SCHEMA,
   'collector_version' => '6.27.0',
   'mode' => 'observation_only',
   'coverage' => self::coverage_summary(),
   'blocking_enabled' => false,
   'event_count' => is_array($events) ? count($events) : 0,
   'event_retention_limit' => self::MAX_EVENTS,
   'last_core_integrity_scan' => WFP_Core_Integrity::summary(),
   'core_integrity_history' => WFP_Core_Integrity::history(),
   'core_integrity_trend' => WFP_Core_Integrity::trend(),
   'content_integrity' => WFP_Content_Integrity::status(),
   'metadata_integrity' => WFP_Metadata_Integrity::status(),
   'site_options_integrity' => WFP_Options_Integrity::status(),
   'extension_integrity' => WFP_Extension_Integrity::status(),
   'uploads_inventory' => WFP_Uploads_Inventory::status(),
   'upload_candidates' => WFP_Upload_Candidates::status(),
   'config_integrity' => WFP_Config_Integrity::status(),
   'plugin_packages' => WFP_Plugin_Packages::summary(),
   'scan_review' => WFP_Scan_Overview::status(),
   'recent_content_changes_retained' => self::recent_content_changes($events),
   'rapid_login_bursts' => self::login_bursts($events),
   'last_24h_failed_logins_retained' => self::recent_failed_logins($events),
   'today_overview_utc' => self::overview($state),
   'login_entry_points_retained' => self::login_entry_summary($events),
   'coalesce_window_seconds' => self::COALESCE_SECONDS,
   'signal_counts' => is_array($counts) ? $counts : [],
   'first_seen_utc' => is_array($first) ? $first : [],
   'last_seen_utc' => is_array($last) ? $last : [],
   'daily_signal_counts_utc' => $state['daily'],
   'assessment' => self::assessment($counts),
   'recent_seven_day_assessment' => self::assessment(self::recent_counts($state['daily'])),
   'recent_seven_day_counts' => self::recent_counts($state['daily']),
  ]);
 }
 public static function events_api() {
  $state = self::read_state();
  $events = $state['events'];
  // The stored schema contains labels/times only; never expose raw request data.
  $safe = [];
  foreach (array_slice($events, 0, self::MAX_EVENTS) as $event) {
   if (!is_array($event)) { continue; }
   $safe[] = [
    'first_seen_utc' => (string) ($event['time'] ?? ''),
    'last_seen_utc' => (string) ($event['last_seen_utc'] ?? $event['time'] ?? ''),
    'signals' => (string) ($event['signals'] ?? ''),
    'login_entry_point' => (string) ($event['entry_point'] ?? ''),
    'occurrences' => max(1, (int) ($event['occurrences'] ?? 1)),
   ];
  }
  return rest_ensure_response([
   'mode' => 'observation_only',
   'blocking_enabled' => false,
   'retained_groups' => count($safe),
   'events' => $safe,
  ]);
 }
 public static function clear() {
  if (!current_user_can('manage_options')) { wp_die('Insufficient permissions'); }
  check_admin_referer('wfp_clear');
  if (!isset($_POST['wfp_confirm_clear']) || $_POST['wfp_confirm_clear'] !== 'yes') { wp_die('Explicit confirmation is required to erase real observations.'); }
  delete_option(self::STATE);
  delete_option(self::OPT);
  delete_option(self::COUNTERS);
  delete_option(self::FIRST_SEEN);
  delete_option(self::LAST_SEEN);
  wp_safe_redirect(admin_url('tools.php?page=wfp-observer'));
  exit;
 }
}
WFP_Observer::init();
WFP_Core_Integrity::init();
WFP_Content_Integrity::init();
WFP_Metadata_Integrity::init();
WFP_Options_Integrity::init();
WFP_Extension_Integrity::init();
WFP_Plugin_Packages::init();
WFP_Uploads_Inventory::init();
WFP_Upload_Candidates::init();
WFP_Config_Integrity::init();
// Optional private GitHub updater; inert until WFP_GITHUB_TOKEN is configured.
require_once __DIR__ . '/includes/private-updates.php';

// Manual SecurityLab feed measurement; no autonomous acquisition.
require_once __DIR__ . '/includes/scanner-host-lab.php';
// Explicitly enrolled SecurityLab can pull the owner's private hub feed.
require_once __DIR__ . '/includes/minimal-hub.php';

// Independent read-only prevention view; no authentication enforcement.
require_once __DIR__ . '/includes/prevention-panel.php';

// Unified owner navigation and presentation.
require_once __DIR__ . '/includes/owner-admin.php';
require_once __DIR__ . '/includes/owner-report.php';
require_once __DIR__ . '/includes/owner-mail.php';
require_once __DIR__ . '/includes/login-lockout/controller.php';
add_action('plugins_loaded', static function () { if (!is_multisite()) WFP_Login_Lockout_Controller::site()->register(); });
require_once __DIR__ . '/includes/xmlrpc-switch.php';
WFP_XMLRPC_Switch::init();
if (function_exists('register_deactivation_hook')) register_deactivation_hook(__FILE__, ['WFP_Owner_Mail', 'stop']);
