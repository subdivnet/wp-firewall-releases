<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__.'/hardening-facts.php';
require_once __DIR__.'/vulnerability-presentation.php';
require_once __DIR__.'/release-evidence.php';
require_once __DIR__.'/attack-visibility.php';
/** Owner-facing presentation only; collectors, references and schedules are untouched. */
final class WFP_Owner_Admin {
 const TABS=['overview'=>'Overview','vulnerabilities'=>'Vulnerabilities','attacks'=>'Attacks','login'=>'Login','hardening'=>'Hardening','settings'=>'Settings'];
 public static function init(){
  add_action('admin_menu',[__CLASS__,'menu'],999);
  add_action('admin_init',[__CLASS__,'legacy']);
 }
 public static function url($tab='overview'){return admin_url('admin.php?page=wp-firewall&tab='.$tab);}
 public static function menu(){
  remove_action('admin_notices',['WFP_Scanner_Host_Lab','notice']);
  foreach(['wfp-observer','wfp-updates','wfp-scanner-host-lab','wfp-minimal-hub','wfp-prevention'] as $slug)remove_submenu_page('tools.php',$slug);
  add_menu_page('WP Firewall','WP Firewall','manage_options','wp-firewall',[__CLASS__,'page'],'dashicons-shield',65);
 }
 public static function legacy(){
  if(!current_user_can('manage_options')||!isset($_GET['page'])||!is_string($_GET['page']))return;
  $map=['wfp-observer'=>'overview','wfp-updates'=>'settings','wfp-scanner-host-lab'=>'vulnerabilities','wfp-minimal-hub'=>'vulnerabilities','wfp-prevention'=>'hardening'];
  $page=wp_unslash($_GET['page']);if(isset($map[$page])){wp_safe_redirect(self::url($map[$page]));exit;}
 }
 public static function editor_enabled(){
  if((defined('DISALLOW_FILE_EDIT')&&DISALLOW_FILE_EDIT)||(defined('DISALLOW_FILE_MODS')&&DISALLOW_FILE_MODS))return false;
  if(function_exists('wp_is_file_mod_allowed')&&!wp_is_file_mod_allowed('capability_edit_plugins')&&!wp_is_file_mod_allowed('capability_edit_themes'))return false;
  return true;
 }
 public static function overview(array $findings,array $preview,$editor,$adminGrant=false,array $audit=[]){
  $items=[];
  if($findings)$items[]=['level'=>'red','sentence'=>'Known vulnerabilities need your attention.','action'=>'Review the findings and update the affected components.','button'=>'Review vulnerabilities','tab'=>'vulnerabilities'];
  if($adminGrant)$items[]=['level'=>'red','sentence'=>'Administrator access was granted in the last 24 hours.','action'=>'Confirm the access change was intended.','button'=>'Review accounts','url'=>admin_url('users.php')];
  if(($preview['pressure']??'')==='REVIEW')$items[]=['level'=>'yellow','sentence'=>'Repeated failed logins were recorded recently.','action'=>'Review the recent activity; this alone does not confirm an attack.','button'=>'Review logins','tab'=>'login'];
  if($editor)$items[]=['level'=>'yellow','sentence'=>'WordPress allows theme and plugin files to be edited in the dashboard.','action'=>'Turn off the file editor to reduce accidental or unwanted code changes.','button'=>'See how to turn it off','tab'=>'hardening'];
  foreach($audit as $check)if(($check['status']??'')==='review')$items[]=['level'=>'yellow','sentence'=>$check['sentence'],'action'=>$check['action'],'button'=>'Review hardening','tab'=>'hardening'];
  $red=false;foreach($items as $item)if($item['level']==='red')$red=true;
  return ['level'=>$red?'red':($items?'yellow':'green'),'label'=>$red?'Action needed':($items?'Worth a look':'No problems found'),'items'=>$items];
 }
 private static function recent_admin_grant(array $events,$now){
  foreach($events as $event){if(!is_array($event)||!in_array('administrator_role_assigned',array_map('trim',explode(',',(string)($event['signals']??''))),true))continue;$stamp=WFP_State_Sanitizer::timestamp($event['last_seen_utc']??($event['time']??''));if($stamp==='')continue;$t=strtotime($stamp.' UTC');if($t!==false&&$t<=$now&&$t>=$now-86400)return true;}return false;
 }
 public static function saved_message($kind,$feedConfigured,$updatesConfigured){
  if($kind==='feed'&&$feedConfigured)return 'Feed credential saved. You can leave this page; the site checks for feed updates automatically.';
  if($kind==='update_key_removed'&&!WFP_Private_Updates::stored_update_key_exists())return 'Stored plugin-update key removed.';
  if($kind==='updates'&&$updatesConfigured)return 'Plugin-update credential saved. You can manage updates from the Plugins page.';
  return '';
 }
 public static function login_summary(array $preview){
  $n=$preview['failed_attempts']??null;
  if(!is_int($n)||$n<0||$n>3000000)return ['color'=>'grey','text'=>'Not checked yet.'];
  if($n===0)return ['color'=>'neutral','text'=>'No failed login attempts were recorded in these periods.'];
  if($n<5)return ['color'=>'neutral','text'=>$n.($n===1?' failed login attempt was':' failed login attempts were').' recorded in these periods.'];
  return ['color'=>'yellow','text'=>'Repeated failed logins are worth reviewing; this alone does not confirm an attack.'];
 }
 private static function badge($text,$color='grey'){echo '<span class="wfp-badge wfp-'.esc_attr($color).'">'.esc_html($text).'</span>';}
 private static function overview_checks(array $hub,array $findings,array $attacks,array $state,array $scan,$now){
  $matching=$hub['matching']??[];
  $vulnerability=WFP_Vulnerability_Presentation::summary($findings,$matching,$now);
  $stamp=WFP_Vulnerability_Presentation::date($matching['checked_at_utc']??null,$now);
  $checked=$vulnerability['color']==='neutral';
  $current=$stamp!==null&&$now-strtotime($stamp.' UTC')<7200&&($matching['status']??'')==='COMPLETE'&&($matching['feed_status']??'')==='FRESH';
  $rows=[['label'=>'Known vulnerabilities','anchor'=>'wfp-overview-vulnerabilities','time'=>$stamp,
   'result'=>$checked?((int)$matching['components_checked'].' components checked. '.$vulnerability['text']):$vulnerability['text'],
   'action'=>$findings?'Review and update the affected components.':($checked&&$current?'No action needed for these results.':'Review feed freshness and check coverage.'),
   'url'=>self::url('vulnerabilities'),'live'=>!empty($hub['enabled'])&&($checked||($stamp!==null&&$findings))]];
  $last=WFP_Vulnerability_Presentation::date(WFP_Observer::overview($state)['last_observation_utc']??null,$now);
  $day=$attacks['day'];
  $review=WFP_Attack_Visibility::needs_review($day);
  $rows[]=['label'=>'Attack activity','anchor'=>'wfp-overview-attacks','time'=>$last,'time_label'=>'Last recorded observation',
   'result'=>WFP_Attack_Visibility::sentence($day),
   'action'=>$review?'Review the recorded activity.':(!is_array($day)?'Open Attacks to see what can be observed.':'No action from these counts. Coverage is partial.'),
   'url'=>self::url('attacks'),'live'=>true];
  foreach($scan['scopes'] as $row){
   $review=$row['review_observations'];$limited=$row['review_coverage'];
   $rows[]=['label'=>$row['label'],'anchor'=>$row['anchor'],'time'=>$row['report_time_utc'],
    'result'=>$row['latest_observations'],
    'action'=>$review?'Review the recorded differences. Planned changes can explain them.':($limited?'Check the age or coverage of this report.':'No action from the saved check.'),
    'coverage'=>$row['report_time_utc']===null?'No saved check':($row['coverage']==='complete'?'Check finished':($row['coverage']==='initial_unverified_reference'?'Starting reference only':'Incomplete or needs a fresh check')),
    'live'=>$row['report_time_utc']!==null||$row['progress']!==null];
  }
  return $rows;
 }
 private static function overview_cards(array $summary,array $rows){
  $cards=[
   'Vulnerabilities'=>['green','No known vulnerabilities found.',self::url('vulnerabilities')],
   'Attacks'=>['green','No attack activity needs your review.',self::url('attacks')],
   'Hardening'=>['green','No settings changes are recommended.',self::url('hardening')],
   'Site changes'=>['green','No site changes need your review.','#wfp-overview-details'],
  ];
  if($rows[0]['time']===null&&!$rows[0]['live'])$cards['Vulnerabilities'][1]='No vulnerability findings to review yet.';
  foreach($summary['items'] as $item){
   $category=['vulnerabilities'=>'Vulnerabilities','attacks'=>'Attacks','login'=>'Attacks','hardening'=>'Hardening'][$item['tab']??'']??'Site changes';
   if($cards[$category][0]!=='green'&&$item['level']!=='red')continue;
   $cards[$category][0]=$item['level'];
   $cards[$category][1]=$item['sentence'];
  }
  return $cards;
 }
 private static function render_overview(array $summary,array $rows,array $features){
  $level=$summary['level'];
  $label=['red'=>'Action needed','yellow'=>'Review recommended','green'=>'No action needed'][$level];
  echo '<div class="wfp-overview-cards" aria-label="Firewall at a glance">';
  foreach(self::overview_cards($summary,$rows) as $title=>$card){
   echo '<a class="wfp-overview-card wfp-'.esc_attr($card[0]).'" href="'.esc_url($card[2]).'"><h2>'.esc_html($title).'</h2><p>'.esc_html($card[1]).'</p></a>';
  }
  echo '</div>';
  echo '<div role="status" class="wfp-status wfp-'.esc_attr($level).'">'.esc_html($label).'</div>';
  echo '<section aria-labelledby="wfp-purpose"><h2 id="wfp-purpose">What WP Firewall does here</h2><p>WP Firewall observes WordPress activity and checks for changes in files, content and selected settings. When the vulnerability feed is connected, it checks installed versions against known advisories. It shows what was checked and what needs your attention. It does not block visitors or repair the site automatically.</p></section>';
  if($summary['items'])echo '<h2>What needs your attention</h2>';
  foreach($summary['items'] as $item){
   echo '<div class="wfp-item"><div>';self::badge($item['level']==='red'?'Action needed':'Review',$item['level']);
   echo '<p><strong>'.esc_html($item['sentence']).'</strong></p><p>'.esc_html($item['action']).'</p></div><a class="button" href="'.esc_url($item['url']??self::url($item['tab'])).'">'.esc_html($item['button']).'</a></div>';
  }
  echo '<section aria-labelledby="wfp-overview-working"><h2 id="wfp-overview-working">What’s working</h2><ul class="wfp-live-list">';
  foreach($features as $name=>$feature)echo '<li><a href="'.esc_url($feature[0]).'">'.esc_html($name).'</a> <span class="wfp-muted">'.esc_html($feature[1]).'</span></li>';
  echo '</ul></section><details class="wfp-details" id="wfp-overview-details"><summary>Show details</summary><h2>What was checked</h2><p class="wfp-muted">Private plugins may not have checksums on WordPress.org. That is normal. Feed age and partial coverage explain what the checks could see.</p><div class="wfp-check-table"><table class="widefat striped"><thead><tr><th scope="col">Check and time</th><th scope="col">Result and next step</th></tr></thead><tbody>';
  foreach($rows as $row){
   echo '<tr id="'.esc_attr($row['anchor']).'"><th scope="row">'.esc_html($row['label']).'<br><span class="wfp-muted">'.esc_html($row['time']===null?'No saved check time':(($row['time_label']??'Checked').': '.$row['time'].' UTC')).'</span></th><td>';
   echo '<p>'.esc_html($row['result']).'</p>';
   if(isset($row['coverage']))echo '<p class="wfp-muted">'.esc_html($row['coverage']).'</p>';
   echo '<p>'.esc_html($row['action']).'</p>';
   if(isset($row['url']))echo '<a href="'.esc_url($row['url']).'">Open '.esc_html($row['label']).'</a>';
   echo '</td></tr>';
  }
  echo '</tbody></table></div></details><script>(function(){function reveal(){var id=location.hash.slice(1);var target=document.getElementById(id);var detail=document.getElementById("wfp-overview-details");if(target&&detail&&(target===detail||detail.contains(target))){detail.open=true;target.scrollIntoView();}}window.addEventListener("hashchange",reveal);document.addEventListener("click",function(event){var link=event.target.closest("a[href^=\"#\"]");if(link&&link.hash===location.hash)reveal();});reveal();})();</script>';
 }
 private static function details($html){echo '<details class="wfp-details"><summary>Show details</summary>'.$html.'</details>';}
 private static function nonce_field($action,$id){
  // Change only DOM identity. Preserve WordPress action, POST name and nonce value.
  ob_start();wp_nonce_field($action);$html=ob_get_clean();
  echo str_replace('id="_wpnonce"','id="'.esc_attr($id).'"',$html);
 }
 private static function audit_rows(array $checks){
  $names=['public_registration'=>'Public account registration','registration_role'=>'Default new-account role','mfa_coverage'=>'Multi-factor authentication','https_login'=>'Login connection checks','application_passwords'=>'Connected application access','country_coverage'=>'Country information'];
  foreach($checks as $c){if(!isset($names[$c['id']])||$c['id']==='registration_role')continue;$text=$c['result']==='PASS'?'No problem found':($c['result']==='REVIEW'?'Worth a look':'Not checked yet');echo '<div class="wfp-check"><h3>'.esc_html($names[$c['id']]).'</h3>';self::badge($text,$c['result']==='PASS'?'green':($c['result']==='REVIEW'?'yellow':'grey'));if($c['id']==='public_registration'){
    if($c['result']==='PASS')echo '<p>Public account registration is turned off.</p>';
    elseif($c['result']==='REVIEW')echo '<p>Visitors can register for accounts. Review whether this is intended.</p><p><a class="button" href="'.esc_url(admin_url('options-general.php')).'">Review registration settings</a></p>';
   }
   self::details('<p>'.esc_html($c['id']==='public_registration'?'This checks public registration only; other account-creation paths are not covered.':$c['meaning']).'</p>');echo '</div>';}
 }
 public static function page(){
  if(!current_user_can('manage_options'))wp_die('Insufficient permissions');nocache_headers();
  $tab=isset($_GET['tab'])&&is_string($_GET['tab'])?sanitize_key(wp_unslash($_GET['tab'])):'overview';if(!isset(self::TABS[$tab]))$tab='overview';
  $report=WFP_Prevention_Panel::status();$hub=WFP_Minimal_Hub::status();$alerts=get_option(WFP_Scanner_Host_Lab::ALERTS,[]);$findings=is_array($alerts['findings']??null)?$alerts['findings']:[];$state=WFP_Observer::read_state();
  $hardening=WFP_Hardening_Facts::capture();
  $summary=self::overview($findings,$report['login']['preview'],self::editor_enabled(),self::recent_admin_grant($state['events']??[],time()),$hardening['checks']);
  $attackState=defined('WFP_Observer::STATE')&&!is_array(get_option(WFP_Observer::STATE,null))?null:$state;
  $attackModel=WFP_Attack_Visibility::model($attackState,time());
  if(WFP_Attack_Visibility::needs_review($attackModel['day'])){
   $summary['items'][]=['level'=>'yellow','sentence'=>'Possible probes or rapid failed-login groups were recorded in the past 24 hours.','action'=>'Review the observed counts; they do not prove a successful attack.','button'=>'Review attack activity','tab'=>'attacks'];
   if($summary['level']!=='red'){$summary['level']='yellow';$summary['label']='Worth a look';}
  }
  echo '<style>.wfp-owner{max-width:1120px}.wfp-status{padding:28px 32px;border-radius:10px;margin:24px 0;font-size:32px;font-weight:650}.wfp-green{background:#e7f4ea;color:#185c2c}.wfp-yellow{background:#fff3cd;color:#735000}.wfp-red{background:#fbe8e7;color:#9c2121}.wfp-grey{background:#eceff2;color:#50575e}.wfp-item{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:24px;background:white;padding:22px 24px;margin:12px 0;border:1px solid #dcdcde;border-radius:8px}.wfp-item p{font-size:15px;margin:5px 0}.wfp-item .button{flex-shrink:0}.wfp-check{background:white;border:1px solid #dcdcde;padding:20px 24px;margin:14px 0;border-radius:8px}.wfp-badge{display:inline-block;padding:5px 11px;border-radius:16px;font-size:13px}.wfp-details{margin:22px 0;padding:18px;background:white;border:1px solid #dcdcde;border-radius:8px}.wfp-details summary{cursor:pointer;font-weight:600}.wfp-owner input[type=password]{max-width:100%;box-sizing:border-box}.wfp-owner pre{white-space:pre-wrap;overflow-wrap:anywhere}.wfp-tabs{margin-bottom:24px}.wfp-owner table{margin:18px 0}.wfp-muted{color:#646970}</style><div class="wrap wfp-owner"><h1>WP Firewall</h1><nav class="nav-tab-wrapper wfp-tabs" aria-label="WP Firewall sections">';
  foreach(self::TABS as $key=>$label)echo '<a class="nav-tab'.($tab===$key?' nav-tab-active':'').'" href="'.esc_url(self::url($key)).'"'.($tab===$key?' aria-current="page"':'').'>'.esc_html($label).'</a>';
  echo '</nav>';
  if($tab==='overview'){
   echo '<style>.wfp-overview-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px}.wfp-overview-card{display:block;padding:18px 20px;border-radius:8px;border:1px solid currentColor;text-decoration:none}.wfp-overview-card h2{color:inherit;margin:0 0 8px;font-size:19px}.wfp-overview-card p{margin:0;color:inherit;font-size:14px}.wfp-overview-card:hover,.wfp-overview-card:focus-visible{text-decoration:underline;color:inherit}.wfp-owner .wfp-status{padding:14px 18px;font-size:22px;margin:18px 0}.wfp-live-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:0 18px}.wfp-live-list li{padding:7px 0;border-bottom:1px solid #dcdcde}.wfp-check-table th[scope=row]{width:38%;overflow-wrap:anywhere}.wfp-check-table td p{margin:6px 0}</style>';
   $scan=WFP_Scan_Overview::status();
   foreach($scan['scopes'] as $scope){
    if((($scope['scope']??'')==='core'&&$scope['review_observations'])||($scope['latest_bulk_assessment']??null)==='review'){
     $summary['items'][]=['level'=>'yellow','sentence'=>'Recorded site changes need a review.','action'=>'Check whether these differences match work you planned.','button'=>'Review site changes','url'=>'#'.$scope['anchor']];
     if($summary['level']==='green')$summary['level']='yellow';
     break;
    }
   }
   $rows=self::overview_checks($hub,$findings,$attackModel,$state,$scan,time());
   $features=['Login activity'=>[self::url('login'),'Records login activity as it happens.'],
    'Hardening checks'=>[self::url('hardening'),'Reviews selected WordPress settings.'],
    'Detector self-check'=>['#wfp-overview-diagnostics','Tests the built-in detection rules.']];
   foreach($rows as $row){if($row['live'])$features[$row['label']]=[$row['url']??'#'.$row['anchor'],''];}
   if(WFP_Private_Updates::updates_configured())$features['Plugin update checks']=[admin_url('plugins.php'),'Update source configured.'];
   if(class_exists('WFP_Owner_Mail')&&get_option(WFP_Owner_Mail::ENABLED,'0')==='1'&&wp_next_scheduled(WFP_Owner_Mail::HOOK)){
    $features['Owner email reports']=[self::url('settings').'#wfp-owner-mail',WFP_Owner_Mail::last_result()];
   }
   self::render_overview($summary,$rows,$features);
   echo '<section id="wfp-overview-diagnostics"><h2>Detector self-check and release evidence</h2>';
   self::details(WFP_Release_Evidence::html());echo '</section>';
  }elseif($tab==='vulnerabilities'){
   $presentation=WFP_Vulnerability_Presentation::summary($findings,is_array($hub['matching']??null)?$hub['matching']:[],time());
   echo '<h2>Vulnerabilities</h2>';
   if($presentation['color']==='grey')self::badge($presentation['text'],'grey');else echo '<p>'.esc_html($presentation['text']).'</p>';
   foreach($findings as $finding){$display=$finding;unset($display['feed_status'],$display['feed_age_seconds']);echo '<section class="wfp-check"><h3>'.esc_html($finding['title']??'Vulnerability finding').'</h3><p>Review the advisory and update the affected component.</p>';self::details(WFP_Wordfence_Local::render_finding($display));echo '</section>';}
   $m=$hub['matching']??[];$phase=$hub['state']['status']??'';
   $progress=$phase==='indexing'?'A downloaded update is being prepared; earlier results remain visible.':($phase==='unavailable'?'The latest update could not be completed; earlier results remain visible.':'The site checks the published feed automatically.');
   $cost=$hub['state']['resources']??null;$costText='<p>Feed resource measurements: Not checked yet.</p>';
   if(is_array($cost)&&isset($cost['cache_logical_bytes'],$cost['cache_files'],$cost['php_allocator_peak_bytes'],$cost['last_slice_elapsed_seconds'])){
    $active=$hub['state']['active']??[];
    $costText='<h3>Feed resource measurements</h3><p>Measured at '.esc_html(WFP_Vulnerability_Presentation::display_date($cost['captured_at_utc']??null,time())).'.</p><p>Local cache: '.esc_html(number_format($cost['cache_logical_bytes']/1048576,2)).' MiB across '.esc_html((string)$cost['cache_files']).' files. Local cache limit: 512 MiB and 2,048 files.</p><p>Largest PHP allocation recorded in the measured request: '.esc_html(number_format($cost['php_allocator_peak_bytes']/1048576,2)).' MiB. Measured request work: '.esc_html((string)$cost['last_slice_elapsed_seconds']).' seconds.</p><p>Current feed indexing: '.esc_html((string)($active['index_elapsed_seconds']??'Not checked yet')).' seconds across '.esc_html((string)($active['slices']??'Not checked yet')).' requests; longest indexing slice '.esc_html((string)($active['max_index_slice_seconds']??'Not checked yet')).' seconds.</p><p>These are logical file sizes, PHP allocator memory and elapsed time, not hosting quota, physical disk allocation, total process memory or CPU usage. Check account-level load and limits separately before adding another site.</p>';
   }
   $audit=$hub['state']['cache_audit']??null;
   if(($hub['state']['cache_policy']??null)==='legacy_measurement'&&is_array($audit)){
    $complete=($audit['complete']??false)===true;
    $costText='<h3>Existing cache measurement</h3><p>Measured at '.esc_html(WFP_Vulnerability_Presentation::display_date($audit['captured_at_utc']??null,time())).'.</p><p>'.($complete?'Local cache: ':'Counted so far: at least ').esc_html(number_format(($audit['logical_bytes']??0)/1048576,2)).' MiB across '.esc_html((string)($audit['files']??0)).' files.</p>';
    if(!$complete)$costText.='<p>The measurement did not finish. The full cache size has not been checked yet.</p>';
    $costText.='<p>The existing SecurityLab cache is being measured before a capacity change. Its previous feed behavior is retained; the new-site cache limit has not been applied here and old files are not removed.</p>';
    if(is_array($cost)&&isset($cost['php_allocator_peak_bytes'],$cost['last_slice_elapsed_seconds']))$costText.='<p>Largest PHP allocation in the measured feed request: '.esc_html(number_format($cost['php_allocator_peak_bytes']/1048576,2)).' MiB. Measured request work: '.esc_html((string)$cost['last_slice_elapsed_seconds']).' seconds. Captured at '.esc_html(WFP_Vulnerability_Presentation::display_date($cost['captured_at_utc']??null,time())).'.</p>';
    $costText.='<p>Logical file sizes are not physical disk allocation, account quota or inode headroom. PHP allocator memory and elapsed time are not total process memory or CPU usage.</p>';
   }
   self::details($costText.'<p>'.esc_html($progress).'</p><p>'.esc_html((string)($m['components_checked']??0)).' components and '.esc_html((string)($m['candidate_records_checked']??0)).' advisory records were checked. Matching covers selected records; full coverage is not established.</p><p>Feed acquired: '.esc_html(WFP_Vulnerability_Presentation::display_date($m['feed_attempt_utc']??null,time())).'. Last local check: '.esc_html(WFP_Vulnerability_Presentation::display_date($m['checked_at_utc']??null,time())).'.</p><p>Feed age and incomplete coverage do not create a vulnerability finding.</p>');
  }elseif($tab==='attacks'){
   WFP_Attack_Visibility::render($attackModel);
  }elseif($tab==='login'){
   $login=self::login_summary($report['login']['preview']);echo '<h2>Login activity</h2>';
   if($login['color']==='grey')self::badge($login['text'],'grey');else echo '<p>'.esc_html($login['text']).'</p>';
   if($login['color']==='yellow')echo '<p>Review whether the timing fits expected activity with your site maintainer.</p>';
   echo '<p>Login protection is observing activity. It does not block or challenge anyone.</p><table class="widefat striped"><thead><tr><th>Five-minute period starts (UTC)</th><th>Failed login attempts recorded</th></tr></thead><tbody>';
   foreach($report['login']['buckets'] as $b)echo '<tr><td>'.esc_html($b['bucket_start_utc']).'</td><td>'.esc_html((string)$b['failed_attempts']).'</td></tr>';echo '</tbody></table>';
   self::details('<p>The preview flags five recorded failures across these periods for review. It does not identify an attack or distinct people. Retained history can be incomplete; groups crossing period boundaries are excluded. Excluded groups: '.esc_html((string)$report['login']['preview']['ambiguous_groups_excluded']).'.</p><p>Country restrictions are not enabled. No trusted country sample is available for an impact estimate.</p>');
  }elseif($tab==='hardening'){
   echo '<h2>Hardening</h2><section class="wfp-check" id="file-editor"><h3>WordPress file editor</h3>';self::badge(self::editor_enabled()?'Worth a look':'Turned off',self::editor_enabled()?'yellow':'green');
   echo '<p>'.(self::editor_enabled()?'The dashboard file editor is enabled. Turning it off reduces accidental or unwanted changes to plugin and theme code.':'The dashboard file editor is turned off by site policy.').'</p>';
   if(self::editor_enabled())echo '<p>Ask your site maintainer to add this line to the WordPress configuration file, before the line that says to stop editing:</p><pre><code>define( \'DISALLOW_FILE_EDIT\', true );</code></pre><p>This turns off the built-in file editor while keeping normal plugin and theme updates available. This page does not change the file for you.</p><a class="button" href="https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#disable-the-plugin-and-theme-file-editor">Read the WordPress instructions</a>';
   echo '</section>';
   foreach($hardening['checks'] as $check){echo '<section class="wfp-check"><h3>'.esc_html($check['title']).'</h3>';self::badge($check['badge'],$check['color']);echo '<p>'.esc_html($check['sentence']).'</p>';if($check['action']!==null)echo '<p>'.esc_html($check['action']).'</p>';self::details('<p>'.esc_html($check['details']).'</p>');echo '</section>';}
   self::audit_rows($report['audit']['checks']);
   if(class_exists('WFP_XMLRPC_Switch'))WFP_XMLRPC_Switch::render();
   require __DIR__.'/country-draft-view.php';
  }else{
   $saved=isset($_GET['wfp_saved'])&&is_string($_GET['wfp_saved'])?sanitize_key(wp_unslash($_GET['wfp_saved'])):'';
   $message=self::saved_message($saved,WFP_Private_Updates::hub_configured(),WFP_Private_Updates::updates_configured());
   if($message!=='')echo '<div class="wfp-check wfp-green" role="status"><p>'.esc_html($message).'</p></div>';
   echo '<h2>Settings</h2><p>Matching stays on this site. The provider key stays on your machine. Credentials are never shown after saving.</p><section class="wfp-check"><h3>Feed connection</h3>';self::badge(WFP_Private_Updates::hub_configured()?'Credential saved':'Not configured',WFP_Private_Updates::hub_configured()?'green':'grey');
   echo '<p>Use a separate expiring read-only token for the private feed repository.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_hub_save_read_token">';self::nonce_field('wfp_hub_save_read_token','wfp-feed-nonce');echo '<label for="wfp_hub_read_token">New feed read-only token</label><p><input id="wfp_hub_read_token" name="wfp_hub_read_token" type="password" value="" autocomplete="new-password" size="55"></p>';submit_button('Save feed credential','secondary','submit',true,['id'=>'wfp-feed-submit']);echo '</form></section><section class="wfp-check"><h3>Plugin updates</h3>';
   if(WFP_Private_Updates::public_enabled()){
    self::badge('Signed public downloads','green');
    echo '<p>WordPress verifies Firewall updates before installing them. This update source works without a site key.</p>';
    if(WFP_Private_Updates::stored_update_key_exists()){
     echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_save_token">';
     self::nonce_field('wfp_save_token','wfp-remove-update-nonce');
     echo '<p><label><input type="checkbox" name="wfp_remove_token" value="1" required> Confirm removal of the old plugin-update key</label></p><p>This leaves the private feed key in place.</p>';
     submit_button('Remove old plugin-update key','secondary','submit',true,['id'=>'wfp-remove-update-submit']);
     echo '</form>';
    }
   }else{
    self::badge(WFP_Private_Updates::updates_configured()?'Credential saved':'Not configured',WFP_Private_Updates::updates_configured()?'green':'grey');echo '<p>The plugin update credential is separate from the feed credential. Saving a new credential replaces the stored one.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_save_token">';self::nonce_field('wfp_save_token','wfp-updates-nonce');echo '<label for="wfp_token">New plugin-update read-only token</label><p><input id="wfp_token" name="wfp_token" type="password" value="" autocomplete="new-password" size="55"></p>';submit_button('Save update credential','secondary','submit',true,['id'=>'wfp-updates-submit']);echo '</form>';
   }
   echo '<p><a class="button" href="'.esc_url(admin_url('plugins.php')).'">Manage plugin updates</a></p></section>';
   if(empty($hub['enabled'])){
    echo '<section class="wfp-check"><h3>Connect this site to the feed</h3><p>Saving a credential does not connect this site. The feed uses a private folder outside the public website; debug logging is not required. Start one site at a time and review its measured storage and request cost before adding another. Hosting limits may be unknown.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="wfp_minimal_hub">';self::nonce_field('wfp_minimal_hub','wfp-enroll-nonce');echo '<p><label for="wfp-hub-consent"><input id="wfp-hub-consent" type="checkbox" name="wfp_hub_site_consent" value="yes" required> I want this site to download the private feed and check component versions locally.</label></p><p>This schedules observation only. It does not block visitors or change WordPress security settings.</p>';submit_button('Connect this site','secondary','submit',true,['id'=>'wfp-enroll-submit']);echo '</form></section>';
   }
   WFP_Release_Evidence::settings_html();
   if(class_exists('WFP_Owner_Mail'))WFP_Owner_Mail::panel();
   if(class_exists('WFP_Login_Lockout_Controller')&&!is_multisite())WFP_Login_Lockout_Controller::site()->render();
   self::details('<p>The feed repository is subdivnet/wp-firewall-feed. The plugin source repository is subdivnet/wp-firewall. Use a different token for each, limited to its own repository.</p><p>Observation mode is active. No blocking, country restrictions, challenges or automatic setting changes are enabled.</p>');
  }
  echo '</div>';
 }
}
WFP_Owner_Admin::init();
