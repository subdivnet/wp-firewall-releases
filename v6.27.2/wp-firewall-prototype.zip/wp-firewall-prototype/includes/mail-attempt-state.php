<?php

/** Offline model for the state transition. A caller must persist it with compare-and-exchange. */
final class WFP_Mail_Attempt_Prototype {
 const MIN_INTERVAL=3600;
 const WEEK=604800;
 const LEASE=900;

 public static function reserve(array $state,$revision,$now,$claimId) {
  if(!is_int($now)||$now<self::WEEK||!self::id($claimId))return null;
  if($revision!==null&&(!is_string($revision)||!preg_match('/\A[a-f0-9]{64}\z/',$revision)))return null;
  $previous=$state['attempt']??0;
  $weeklyAt=$state['weekly']??0;
  if(!is_int($previous)||!is_int($weeklyAt)||$previous<0||$weeklyAt<0||$weeklyAt>$now
   ||$previous>$now-self::MIN_INTERVAL)return null;
  $active=$state['claim']??null;
  if($active!==null&&(!is_array($active)||!self::id($active['id']??null)
   ||!is_int($active['expires']??null)||$active['expires']>$now))return null;
  $alert=$revision!==null&&$revision!==($state['alert_revision']??null);
  if(!$alert&&$weeklyAt>$now-self::WEEK)return null;
  $kind=$alert?'alert':'weekly';
  $state['attempt']=$now;
  $state['result']='pending';
  $state['transport']='unknown';
  $state['claim']=['id'=>$claimId,'expires'=>$now+self::LEASE,'kind'=>$kind];
  if($alert)$state['alert_revision']=$revision;
  else $state['weekly']=$now;
  return ['state'=>$state,'send'=>$kind];
 }

 public static function complete(array $state,$claimId,$accepted,$transport) {
  if(!self::id($claimId)||!is_bool($accepted)||!in_array($transport,['smtp','local','unknown'],true))return null;
  $claim=$state['claim']??null;
  if(!is_array($claim)||($claim['id']??null)!==$claimId
   ||!in_array($claim['kind']??null,['alert','weekly'],true))return null;
  $state['result']=$accepted?'accepted':'failed';
  $state['transport']=$transport;
  if(!$accepted){
   unset($state[$claim['kind']==='alert'?'alert_revision':'weekly']);
  }
  unset($state['claim']);
  return $state;
 }

 private static function id($value) {
  return is_string($value)&&preg_match('/\A[a-f0-9]{32}\z/',$value);
 }
}
