<?php
/** Site-local delivery via WordPress's configured mail transport. */
if (!defined('ABSPATH')) exit;

require_once __DIR__.'/mail-attempt-state.php';

final class WFP_Owner_Mail {
 const HOOK = 'wfp_owner_mail_hourly';
 const ENABLED = 'wfp_owner_mail_enabled_v1';
 const RECIPIENT = 'wfp_owner_mail_recipient_v1';
 const STATE = 'wfp_owner_mail_state_v1';
 const LOCK = 'wfp_owner_mail_running_v1';

 public static function init() {
  add_action('init', [__CLASS__, 'schedule']);
  add_action(self::HOOK, [__CLASS__, 'run']);
  add_action('admin_post_wfp_owner_mail_settings', [__CLASS__, 'save']);
 }
 public static function schedule() {
  if (get_option(self::ENABLED, '0') === '1' && !wp_next_scheduled(self::HOOK)) {
   wp_schedule_event(time() + 300, 'hourly', self::HOOK);
  }
 }
 public static function stop() { wp_clear_scheduled_hook(self::HOOK); }

 public static function save() {
  if (!current_user_can('manage_options')) wp_die('Administrator permission required.');
  check_admin_referer('wfp_owner_mail_settings');
  $recipient = $_POST['wfp_owner_mail_recipient'] ?? '';
  if (!is_string($recipient)) wp_die('Enter a single email address.');
  $recipient = trim(wp_unslash($recipient));
  if ($recipient !== '' && !is_email($recipient)) wp_die('Enter a valid email address.');
  update_option(self::RECIPIENT, $recipient, false);
  $enabled = ($_POST['wfp_owner_mail_enabled'] ?? '') === '1';
  update_option(self::ENABLED, $enabled ? '1' : '0', false);
  if ($enabled) self::schedule(); else self::stop();
  wp_safe_redirect(admin_url('admin.php?page=wp-firewall&tab=settings'));
  exit;
 }
 public static function panel() {
  $enabled = get_option(self::ENABLED, '0') === '1';
  echo '<section id="wfp-owner-mail"><h3>Owner email reporting</h3><p>This site sends vulnerability alerts and a weekly summary through its existing WordPress mail setup.</p>';
  echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
  wp_nonce_field('wfp_owner_mail_settings');
  echo '<p><label for="wfp-owner-mail-recipient">Reporting email address</label> <input type="email" id="wfp-owner-mail-recipient" name="wfp_owner_mail_recipient" value="' . esc_attr(get_option(self::RECIPIENT, '')) . '"></p><p>Leave blank to use the WordPress administration email address.</p>';
  echo '<input type="hidden" name="action" value="wfp_owner_mail_settings"><label><input type="checkbox" name="wfp_owner_mail_enabled" value="1"' . checked($enabled, true, false) . '> Enable owner email reporting</label><p><button class="button" type="submit">Save email reporting</button></p></form>';
  $state = get_option(self::STATE, []);
  echo '<p>' . esc_html(self::last_result($state)) . '</p>';
  $route = is_array($state) ? ($state['transport'] ?? 'unknown') : 'unknown';
  if ($route !== 'smtp') {
   $warning = $route === 'local'
    ? 'The last Firewall email used WordPress’s local mail path. Check whether your host relays it through a sending service.'
    : 'Firewall has not verified a sending service for site mail. An API mail connector or a host relay may handle delivery.';
   echo '<p><strong>Mail delivery check:</strong> ' . esc_html($warning) . ' Configure your site’s mail service if needed, then verify a message reaches your inbox.</p>';
  } else {
   echo '<p>The last Firewall email used SMTP. Check your inbox to verify delivery.</p>';
  }
  echo '</section>';
 }

 public static function last_result($state = null) {
  if ($state === null) $state = get_option(self::STATE, []);
  $labels = ['accepted'=>'WordPress accepted the last email for sending.','failed'=>'WordPress could not send the last email.','pending'=>'The last delivery attempt has no recorded result.'];
  $result = is_array($state) && is_string($state['result'] ?? null) ? $state['result'] : '';
  return $labels[$result] ?? 'No email attempt recorded yet.';
 }

 /** Reserve and finish the same persisted attempt using exact stored bytes. */
 private static function change_state($transition) {
  global $wpdb;
  $table=$wpdb->options;
  if(!is_string($table)||!preg_match('/\A[A-Za-z0-9_]+\z/',$table))return null;
  $suppressed=$wpdb->suppress_errors(true);
  try{
   for($i=0;$i<3;$i++){
    $before=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM `'.$table.'` WHERE option_name=%s',self::STATE));
    if($wpdb->last_error!==''||($before!==null&&(!is_string($before)||strlen($before)>16384)))return null;
    $state=$before===null?[]:@unserialize($before,['allowed_classes'=>false]);
    if(!is_array($state))return null;
    $next=$transition($state);
    if(!is_array($next))return null;
    $encoded=serialize($next);
    if(strlen($encoded)>16384)return null;
    if($before===null){
     $sql=$wpdb->prepare('INSERT IGNORE INTO `'.$table.'` (option_name,option_value,autoload) VALUES (%s,%s,%s)',self::STATE,$encoded,'no');
    }else{
     $sql=$wpdb->prepare('UPDATE `'.$table.'` SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s',$encoded,self::STATE,$before);
    }
    $written=$wpdb->query($sql);
    if($written===false)return null;
    if($written===1){
     wp_cache_delete(self::STATE,'options');
     wp_cache_delete('notoptions','options');
     wp_cache_delete('alloptions','options');
     return $next;
    }
   }
  }catch(Throwable $error){return null;}
  finally{$wpdb->suppress_errors($suppressed);}
  return null;
 }

 public static function run() {
  if (get_option(self::ENABLED, '0') !== '1') return;
  // An older installed version may still be finishing a send. Preserve its lock.
  if (get_option(self::LOCK,false)!==false) return;
  $to = get_option(self::RECIPIENT, '');
  if ($to === '') $to = get_option('admin_email', '');
  if (!is_string($to) || !is_email($to)) return;
  $now=time();
  $report=WFP_Owner_Report::current();
  $revision=$report['feed_status']==='FRESH'&&$report['vulnerable_plugins']>0?$report['plugin_revision']:null;
  try{$claimId=bin2hex(random_bytes(16));}catch(Throwable $error){return;}
  $reserved=self::change_state(static function($state)use($revision,$now,$claimId){
   return WFP_Mail_Attempt_Prototype::reserve($state,$revision,$now,$claimId)['state']??null;
  });
  if($reserved===null)return;
  $weekly=$reserved['claim']['kind']==='weekly';
  $route='unknown';
  $observe=static function($mailer)use(&$route){
   $method=$mailer->Mailer??'';
   if($method==='smtp')$route='smtp';
   elseif(in_array($method,['mail','sendmail','qmail'],true))$route='local';
  };
  add_action('phpmailer_init',$observe,PHP_INT_MAX);
  try{
   $accepted=(bool)wp_mail($to,$weekly?'WP Firewall: weekly summary':'WP Firewall: vulnerable plugins found',self::message($report,$weekly));
  }catch(Throwable $error){$accepted=false;}
  finally{remove_action('phpmailer_init',$observe,PHP_INT_MAX);}
  self::change_state(static function($state)use($claimId,$accepted,$route){
   return WFP_Mail_Attempt_Prototype::complete($state,$claimId,$accepted,$route);
  });
 }

 public static function message($report, $weekly) {
  $lines = ['WP Firewall report for ' . $report['site'], ''];
  $count = $report['vulnerable_plugins'];
  $lines[] = $count === null ? 'Vulnerability check unavailable.' :
   'Plugins with known vulnerability matches: ' . $count . '. Components checked: ' . $report['components_checked'] . '.';
  $lines[] = 'Check coverage: ' . strtolower($report['coverage']) . '. Feed: ' . strtolower($report['feed_status']) . '.';
  if ($report['checked_at_utc']) $lines[] = 'Last checked: ' . $report['checked_at_utc'] . ' UTC.';
  if ($weekly && is_array($report['attacks'])) {
   $activity = $report['attacks'];
   $lines[] = '';
   $lines[] = 'Recorded activity in the last seven days (partial coverage):';
   $lines[] = 'Failed login attempts: ' . $activity['failed_logins'];
   $lines[] = 'Possible password-guessing bursts: ' . $activity['guessing_bursts'];
   $lines[] = 'Sensitive-file probes: ' . $activity['sensitive_file_probes'];
   $lines[] = 'Possible XML-RPC abuse signals: ' . $activity['xmlrpc_abuse_signals'];
   $lines[] = 'Counts may overlap.';
  } elseif ($weekly) {
   $lines[] = 'Attack activity counts are unavailable.';
  }
  $lines[] = '';
  $lines[] = admin_url('admin.php?page=wp-firewall&tab=vulnerabilities');
  return implode("\n", $lines);
 }
}
WFP_Owner_Mail::init();
